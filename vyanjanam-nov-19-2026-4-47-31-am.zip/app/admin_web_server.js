const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 3000;
const HTML_FILE = path.join(__dirname, 'app/src/main/assets/admin_dashboard.html');

const server = http.createServer((req, res) => {
  if (req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({ status: 'healthy', timestamp: new Date().toISOString() }));
  }

  // Read the latest admin dashboard file
  fs.readFile(HTML_FILE, 'utf8', (err, data) => {
    if (err) {
      console.error('Error reading admin dashboard HTML:', err);
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      return res.end('Admin Dashboard source file not found');
    }

    res.writeHead(200, {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'no-cache, no-store, must-revalidate',
      'Pragma': 'no-cache',
      'Expires': '0'
    });
    res.end(data);
  });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Vyanjanam Web Admin Dashboard Server listening on http://0.0.0.0:${PORT}`);
});
