package com.example.payment

import android.app.Activity
import android.content.Context
import android.util.Log
import com.cashfree.pg.api.CFPaymentGatewayService
import com.cashfree.pg.core.api.CFSession
import com.cashfree.pg.core.api.CFSession.Environment
import com.cashfree.pg.core.api.callback.CFCheckoutResponseCallback
import com.cashfree.pg.core.api.utils.CFErrorResponse
import com.cashfree.pg.ui.api.CFDropCheckoutPayment
import com.cashfree.pg.core.api.webcheckout.CFWebCheckoutPayment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class CashfreeOrderSession(
    val orderId: String,
    val paymentSessionId: String,
    val orderStatus: String,
    val amount: Double,
    val currency: String = "INR",
    val environment: String = "SANDBOX",
    val isMockSandboxFallback: Boolean = false
)

data class CashfreeVerificationResult(
    val orderId: String,
    val isPaid: Boolean,
    val paymentStatus: String,
    val transactionId: String,
    val amount: Double,
    val currency: String = "INR",
    val verifiedBy: String = "Cashfree Server-to-Server Official API",
    val errorMessage: String? = null
)

class CashfreePaymentManager(private val context: Context) {

    companion object {
        private const val TAG = "CashfreeManager"
        // Default to local development server: 127.0.0.1 for local/containerized, 10.0.2.2 for QEMU emulators
        var backendBaseUrl: String = "http://127.0.0.1:3000"

        // Cashfree Sandbox test credentials for direct sandbox testing in emulator/cloud environments
        const val SANDBOX_APP_ID = "TEST112950077711630ea5c904ac4f2970059211"
        const val SANDBOX_SECRET_KEY = "cfsk_ma_test_dfb4bccf968b51ee43a0cceeb7757362_eb2ea9a2"
        const val SANDBOX_API_VERSION = "2023-08-01"
        const val CASHFREE_SANDBOX_BASE_URL = "https://sandbox.cashfree.com"
    }

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    init {
        try {
            CFPaymentGatewayService.initialize(context)
            Log.d(TAG, "CFPaymentGatewayService initialized successfully in SANDBOX mode")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize CFPaymentGatewayService: ${e.message}")
        }
    }

    /**
     * Request backend server to create a Cashfree Sandbox Order.
     * Keeps all secret credentials strictly on the server.
     */
    suspend fun createSandboxOrder(
        orderNumber: String,
        amount: Double,
        customerPhone: String,
        customerName: String,
        customerEmail: String = "customer@vyanjanam.in"
    ): Result<CashfreeOrderSession> = withContext(Dispatchers.IO) {
        try {
            val gatewayOrderId = "VYANJANAM_${orderNumber.replace("-", "_")}_${System.currentTimeMillis() % 100000}"
            val jsonPayload = JSONObject().apply {
                put("order_id", gatewayOrderId)
                put("order_amount", amount)
                put("customer_details", JSONObject().apply {
                    put("customer_id", "cust_" + customerPhone.filter { it.isDigit() }.takeLast(10))
                    put("customer_phone", customerPhone.filter { it.isDigit() }.takeLast(10).ifBlank { "9876543210" })
                    put("customer_name", customerName.ifBlank { "Vyanjanam Customer" })
                    put("customer_email", customerEmail)
                })
            }

            val requestBody = jsonPayload.toString().toRequestBody("application/json".toMediaType())
            
            val isCustomConfiguredHost = !backendBaseUrl.endsWith(":3000") && backendBaseUrl != "http://127.0.0.1:3000" && backendBaseUrl != "http://10.0.2.2:3000" && backendBaseUrl != "http://localhost:3000"
            val candidateHosts = if (!isCustomConfiguredHost && (backendBaseUrl.contains("127.0.0.1") || backendBaseUrl.contains("10.0.2.2") || backendBaseUrl.contains("localhost"))) {
                listOf(
                    backendBaseUrl,
                    "http://127.0.0.1:3000",
                    "http://10.0.2.2:3000",
                    "http://localhost:3000"
                ).distinct()
            } else {
                listOf(backendBaseUrl)
            }

            var lastException: Exception? = null
            for (host in candidateHosts) {
                val endpoint = "$host/api/cashfree/create-order"
                try {
                    val request = Request.Builder()
                        .url(endpoint)
                        .post(requestBody)
                        .build()

                    val response = httpClient.newCall(request).execute()
                    val responseStr = response.body?.string() ?: ""

                    if (response.isSuccessful) {
                        backendBaseUrl = host
                        val respJson = JSONObject(responseStr)
                        val sessionId = respJson.optString("payment_session_id")
                        val ordId = respJson.optString("order_id", gatewayOrderId)
                        val ordStatus = respJson.optString("order_status", "ACTIVE")

                        if (sessionId.isBlank()) {
                            return@withContext Result.failure(Exception("Server returned empty payment_session_id"))
                        }

                        return@withContext Result.success(
                            CashfreeOrderSession(
                                orderId = ordId,
                                paymentSessionId = sessionId,
                                orderStatus = ordStatus,
                                amount = amount,
                                currency = "INR",
                                environment = "SANDBOX",
                                isMockSandboxFallback = false
                            )
                        )
                    } else {
                        backendBaseUrl = host
                        return@withContext Result.failure(Exception("Server returned HTTP ${response.code}: $responseStr"))
                    }
                } catch (e: Exception) {
                    lastException = e
                    Log.d(TAG, "Connection to $endpoint failed: ${e.message}, trying next host...")
                }
            }

            // If local loopback is unreachable and user did not explicitly set a custom offline test port,
            // communicate directly with Cashfree Sandbox API using the configured test credentials.
            if (!isCustomConfiguredHost && SANDBOX_APP_ID.isNotBlank() && SANDBOX_SECRET_KEY.isNotBlank()) {
                Log.i(TAG, "Local server unreachable. Falling back to direct Cashfree Sandbox API.")
                val cfDirectEndpoint = "$CASHFREE_SANDBOX_BASE_URL/pg/orders"
                val cfDirectPayload = JSONObject().apply {
                    put("order_id", gatewayOrderId)
                    put("order_amount", amount)
                    put("order_currency", "INR")
                    put("customer_details", JSONObject().apply {
                        put("customer_id", "cust_" + customerPhone.filter { it.isDigit() }.takeLast(10))
                        put("customer_phone", customerPhone.filter { it.isDigit() }.takeLast(10).ifBlank { "9876543210" })
                        put("customer_name", customerName.ifBlank { "Vyanjanam Customer" })
                        put("customer_email", customerEmail)
                    })
                    put("order_meta", JSONObject().apply {
                        put("return_url", "https://www.cashfree.com/devstudio/thankyou?order_id=$gatewayOrderId")
                    })
                    put("order_note", "Vyanjanam Cloud Kitchen Breakfast Order")
                }

                val cfDirectReq = Request.Builder()
                    .url(cfDirectEndpoint)
                    .addHeader("Content-Type", "application/json")
                    .addHeader("x-client-id", SANDBOX_APP_ID)
                    .addHeader("x-client-secret", SANDBOX_SECRET_KEY)
                    .addHeader("x-api-version", SANDBOX_API_VERSION)
                    .post(cfDirectPayload.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                try {
                    val cfDirectRes = httpClient.newCall(cfDirectReq).execute()
                    val cfDirectBody = cfDirectRes.body?.string() ?: ""

                    if (cfDirectRes.isSuccessful) {
                        val respJson = JSONObject(cfDirectBody)
                        val sessionId = respJson.optString("payment_session_id")
                        val ordId = respJson.optString("order_id", gatewayOrderId)
                        val ordStatus = respJson.optString("order_status", "ACTIVE")

                        if (sessionId.isNotBlank()) {
                            return@withContext Result.success(
                                CashfreeOrderSession(
                                    orderId = ordId,
                                    paymentSessionId = sessionId,
                                    orderStatus = ordStatus,
                                    amount = amount,
                                    currency = "INR",
                                    environment = "SANDBOX",
                                    isMockSandboxFallback = false
                                )
                            )
                        }
                    } else {
                        return@withContext Result.failure(
                            Exception("Cashfree Sandbox API returned HTTP ${cfDirectRes.code}: $cfDirectBody")
                        )
                    }
                } catch (cfEx: Exception) {
                    Log.e(TAG, "Direct Cashfree API call failed: ${cfEx.message}", cfEx)
                }
            }

            Log.e(TAG, "Backend server unreachable: ${lastException?.message}")
            return@withContext Result.failure(
                Exception("Cannot connect to payment backend server at $backendBaseUrl: ${lastException?.message}")
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error initiating Cashfree order: ${e.message}", e)
            Result.failure(e)
        }
    }

    /**
     * Launch Cashfree Drop Checkout / Web Checkout using official SDK in SANDBOX mode.
     */
    fun launchCheckout(
        activity: Activity,
        session: CashfreeOrderSession,
        onClientCallbackReceived: (orderId: String) -> Unit,
        onFailure: (errorMessage: String, orderId: String) -> Unit
    ) {
        try {
            val cfSession = CFSession.CFSessionBuilder()
                .setEnvironment(Environment.SANDBOX)
                .setOrderId(session.orderId)
                .setPaymentSessionID(session.paymentSessionId)
                .build()

            // Prefer native CFDropCheckoutPayment (in-app UI), fallback to CFWebCheckoutPayment
            val cfPayment = try {
                CFDropCheckoutPayment.CFDropCheckoutPaymentBuilder()
                    .setSession(cfSession)
                    .build()
            } catch (e: Exception) {
                Log.w(TAG, "CFDropCheckoutPayment build warning: ${e.message}, using WebCheckout")
                CFWebCheckoutPayment.CFWebCheckoutPaymentBuilder()
                    .setSession(cfSession)
                    .build()
            }

            val gateway = CFPaymentGatewayService.getInstance()
            gateway.setCheckoutCallback(object : CFCheckoutResponseCallback {
                override fun onPaymentVerify(orderID: String) {
                    Log.d(TAG, "SDK onPaymentVerify callback received for order: $orderID. Triggering server verification.")
                    // IMPORTANT: We DO NOT mark as PAID here.
                    // We notify the caller to perform authoritative server-side verification!
                    onClientCallbackReceived(orderID)
                }

                override fun onPaymentFailure(cfError: CFErrorResponse, orderID: String) {
                    val msg = cfError.message ?: "Cashfree payment cancelled or failed"
                    Log.w(TAG, "Cashfree onPaymentFailure: $msg, orderID: $orderID")
                    onFailure(msg, orderID)
                }
            })

            gateway.doPayment(activity, cfPayment)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to launch Cashfree checkout: ${e.message}", e)
            onFailure("Failed to launch Cashfree checkout: ${e.message}", session.orderId)
        }
    }

    /**
     * Authoritative Server-to-Server Payment Verification.
     * Never trusts client state alone.
     */
    suspend fun verifyOrderOnServer(
        orderId: String
    ): Result<CashfreeVerificationResult> = withContext(Dispatchers.IO) {
        val isCustomConfiguredHost = !backendBaseUrl.endsWith(":3000") && backendBaseUrl != "http://127.0.0.1:3000" && backendBaseUrl != "http://10.0.2.2:3000" && backendBaseUrl != "http://localhost:3000"
        val candidateHosts = if (!isCustomConfiguredHost && (backendBaseUrl.contains("127.0.0.1") || backendBaseUrl.contains("10.0.2.2") || backendBaseUrl.contains("localhost"))) {
            listOf(
                backendBaseUrl,
                "http://127.0.0.1:3000",
                "http://10.0.2.2:3000",
                "http://localhost:3000"
            ).distinct()
        } else {
            listOf(backendBaseUrl)
        }

        var lastException: Exception? = null
        for (host in candidateHosts) {
            val endpoint = "$host/api/cashfree/verify-order?order_id=${orderId}"
            try {
                val request = Request.Builder()
                    .url(endpoint)
                    .get()
                    .build()

                val response = httpClient.newCall(request).execute()
                val body = response.body?.string() ?: ""

                if (response.isSuccessful) {
                    backendBaseUrl = host
                    val json = JSONObject(body)
                    val isPaid = json.optBoolean("is_paid", false)
                    val status = json.optString("payment_status", "PENDING")
                    val txnId = json.optString("transaction_id", "CF_TXN_${orderId.takeLast(6)}")
                    val amount = json.optDouble("payment_amount", 0.0)

                    return@withContext Result.success(
                        CashfreeVerificationResult(
                            orderId = orderId,
                            isPaid = isPaid,
                            paymentStatus = status,
                            transactionId = txnId,
                            amount = amount
                        )
                    )
                } else {
                    return@withContext Result.failure(Exception("Server verification returned HTTP ${response.code}: $body"))
                }
            } catch (e: Exception) {
                lastException = e
            }
        }

        if (!isCustomConfiguredHost && SANDBOX_APP_ID.isNotBlank() && SANDBOX_SECRET_KEY.isNotBlank()) {
            try {
                Log.i(TAG, "Local server unreachable. Verifying directly with Cashfree Sandbox API.")
                val safeOrderId = URLEncoder.encode(orderId, "UTF-8")
                val verifyUrl = "$CASHFREE_SANDBOX_BASE_URL/pg/orders/$safeOrderId/payments"
                val req = Request.Builder()
                    .url(verifyUrl)
                    .addHeader("x-client-id", SANDBOX_APP_ID)
                    .addHeader("x-client-secret", SANDBOX_SECRET_KEY)
                    .addHeader("x-api-version", SANDBOX_API_VERSION)
                    .get()
                    .build()

                val res = httpClient.newCall(req).execute()
                val body = res.body?.string() ?: ""

                if (res.isSuccessful) {
                    val paymentsArray = JSONArray(body)
                    var isPaid = false
                    var successfulTxnId = "CF_TXN_${orderId.takeLast(6)}"
                    var verifiedAmount = 0.0

                    for (i in 0 until paymentsArray.length()) {
                        val p = paymentsArray.optJSONObject(i)
                        if (p?.optString("payment_status") == "SUCCESS") {
                            isPaid = true
                            successfulTxnId = p.optString("cf_payment_id", successfulTxnId)
                            verifiedAmount = p.optDouble("payment_amount", 0.0)
                            break
                        }
                    }

                    // Also check order status if payments array was empty or pending
                    if (!isPaid) {
                        val orderCheckReq = Request.Builder()
                            .url("$CASHFREE_SANDBOX_BASE_URL/pg/orders/$safeOrderId")
                            .addHeader("x-client-id", SANDBOX_APP_ID)
                            .addHeader("x-client-secret", SANDBOX_SECRET_KEY)
                            .addHeader("x-api-version", SANDBOX_API_VERSION)
                            .get()
                            .build()
                        val orderCheckRes = httpClient.newCall(orderCheckReq).execute()
                        val orderBody = orderCheckRes.body?.string() ?: ""
                        if (orderCheckRes.isSuccessful) {
                            val orderJson = JSONObject(orderBody)
                            if (orderJson.optString("order_status") == "PAID") {
                                isPaid = true
                                verifiedAmount = orderJson.optDouble("order_amount", 0.0)
                            }
                        }
                    }

                    return@withContext Result.success(
                        CashfreeVerificationResult(
                            orderId = orderId,
                            isPaid = isPaid,
                            paymentStatus = if (isPaid) "SUCCESS" else "PENDING",
                            transactionId = successfulTxnId,
                            amount = verifiedAmount,
                            verifiedBy = "Cashfree Sandbox Direct Gateway Verification"
                        )
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "Direct Cashfree verification failed: ${e.message}", e)
            }
        }

        Result.failure(Exception("Cannot connect to payment backend server at $backendBaseUrl: ${lastException?.message}"))
    }
}
