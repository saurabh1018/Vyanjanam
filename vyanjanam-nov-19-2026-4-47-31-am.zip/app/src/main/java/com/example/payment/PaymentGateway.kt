package com.example.payment

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import java.util.UUID

enum class PaymentMethodType(val displayName: String, val iconName: String) {
    INSTANT_UPI("Direct UPI (GPay, PhonePe, Paytm)", "upi"),
    WHATSAPP_UPI("Pay via WhatsApp Support", "whatsapp"),
    CASHFREE_SANDBOX("Cashfree Gateway (Sandbox / Testing)", "shield")
}

object UpiPaymentHelper {
    const val OFFICIAL_UPI_ID = "vyanjanamm@ybl"
    const val PAYEE_NAME = "Vyanjanam Pure Veg"
    const val MERCHANT_CATEGORY_CODE = "5812" // Eating Places, Restaurants, Catering

    const val PKG_GPAY = "com.google.android.apps.nbu.paisa.user"
    const val PKG_PHONEPE = "com.phonepe.app"
    const val PKG_PAYTM = "net.one97.paytm"
    const val PKG_BHIM = "in.org.npci.upiapp"
    const val PKG_CRED = "com.dreamplug.androidapp"

    /**
     * Builds standard NPCI UPI Deep Link Intent URI:
     *
     * In Android apps, if a payee VPA is a personal / non-PG-onboarded merchant VPA,
     * passing 'mc' (Merchant Category Code) and 'tr' without an acquiring payment aggregator's
     * cryptographic digital signature ('&sign=...') triggers Google Pay and PhonePe's automated
     * "Payment declined as per UPI risk policy" / "Risk threshold exceeded" anti-fraud blocks.
     *
     * In P2P (Peer-to-Peer / Direct) mode (isMerchantMode = false):
     * Generates a clean transfer URI:
     * upi://pay?pa=vyanjanamm@ybl&pn=Vyanjanam%20Pure%20Veg&am=140.00&cu=INR
     * This avoids the unsigned merchant transaction risk filter in PhonePe and Google Pay.
     */
    fun buildUpiUri(orderNumber: String, amount: Double, isMerchantMode: Boolean = false): String {
        val formattedAmount = String.format(java.util.Locale.US, "%.2f", amount)
        val cleanOrder = orderNumber.replace(Regex("[^A-Za-z0-9]"), "")
        val cleanTr = "VYAN" + System.currentTimeMillis().toString().takeLast(6) + cleanOrder.takeLast(8)

        val builder = Uri.Builder()
            .scheme("upi")
            .authority("pay")
            .appendQueryParameter("pa", OFFICIAL_UPI_ID)
            .appendQueryParameter("pn", PAYEE_NAME)

        if (isMerchantMode) {
            builder.appendQueryParameter("mc", MERCHANT_CATEGORY_CODE)
            builder.appendQueryParameter("tr", cleanTr)
            builder.appendQueryParameter("tn", "Order $cleanOrder Vyanjanam".take(50))
        }

        builder.appendQueryParameter("am", formattedAmount)
            .appendQueryParameter("cu", "INR")

        return builder.build().toString()
    }

    /**
     * Builds a universal scannable QR Code image URL for the UPI payment.
     * Scanning this QR directly in Google Pay, PhonePe, Paytm, or BHIM bypasses
     * client-side Android intent security blocks.
     */
    fun buildQrCodeUrl(orderNumber: String, amount: Double): String {
        val upiUri = buildUpiUri(orderNumber, amount, isMerchantMode = false)
        val encoded = java.net.URLEncoder.encode(upiUri, "UTF-8")
        return "https://api.qrserver.com/v1/create-qr-code/?size=300x300&margin=10&data=$encoded"
    }

    fun launchUpiPayment(
        context: Context,
        orderNumber: String,
        amount: Double,
        targetPackage: String? = null,
        isMerchantMode: Boolean = false,
        onFallback: (String) -> Unit
    ) {
        try {
            val uri = Uri.parse(buildUpiUri(orderNumber, amount, isMerchantMode))
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                targetPackage?.let { setPackage(it) }
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val pm = context.packageManager
            val activities = pm.queryIntentActivities(intent, 0)
            if (activities.isNotEmpty()) {
                if (targetPackage != null) {
                    context.startActivity(intent)
                } else {
                    val chooser = Intent.createChooser(intent, "Pay ₹${amount.toInt()} with UPI App").apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(chooser)
                }
            } else {
                if (targetPackage != null) {
                    val genericIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    val genericActivities = pm.queryIntentActivities(genericIntent, 0)
                    if (genericActivities.isNotEmpty()) {
                        val chooser = Intent.createChooser(genericIntent, "Pay ₹${amount.toInt()} with UPI App").apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(chooser)
                        return
                    }
                }

                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                clipboard?.setPrimaryClip(ClipData.newPlainText("UPI ID", OFFICIAL_UPI_ID))
                onFallback("Copied $OFFICIAL_UPI_ID to clipboard! Open your UPI app to pay ₹${amount.toInt()}.")
            }
        } catch (_: Exception) {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            clipboard?.setPrimaryClip(ClipData.newPlainText("UPI ID", OFFICIAL_UPI_ID))
            onFallback("Copied $OFFICIAL_UPI_ID to clipboard! Open your UPI app to pay ₹${amount.toInt()}.")
        }
    }

    fun buildWhatsAppConfirmationUrl(orderNumber: String, amount: Double, utr: String = ""): String {
        val utrText = if (utr.isNotBlank()) " UTR/Ref: $utr" else ""
        val message = "Hello Vyanjanam Team, I have completed payment of ₹${amount.toInt()} for Order #$orderNumber via UPI (vyanjanamm@ybl).$utrText"
        val encoded = java.net.URLEncoder.encode(message, "UTF-8")
        return "https://wa.me/${WhatsAppPaymentHelper.OFFICIAL_WHATSAPP_NUMBER}?text=$encoded"
    }
}

object WhatsAppPaymentHelper {
    const val OFFICIAL_WHATSAPP_NUMBER = "917579890049"
    const val OFFICIAL_WHATSAPP_DISPLAY = "+91 7579890049"

    fun buildWhatsAppUrl(orderNumber: String, amount: Double, purpose: String = ""): String {
        val baseText = if (purpose.isNotBlank()) {
            "Hello Vyanjanam Team, I have placed Order #$orderNumber for $purpose (₹${amount.toInt()}). Please verify my advance payment to confirm my weekly kitchen schedule."
        } else {
            "Hello Vyanjanam Team, I have placed Order #$orderNumber for ₹${amount.toInt()}. Please share payment details to complete the payment."
        }
        val encodedMessage = java.net.URLEncoder.encode(baseText, "UTF-8")
        return "https://wa.me/$OFFICIAL_WHATSAPP_NUMBER?text=$encodedMessage"
    }
}

data class PaymentRequest(
    val amount: Double,
    val orderTitle: String,
    val targetDateDisplay: String,
    val dayOfWeek: String,
    val deliverySlot: String,
    val itemsSummary: String,
    val preSelectedAddressId: String? = null,
    val hideAddressSection: Boolean = false,
    val isChefsWeeklyChoice: Boolean = false
)

data class PaymentResult(
    val isSuccess: Boolean,
    val transactionId: String,
    val paymentMethod: String,
    val amount: Double,
    val timestamp: Long = System.currentTimeMillis(),
    val errorMessage: String? = null
)

object PaymentSecurityHelper {
    fun generateTransactionId(prefix: String = "TXN"): String {
        val randomNum = (100000..999999).random()
        val randomAlpha = ('A'..'Z').shuffled().take(3).joinToString("")
        return "$prefix-${System.currentTimeMillis().toString().takeLast(6)}$randomAlpha-$randomNum"
    }

    fun maskCardNumber(number: String): String {
        val clean = number.replace(" ", "")
        if (clean.length < 4) return clean
        return "•••• •••• •••• " + clean.takeLast(4)
    }
}
