package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.MainAppScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.theme.MyApplicationTheme
import com.cashfree.pg.api.CFPaymentGatewayService
import com.example.viewmodel.KitchenViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        try {
            CFPaymentGatewayService.initialize(applicationContext)
        } catch (_: Exception) {}
        setContent {
            MyApplicationTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val viewModel: KitchenViewModel = viewModel()
                    var isSplashVisible by remember { mutableStateOf(true) }

                    Crossfade(
                        targetState = isSplashVisible,
                        animationSpec = tween(durationMillis = 400),
                        label = "splash_fade_transition"
                    ) { showSplash ->
                        if (showSplash) {
                            SplashScreen(
                                onTimeout = { isSplashVisible = false }
                            )
                        } else {
                            MainAppScreen(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
    }
}
