package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.entity.OrderEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface OrderDao {
    @Query("SELECT * FROM breakfast_orders ORDER BY targetDate ASC, id DESC")
    fun getAllOrders(): Flow<List<OrderEntity>>

    @Query("SELECT * FROM breakfast_orders ORDER BY targetDate ASC, id DESC")
    suspend fun getAllOrdersSync(): List<OrderEntity>

    @Query("SELECT * FROM breakfast_orders WHERE targetDate = :targetDate LIMIT 1")
    fun getOrderByDate(targetDate: String): Flow<OrderEntity?>

    @Query("SELECT * FROM breakfast_orders WHERE id = :id LIMIT 1")
    fun getOrderById(id: Long): Flow<OrderEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: OrderEntity): Long

    @Update
    suspend fun updateOrder(order: OrderEntity)

    @Query("UPDATE breakfast_orders SET isLocked = 1, lockState = :lockState, lockedAt = :lockedAt WHERE id = :id")
    suspend fun lockOrder(id: Long, lockedAt: Long, lockState: String = "LOCKED_BY_USER")

    @Query("UPDATE breakfast_orders SET kitchenStatus = :kitchenStatus WHERE id = :id")
    suspend fun updateKitchenStatus(id: Long, kitchenStatus: String)

    @Query("UPDATE breakfast_orders SET itemsSummary = :newSummary WHERE id = :id")
    suspend fun updateOrderItemsSummary(id: Long, newSummary: String)

    @Query("UPDATE breakfast_orders SET paymentStatus = :paymentStatus, transactionId = :transactionId, kitchenStatus = :kitchenStatus WHERE orderNumber = :orderNumber")
    suspend fun updateOrderPaymentStatus(orderNumber: String, paymentStatus: String, transactionId: String, kitchenStatus: String)

    @Query("DELETE FROM breakfast_orders WHERE id = :id")
    suspend fun deleteOrder(id: Long)

    @Query("DELETE FROM breakfast_orders")
    suspend fun deleteAllOrders()
}
