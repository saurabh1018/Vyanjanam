package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.entity.MenuDishEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MenuDishDao {
    @Query("SELECT * FROM menu_dishes ORDER BY sortOrder ASC, id ASC")
    fun getAllDishes(): Flow<List<MenuDishEntity>>

    @Query("SELECT * FROM menu_dishes ORDER BY sortOrder ASC, id ASC")
    suspend fun getAllDishesSync(): List<MenuDishEntity>

    @Query("SELECT * FROM menu_dishes WHERE id = :dishId LIMIT 1")
    suspend fun getDishById(dishId: String): MenuDishEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDishes(dishes: List<MenuDishEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDish(dish: MenuDishEntity)

    @Update
    suspend fun updateDish(dish: MenuDishEntity)

    @Query("UPDATE menu_dishes SET isAvailable = :isAvailable, updatedAt = :updatedAt WHERE id = :dishId")
    suspend fun updateAvailability(dishId: String, isAvailable: Boolean, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE menu_dishes SET name = :name, subName = :subName, updatedAt = :updatedAt WHERE id = :dishId")
    suspend fun updateDishName(dishId: String, name: String, subName: String, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE menu_dishes SET optionsJson = :optionsJson, updatedAt = :updatedAt WHERE id = :dishId")
    suspend fun updateDishOptions(dishId: String, optionsJson: String, updatedAt: Long = System.currentTimeMillis())

    @Query("DELETE FROM menu_dishes WHERE id = :dishId")
    suspend fun deleteDish(dishId: String)

    @Query("DELETE FROM menu_dishes")
    suspend fun clearAll()
}
