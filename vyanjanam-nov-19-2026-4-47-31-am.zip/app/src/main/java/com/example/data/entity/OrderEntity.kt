package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "breakfast_orders")
data class OrderEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val orderNumber: String,
    val targetDate: String,
    val dayOfWeek: String,
    val itemsSummary: String,
    val totalAmount: Double,
    val deliverySlot: String,
    val deliveryAddress: String,
    val isLocked: Boolean = false,
    val lockState: String = "OPEN",
    val lockedAt: Long = 0L,
    val paymentMethod: String = "UPI",
    val paymentStatus: String = "PAID",
    val transactionId: String = "",
    val kitchenStatus: String = "CONFIRMED",
    val deliveryLatitude: Double = 15.4989,
    val deliveryLongitude: Double = 73.8278,
    val deliveryDistanceKm: Double = 2.4,
    val locationAccuracyMeters: Float = 8.5f,
    val locationAddressFormatted: String = "",
    val customerPhoneNumber: String = "+91 98765 43210",
    val customerName: String = "Gourmet Foodie",
    val createdAt: Long = System.currentTimeMillis()
)
