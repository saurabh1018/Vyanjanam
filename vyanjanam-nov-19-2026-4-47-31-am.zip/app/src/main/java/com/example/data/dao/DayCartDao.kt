package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.entity.DayCartItemEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface DayCartDao {
    @Query("SELECT * FROM scheduled_day_items ORDER BY dayIndex ASC, id ASC")
    fun getAllDayCartItems(): Flow<List<DayCartItemEntity>>

    @Query("SELECT * FROM scheduled_day_items WHERE dayIndex = :dayIndex")
    fun getItemsForDay(dayIndex: Int): Flow<List<DayCartItemEntity>>

    @Query("SELECT * FROM scheduled_day_items")
    suspend fun getAllItemsSync(): List<DayCartItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: DayCartItemEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<DayCartItemEntity>)

    @Update
    suspend fun updateItem(item: DayCartItemEntity)

    @Query("DELETE FROM scheduled_day_items WHERE id = :id")
    suspend fun deleteItem(id: Long)

    @Query("DELETE FROM scheduled_day_items WHERE dayIndex = :dayIndex")
    suspend fun clearDay(dayIndex: Int)

    @Query("DELETE FROM scheduled_day_items")
    suspend fun clearAll()
}
