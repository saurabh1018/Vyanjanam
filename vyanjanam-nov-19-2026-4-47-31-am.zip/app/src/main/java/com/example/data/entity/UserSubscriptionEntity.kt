package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_subscription_profile")
data class UserSubscriptionEntity(
    @PrimaryKey
    val id: Int = 1,
    val userName: String = "Gourmet Foodie",
    val phoneNumber: String = "+91 98765 43210",
    val email: String = "",
    val memberTier: String = "Gold Foodie",
    val walletBalance: Double = 850.0,
    val deliveryAddress: String = "",
    val deliverySlot: String = "7:45 AM - 8:30 AM",
    val autoLockEnabled: Boolean = true,
    val enabledDaysIndices: String = "1,2,3,4,5,6",
    val lastUpdated: Long = System.currentTimeMillis()
)
