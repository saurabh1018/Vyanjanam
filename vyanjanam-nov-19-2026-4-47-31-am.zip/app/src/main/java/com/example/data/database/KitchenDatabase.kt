package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.dao.DayCartDao
import com.example.data.dao.MenuDishDao
import com.example.data.dao.OrderDao
import com.example.data.dao.SavedAddressDao
import com.example.data.dao.UserSubscriptionDao
import com.example.data.entity.DayCartItemEntity
import com.example.data.entity.MenuDishEntity
import com.example.data.entity.OrderEntity
import com.example.data.entity.SavedAddressEntity
import com.example.data.entity.UserSubscriptionEntity

@Database(
    entities = [
        OrderEntity::class,
        SavedAddressEntity::class,
        DayCartItemEntity::class,
        MenuDishEntity::class,
        UserSubscriptionEntity::class
    ],
    version = 6,
    exportSchema = false
)
abstract class KitchenDatabase : RoomDatabase() {
    abstract fun orderDao(): OrderDao
    abstract fun savedAddressDao(): SavedAddressDao
    abstract fun dayCartDao(): DayCartDao
    abstract fun menuDishDao(): MenuDishDao
    abstract fun userSubscriptionDao(): UserSubscriptionDao

    companion object {
        @Volatile
        private var INSTANCE: KitchenDatabase? = null

        fun getDatabase(context: Context): KitchenDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    KitchenDatabase::class.java,
                    "rasoi7_breakfast_kitchen.db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
