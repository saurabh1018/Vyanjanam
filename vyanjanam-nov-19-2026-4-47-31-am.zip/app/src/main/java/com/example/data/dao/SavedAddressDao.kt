package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.entity.SavedAddressEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SavedAddressDao {
    @Query("SELECT * FROM saved_addresses ORDER BY isDefault DESC, createdAt DESC")
    fun getAllSavedAddresses(): Flow<List<SavedAddressEntity>>

    @Query("SELECT * FROM saved_addresses ORDER BY isDefault DESC, createdAt DESC")
    suspend fun getAllSavedAddressesSync(): List<SavedAddressEntity>

    @Query("SELECT * FROM saved_addresses WHERE id = :id LIMIT 1")
    suspend fun getAddressById(id: String): SavedAddressEntity?

    @Query("SELECT * FROM saved_addresses WHERE isDefault = 1 LIMIT 1")
    suspend fun getDefaultAddress(): SavedAddressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAddress(address: SavedAddressEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAddresses(addresses: List<SavedAddressEntity>)

    @Update
    suspend fun updateAddress(address: SavedAddressEntity)

    @Query("DELETE FROM saved_addresses WHERE id = :id")
    suspend fun deleteAddressById(id: String)

    @Query("UPDATE saved_addresses SET isDefault = 0")
    suspend fun clearDefaultFlags()

    @Query("UPDATE saved_addresses SET isDefault = 1 WHERE id = :id")
    suspend fun setDefaultAddress(id: String)

    @androidx.room.Transaction
    suspend fun setAsDefaultAddress(id: String) {
        clearDefaultFlags()
        setDefaultAddress(id)
    }
}
