package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "scheduled_day_items")
data class DayCartItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val dayIndex: Int,
    val dishId: String,
    val dishName: String,
    val optionId: String,
    val optionLabel: String,
    val unitPrice: Double,
    val quantity: Int = 1,
    val addOnIds: String = "",
    val addOnNames: String = "",
    val addOnPrices: String = "",
    val spiceLevel: String = "Medium",
    val updatedAt: Long = System.currentTimeMillis()
)
