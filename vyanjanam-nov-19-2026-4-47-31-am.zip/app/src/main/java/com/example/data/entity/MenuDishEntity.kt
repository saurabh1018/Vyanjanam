package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "menu_dishes")
data class MenuDishEntity(
    @PrimaryKey val id: String,
    val name: String,
    val subName: String = "",
    val category: String = "Breakfast",
    val description: String = "",
    val isVegetarian: Boolean = true,
    val isAvailable: Boolean = true,
    val prepTimeMinutes: Int = 20,
    val optionsJson: String = "",
    val addOnsJson: String = "",
    val sortOrder: Int = 0,
    val updatedAt: Long = System.currentTimeMillis()
)
