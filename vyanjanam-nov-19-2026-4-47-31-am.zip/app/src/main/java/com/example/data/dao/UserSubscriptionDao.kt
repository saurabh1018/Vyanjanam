package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.entity.UserSubscriptionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UserSubscriptionDao {
    @Query("SELECT * FROM user_subscription_profile WHERE id = 1")
    fun getProfile(): Flow<List<UserSubscriptionEntity>>

    @Query("SELECT * FROM user_subscription_profile WHERE id = 1 LIMIT 1")
    suspend fun getProfileSync(): UserSubscriptionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveProfile(profile: UserSubscriptionEntity)

    @Query("UPDATE user_subscription_profile SET walletBalance = :balance WHERE id = 1")
    suspend fun updateWallet(balance: Double)

    @Query("UPDATE user_subscription_profile SET deliveryAddress = :address WHERE id = 1")
    suspend fun updateAddress(address: String)

    @Query("UPDATE user_subscription_profile SET deliverySlot = :slot WHERE id = 1")
    suspend fun updateSlot(slot: String)

    @Query("UPDATE user_subscription_profile SET autoLockEnabled = :enabled WHERE id = 1")
    suspend fun updateAutoLock(enabled: Boolean)

    @Query("UPDATE user_subscription_profile SET phoneNumber = :phone WHERE id = 1")
    suspend fun updatePhoneNumber(phone: String)

    @Query("DELETE FROM user_subscription_profile")
    suspend fun deleteAllProfiles()
}
