package com.example.data.repository

import android.content.Context
import com.example.data.dao.DayCartDao
import com.example.data.dao.MenuDishDao
import com.example.data.dao.OrderDao
import com.example.data.dao.UserSubscriptionDao
import com.example.data.entity.DayCartItemEntity
import com.example.data.entity.MenuDishEntity
import com.example.data.entity.OrderEntity
import com.example.data.entity.UserSubscriptionEntity
import com.example.data.firebase.FirebaseKitchenBackend
import com.example.model.AddOnItem
import com.example.model.KitchenMenuData
import com.example.model.MenuDish
import com.example.model.PortionOption
import com.example.model.UserProfile
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

import com.example.data.dao.SavedAddressDao
import com.example.data.entity.SavedAddressEntity

class KitchenRepository(
    val orderDao: OrderDao,
    val dayCartDao: DayCartDao? = null,
    val userSubscriptionDao: UserSubscriptionDao? = null,
    val menuDishDao: MenuDishDao? = null,
    val savedAddressDao: SavedAddressDao? = null,
    private val context: Context? = null
) {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val prefs = context?.getSharedPreferences("vyanjanam_auth_prefs", Context.MODE_PRIVATE)

    val firebaseBackend: FirebaseKitchenBackend? = context?.let { FirebaseKitchenBackend(it) }

    val firebaseSyncStatus: StateFlow<String> = firebaseBackend?.syncStatus
        ?: MutableStateFlow("Firebase Cloud Ready").asStateFlow()

    val firebaseConnected: StateFlow<Boolean> = firebaseBackend?.isConnected
        ?: MutableStateFlow(true).asStateFlow()

    val allOrders: Flow<List<OrderEntity>> = orderDao.getAllOrders()
    val allDayCartItems: Flow<List<DayCartItemEntity>>? = dayCartDao?.getAllDayCartItems()
    val allSavedAddresses: Flow<List<SavedAddressEntity>> = savedAddressDao?.getAllSavedAddresses()
        ?: MutableStateFlow(emptyList())

    // Dynamic Food Menu Flow: reactive stream from Room database
    val menuDishes: Flow<List<MenuDish>> = (menuDishDao?.getAllDishes()?.map { entities ->
        if (entities.isEmpty()) {
            KitchenMenuData.menuDishes
        } else {
            entities.map { entityToMenuDish(it) }
        }
    } ?: MutableStateFlow(KitchenMenuData.menuDishes))

    init {
        scope.launch {
            initRoomDatabaseData()
            initFirebaseSync()
        }
    }

    private suspend fun initRoomDatabaseData() {
        try {
            menuDishDao?.let { dao ->
                val existing = dao.getAllDishesSync()
                val appliedVersion = prefs?.getInt(PREF_MENU_CATALOG_VERSION, 1) ?: 1
                if (existing.isEmpty() || (prefs != null && appliedVersion < MENU_CATALOG_VERSION)) {
                    val refreshedEntities = KitchenMenuData.menuDishes.map { menuDishToEntity(it) }
                    dao.insertDishes(refreshedEntities)
                    prefs?.edit()?.putInt(PREF_MENU_CATALOG_VERSION, MENU_CATALOG_VERSION)?.apply()
                    firebaseBackend?.let { fb ->
                        for (entity in refreshedEntities) {
                            fb.syncMenuDishToCloud(entity)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            // Ignore fallback
        }
        try {
            userSubscriptionDao?.let { dao ->
                val existing = dao.getProfileSync()
                if (existing == null) {
                    dao.saveProfile(
                        UserSubscriptionEntity(
                            id = 1,
                            userName = prefs?.getString("user_name", "Gourmet Foodie") ?: "Gourmet Foodie",
                            phoneNumber = prefs?.getString("phone_number", "+91 98765 43210") ?: "+91 98765 43210",
                            walletBalance = 850.0,
                            deliveryAddress = _savedAddress.value,
                            deliverySlot = _selectedDeliverySlot.value,
                            autoLockEnabled = _autoLockEnabled.value
                        )
                    )
                } else {
                    _walletBalance.value = existing.walletBalance
                    _savedAddress.value = existing.deliveryAddress
                    _selectedDeliverySlot.value = existing.deliverySlot
                    _autoLockEnabled.value = existing.autoLockEnabled
                }
            }
        } catch (e: Exception) {
            // Fallback to in-memory/prefs
        }
        try {
            savedAddressDao?.let { dao ->
                val existingAddresses = dao.getAllSavedAddressesSync()
                if (existingAddresses.isNotEmpty()) {
                    val def = existingAddresses.find { it.isDefault } ?: existingAddresses.first()
                    _savedAddress.value = def.formattedAddress
                }
            }
        } catch (e: Exception) {
            // Fallback
        }
    }

    private suspend fun initFirebaseSync() {
        val fb = firebaseBackend ?: return
        // 1. Initial fetch from Cloud Firestore into Room
        try {
            val cloudOrders = fb.fetchOrdersFromCloud()
            for (remoteOrder in cloudOrders) {
                orderDao.insertOrder(remoteOrder)
            }
        } catch (e: Exception) {
            // Local Room fallback remains pristine
        }

        // 2. Realtime listener to sync changes from Firestore
        fb.listenToCloudOrders { remoteOrders ->
            scope.launch {
                for (order in remoteOrders) {
                    orderDao.insertOrder(order)
                }
            }
        }

        // 3. Cloud Firestore Menu sync (merges remote updates without regressing local catalog version updates)
        try {
            val cloudDishes = fb.fetchMenuDishesFromCloud()
            if (cloudDishes.isNotEmpty()) {
                val localMap = menuDishDao?.getAllDishesSync()?.associateBy { it.id }.orEmpty()
                val toUpsert = cloudDishes.filter { remote ->
                    val local = localMap[remote.id]
                    local == null || remote.updatedAt >= local.updatedAt
                }
                if (toUpsert.isNotEmpty()) {
                    menuDishDao?.insertDishes(toUpsert)
                }
            }
        } catch (e: Exception) {
            // Local fallback
        }

        fb.listenToCloudMenu { remoteDishes ->
            scope.launch {
                val localMap = menuDishDao?.getAllDishesSync()?.associateBy { it.id }.orEmpty()
                val toUpsert = remoteDishes.filter { remote ->
                    val local = localMap[remote.id]
                    local == null || remote.updatedAt >= local.updatedAt
                }
                if (toUpsert.isNotEmpty()) {
                    menuDishDao?.insertDishes(toUpsert)
                }
            }
        }
    }

    companion object {
        private const val PREF_MENU_CATALOG_VERSION = "menu_catalog_version"
        private const val MENU_CATALOG_VERSION = 2
    }

    fun getOrderByDate(targetDate: String): Flow<OrderEntity?> = orderDao.getOrderByDate(targetDate)

    suspend fun insertOrder(order: OrderEntity): Long {
        val rowId = orderDao.insertOrder(order)
        val insertedOrder = order.copy(id = rowId)
        // Sync to Firebase Cloud Firestore backend
        scope.launch {
            firebaseBackend?.syncOrderToCloud(insertedOrder)
        }
        return rowId
    }

    suspend fun lockOrder(id: Long, lockedAt: Long, lockState: String = "LOCKED_BY_USER") {
        orderDao.lockOrder(id, lockedAt, lockState)
        scope.launch {
            val all = orderDao.getAllOrdersSync()
            val updated = all.find { it.id == id }
            if (updated != null) {
                firebaseBackend?.syncOrderToCloud(updated)
            }
        }
    }

    suspend fun updateKitchenStatus(id: Long, status: String) {
        orderDao.updateKitchenStatus(id, status)
        scope.launch {
            val all = orderDao.getAllOrdersSync()
            val updated = all.find { it.id == id }
            if (updated != null) {
                firebaseBackend?.syncOrderToCloud(updated)
            }
        }
    }

    suspend fun updateOrderItemsSummary(id: Long, newSummary: String) {
        orderDao.updateOrderItemsSummary(id, newSummary)
        scope.launch {
            val all = orderDao.getAllOrdersSync()
            val updated = all.find { it.id == id }
            if (updated != null) {
                firebaseBackend?.syncOrderToCloud(updated)
            }
        }
    }

    suspend fun updateOrderPaymentStatus(
        orderNumber: String,
        paymentStatus: String,
        transactionId: String,
        kitchenStatus: String
    ) {
        orderDao.updateOrderPaymentStatus(orderNumber, paymentStatus, transactionId, kitchenStatus)
        scope.launch {
            val all = orderDao.getAllOrdersSync()
            val updated = all.find { it.orderNumber == orderNumber }
            if (updated != null) {
                firebaseBackend?.syncOrderToCloud(updated)
            }
        }
    }

    suspend fun deleteOrder(id: Long) = orderDao.deleteOrder(id)

    // Day Cart Room Database operations
    suspend fun insertDayCartItem(item: DayCartItemEntity): Long {
        return dayCartDao?.insertItem(item) ?: 0L
    }

    suspend fun deleteDayCartItem(id: Long) {
        dayCartDao?.deleteItem(id)
    }

    suspend fun clearDayCart(dayIndex: Int) {
        dayCartDao?.clearDay(dayIndex)
    }

    suspend fun syncDayCartItems(dayIndex: Int, items: List<DayCartItemEntity>) {
        dayCartDao?.clearDay(dayIndex)
        dayCartDao?.insertAll(items)
    }

    suspend fun getScheduledItemsCount(): Int {
        return dayCartDao?.getAllItemsSync()?.size ?: 0
    }

    suspend fun getOrdersCount(): Int {
        return orderDao.getAllOrdersSync().size
    }

    // User Profile & Authentication State
    private val _isLoggedIn = MutableStateFlow(prefs?.getBoolean("is_logged_in", false) ?: false)
    val isLoggedIn = _isLoggedIn.asStateFlow()

    private val _currentUser = MutableStateFlow<UserProfile?>(
        if (_isLoggedIn.value) {
            UserProfile(
                phoneNumber = prefs?.getString("phone_number", "+91 98765 43210") ?: "+91 98765 43210",
                name = prefs?.getString("user_name", "Gourmet Foodie") ?: "Gourmet Foodie",
                email = prefs?.getString("user_email", "") ?: "",
                isVerified = true,
                memberTier = prefs?.getString("member_tier", "Gold Foodie") ?: "Gold Foodie"
            )
        } else null
    )
    val currentUser = _currentUser.asStateFlow()

    fun signIn(phone: String, name: String = "Gourmet Foodie", email: String = "") {
        val user = UserProfile(
            phoneNumber = phone,
            name = if (name.isNotBlank()) name else "Gourmet Foodie",
            email = email,
            isVerified = true,
            memberTier = "Gold Foodie"
        )
        _currentUser.value = user
        _isLoggedIn.value = true
        prefs?.edit()?.apply {
            putBoolean("is_logged_in", true)
            putString("phone_number", phone)
            putString("user_name", user.name)
            putString("user_email", email)
            putString("member_tier", user.memberTier)
            apply()
        }
        scope.launch {
            userSubscriptionDao?.saveProfile(
                UserSubscriptionEntity(
                    id = 1,
                    userName = user.name,
                    phoneNumber = user.phoneNumber,
                    email = user.email,
                    walletBalance = _walletBalance.value,
                    deliveryAddress = _savedAddress.value,
                    deliverySlot = _selectedDeliverySlot.value,
                    autoLockEnabled = _autoLockEnabled.value
                )
            )
        }
        syncProfileToFirebase()
    }

    fun signInWithGoogle(
        email: String,
        password: String,
        name: String = "Google Foodie"
    ) {
        val resolvedName = if (name.isNotBlank()) name else {
            email.substringBefore("@")
                .replace(".", " ")
                .replace("_", " ")
                .split(" ")
                .joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }
        }
        val user = UserProfile(
            phoneNumber = "+91 98765 43210",
            name = resolvedName,
            email = email,
            isVerified = true,
            memberTier = "Gold Foodie"
        )
        _currentUser.value = user
        _isLoggedIn.value = true
        prefs?.edit()?.apply {
            putBoolean("is_logged_in", true)
            putString("phone_number", user.phoneNumber)
            putString("user_name", user.name)
            putString("user_email", email)
            putString("member_tier", user.memberTier)
            apply()
        }
        scope.launch {
            userSubscriptionDao?.saveProfile(
                UserSubscriptionEntity(
                    id = 1,
                    userName = user.name,
                    phoneNumber = user.phoneNumber,
                    email = user.email,
                    walletBalance = _walletBalance.value,
                    deliveryAddress = _savedAddress.value,
                    deliverySlot = _selectedDeliverySlot.value,
                    autoLockEnabled = _autoLockEnabled.value
                )
            )
            firebaseBackend?.signInWithGoogleEmailPassword(email, password)
            syncProfileToFirebase()
        }
    }

    suspend fun signInWithGoogleSuspend(
        email: String,
        password: String,
        name: String = "Google Foodie"
    ) {
        signInWithGoogle(email, password, name)
        userSubscriptionDao?.saveProfile(
            UserSubscriptionEntity(
                id = 1,
                userName = _currentUser.value?.name ?: name,
                phoneNumber = _currentUser.value?.phoneNumber ?: "+91 98765 43210",
                email = email,
                walletBalance = _walletBalance.value,
                deliveryAddress = _savedAddress.value,
                deliverySlot = _selectedDeliverySlot.value,
                autoLockEnabled = _autoLockEnabled.value
            )
        )
    }

    fun registerNewUser(
        name: String,
        email: String,
        password: String,
        phone: String,
        address: String,
        preferredSlot: String
    ) {
        val user = UserProfile(
            phoneNumber = phone,
            name = name,
            email = email,
            memberTier = "Silver Foodie",
            isVerified = true
        )
        _currentUser.value = user
        _isLoggedIn.value = true
        if (address.isNotBlank()) {
            _savedAddress.value = address
        }
        if (preferredSlot.isNotBlank()) {
            _selectedDeliverySlot.value = preferredSlot
        }
        // Add ₹100 Welcome Registration Bonus to wallet
        val newWalletBalance = _walletBalance.value + 100.0
        _walletBalance.value = newWalletBalance

        prefs?.edit()?.apply {
            putBoolean("is_logged_in", true)
            putString("user_phone", phone)
            putString("user_name", name)
            putString("user_email", email)
            putString("member_tier", "Silver Foodie")
            if (address.isNotBlank()) putString("delivery_address", address)
            if (preferredSlot.isNotBlank()) putString("delivery_slot", preferredSlot)
            apply()
        }

        scope.launch {
            userSubscriptionDao?.saveProfile(
                UserSubscriptionEntity(
                    id = 1,
                    userName = user.name,
                    phoneNumber = user.phoneNumber,
                    email = user.email,
                    walletBalance = newWalletBalance,
                    deliveryAddress = _savedAddress.value,
                    deliverySlot = _selectedDeliverySlot.value,
                    autoLockEnabled = _autoLockEnabled.value
                )
            )
            firebaseBackend?.signInWithGoogleEmailPassword(email, password)
            syncProfileToFirebase()
        }
    }

    fun signOut() {
        _currentUser.value = null
        _isLoggedIn.value = false
        prefs?.edit()?.apply {
            putBoolean("is_logged_in", false)
            apply()
        }
    }

    /**
     * Permanently deletes user account, orders, subscription, and cached credentials
     * both locally (Room + SharedPreferences) and from Firebase Cloud.
     */
    suspend fun deleteUserAccountAndData(): Boolean {
        val phone = _currentUser.value?.phoneNumber

        // 1. Delete from Firebase Cloud
        firebaseBackend?.deleteUserAccountAndData(phone)

        // 2. Clear local Room database tables
        userSubscriptionDao?.deleteAllProfiles()
        orderDao?.deleteAllOrders()

        // 3. Wipe all SharedPreferences
        prefs?.edit()?.clear()?.apply()

        // 4. Reset in-memory state
        _currentUser.value = null
        _isLoggedIn.value = false
        _walletBalance.value = 0.0
        _savedAddress.value = ""
        _selectedDeliverySlot.value = "7:45 AM - 8:30 AM"

        return true
    }

    fun updateProfile(name: String, email: String) {
        val current = _currentUser.value ?: return
        val updated = current.copy(name = name, email = email)
        _currentUser.value = updated
        prefs?.edit()?.apply {
            putString("user_name", name)
            putString("user_email", email)
            apply()
        }
        scope.launch {
            userSubscriptionDao?.let { dao ->
                val p = dao.getProfileSync() ?: UserSubscriptionEntity()
                dao.saveProfile(p.copy(userName = name, email = email))
            }
        }
        syncProfileToFirebase()
    }

    // User account & wallet state
    private val _walletBalance = MutableStateFlow(850.0)
    val walletBalance = _walletBalance.asStateFlow()

    private val _savedAddress = MutableStateFlow(
        prefs?.getString("delivery_address", "") ?: ""
    )
    val savedAddress = _savedAddress.asStateFlow()

    private val _selectedDeliverySlot = MutableStateFlow("7:45 AM - 8:30 AM")
    val selectedDeliverySlot = _selectedDeliverySlot.asStateFlow()

    private val _autoLockEnabled = MutableStateFlow(true)
    val autoLockEnabled = _autoLockEnabled.asStateFlow()

    fun deductWallet(amount: Double): Boolean {
        if (_walletBalance.value >= amount) {
            _walletBalance.value -= amount
            scope.launch {
                userSubscriptionDao?.updateWallet(_walletBalance.value)
            }
            syncProfileToFirebase()
            return true
        }
        return false
    }

    fun topUpWallet(amount: Double) {
        _walletBalance.value += amount
        scope.launch {
            userSubscriptionDao?.updateWallet(_walletBalance.value)
        }
        syncProfileToFirebase()
    }

    fun updateAddress(newAddress: String) {
        _savedAddress.value = newAddress
        prefs?.edit()?.putString("delivery_address", newAddress)?.apply()
        scope.launch {
            userSubscriptionDao?.updateAddress(newAddress)
        }
        syncProfileToFirebase()
    }

    suspend fun addSavedAddress(address: SavedAddressEntity) {
        savedAddressDao?.let { dao ->
            if (address.isDefault) {
                dao.clearDefaultFlags()
                _savedAddress.value = address.formattedAddress
                userSubscriptionDao?.updateAddress(address.formattedAddress)
            }
            dao.insertAddress(address)
        }
    }

    suspend fun updateSavedAddress(address: SavedAddressEntity) {
        savedAddressDao?.let { dao ->
            if (address.isDefault) {
                dao.clearDefaultFlags()
                _savedAddress.value = address.formattedAddress
                userSubscriptionDao?.updateAddress(address.formattedAddress)
            }
            dao.updateAddress(address)
        }
    }

    suspend fun deleteSavedAddress(id: String) {
        savedAddressDao?.let { dao ->
            val toDelete = dao.getAddressById(id)
            dao.deleteAddressById(id)
            if (toDelete?.isDefault == true) {
                val remaining = dao.getAllSavedAddressesSync()
                if (remaining.isNotEmpty()) {
                    val nextDef = remaining.first()
                    dao.setDefaultAddress(nextDef.id)
                    _savedAddress.value = nextDef.formattedAddress
                    userSubscriptionDao?.updateAddress(nextDef.formattedAddress)
                }
            }
        }
    }

    suspend fun setDefaultSavedAddress(id: String) {
        savedAddressDao?.let { dao ->
            dao.clearDefaultFlags()
            dao.setDefaultAddress(id)
            val selected = dao.getAddressById(id)
            if (selected != null) {
                _savedAddress.value = selected.formattedAddress
                userSubscriptionDao?.updateAddress(selected.formattedAddress)
            }
        }
    }

    fun updatePhoneNumber(newPhone: String) {
        val curr = _currentUser.value
        if (curr != null) {
            val updated = curr.copy(phoneNumber = newPhone)
            _currentUser.value = updated
        }
        prefs?.edit()?.putString("phone_number", newPhone)?.apply()
        scope.launch {
            userSubscriptionDao?.updatePhoneNumber(newPhone)
        }
        syncProfileToFirebase()
    }

    fun updateDeliverySlot(slot: String) {
        _selectedDeliverySlot.value = slot
        scope.launch {
            userSubscriptionDao?.updateSlot(slot)
        }
        syncProfileToFirebase()
    }

    fun setAutoLockEnabled(enabled: Boolean) {
        _autoLockEnabled.value = enabled
        scope.launch {
            userSubscriptionDao?.updateAutoLock(enabled)
        }
        syncProfileToFirebase()
    }

    fun syncProfileToFirebase() {
        scope.launch {
            val user = _currentUser.value ?: UserProfile(
                phoneNumber = "+91 98765 43210",
                name = "Gourmet Foodie",
                isVerified = true
            )
            firebaseBackend?.syncProfileToCloud(
                profile = user,
                walletBalance = _walletBalance.value,
                deliveryAddress = _savedAddress.value,
                deliverySlot = _selectedDeliverySlot.value,
                autoLockEnabled = _autoLockEnabled.value,
                enabledDays = setOf(1, 2, 3, 4, 5, 6)
            )
        }
    }

    suspend fun manualSyncFirebase(): String {
        return try {
            val fb = firebaseBackend ?: return "Firebase Backend offline"
            val orders = orderDao.getAllOrdersSync()
            var count = 0
            for (o in orders) {
                if (fb.syncOrderToCloud(o)) count++
            }
            syncProfileToFirebase()
            "Synced $count orders with Firebase Cloud Firestore"
        } catch (e: Exception) {
            "Cloud sync deferred: ${e.message}"
        }
    }

    // Dynamic Food Menu Management
    suspend fun updateDishAvailability(dishId: String, isAvailable: Boolean) {
        menuDishDao?.updateAvailability(dishId, isAvailable)
        val updated = menuDishDao?.getDishById(dishId)
        if (updated != null) {
            scope.launch {
                firebaseBackend?.syncMenuDishToCloud(updated)
            }
        }
    }

    suspend fun updateDishName(dishId: String, name: String, subName: String) {
        menuDishDao?.updateDishName(dishId, name, subName)
        val updated = menuDishDao?.getDishById(dishId)
        if (updated != null) {
            scope.launch {
                firebaseBackend?.syncMenuDishToCloud(updated)
            }
        }
    }

    suspend fun updateDishPrices(dishId: String, newOptions: List<com.example.model.PortionOption>) {
        val optionsJson = optionsToJson(newOptions)
        val existing = menuDishDao?.getDishById(dishId)
        if (existing == null) {
            val template = KitchenMenuData.menuDishes.find { it.id == dishId }
            if (template != null) {
                val entity = menuDishToEntity(template.copy(options = newOptions))
                menuDishDao?.insertDish(entity)
            }
        } else {
            menuDishDao?.updateDishOptions(dishId, optionsJson)
        }
        val updated = menuDishDao?.getDishById(dishId)
        if (updated != null) {
            scope.launch {
                firebaseBackend?.syncMenuDishToCloud(updated)
            }
        }
    }

    suspend fun addMenuDish(dish: MenuDish) {
        val entity = menuDishToEntity(dish)
        menuDishDao?.insertDish(entity)
        scope.launch {
            firebaseBackend?.syncMenuDishToCloud(entity)
        }
    }

    suspend fun removeMenuDish(dishId: String) {
        menuDishDao?.deleteDish(dishId)
        scope.launch {
            firebaseBackend?.deleteMenuDishFromCloud(dishId)
        }
    }

    private fun entityToMenuDish(entity: MenuDishEntity): MenuDish {
        val template = KitchenMenuData.menuDishes.find { it.id == entity.id }
        val options = if (entity.optionsJson.isNotBlank()) {
            parseOptionsJson(entity.optionsJson)
        } else {
            template?.options ?: parseOptionsJson("")
        }

        return template?.copy(
            name = entity.name.ifBlank { template.name },
            subName = entity.subName.ifBlank { template.subName },
            category = entity.category.ifBlank { template.category },
            description = entity.description.ifBlank { template.description },
            isVegetarian = entity.isVegetarian,
            isAvailable = entity.isAvailable,
            options = options,
            prepTimeMinutes = entity.prepTimeMinutes,
            sortOrder = entity.sortOrder
        ) ?: MenuDish(
            id = entity.id,
            name = entity.name,
            subName = entity.subName,
            category = entity.category,
            description = entity.description,
            isVegetarian = entity.isVegetarian,
            isAvailable = entity.isAvailable,
            options = options,
            addOns = KitchenMenuData.commonAddOns,
            prepTimeMinutes = entity.prepTimeMinutes,
            sortOrder = entity.sortOrder
        )
    }

    private fun menuDishToEntity(dish: MenuDish): MenuDishEntity {
        return MenuDishEntity(
            id = dish.id,
            name = dish.name,
            subName = dish.subName,
            category = dish.category,
            description = dish.description,
            isVegetarian = dish.isVegetarian,
            isAvailable = dish.isAvailable,
            prepTimeMinutes = dish.prepTimeMinutes,
            optionsJson = optionsToJson(dish.options),
            addOnsJson = "",
            sortOrder = dish.sortOrder
        )
    }

    private fun parseOptionsJson(json: String, fallbackPrice: Double = 80.0): List<com.example.model.PortionOption> {
        if (json.isBlank()) {
            return listOf(
                com.example.model.PortionOption("opt_reg", "Standard Serving", 2, fallbackPrice, "Freshly prepared"),
                com.example.model.PortionOption("opt_jumbo", "Super Value Combo", 4, (fallbackPrice * 1.6).coerceAtLeast(fallbackPrice + 30.0), "Super Value Meal")
            )
        }
        return try {
            val arr = org.json.JSONArray(json)
            val list = mutableListOf<com.example.model.PortionOption>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    com.example.model.PortionOption(
                        id = obj.optString("id", "opt_$i"),
                        label = obj.optString("label", "Standard"),
                        pieceCount = obj.optInt("pieceCount", 1),
                        price = obj.optDouble("price", fallbackPrice),
                        description = obj.optString("description", "")
                    )
                )
            }
            if (list.isEmpty()) {
                listOf(com.example.model.PortionOption("opt_reg", "Standard Serving", 2, fallbackPrice, "Freshly prepared"))
            } else list
        } catch (e: Exception) {
            listOf(com.example.model.PortionOption("opt_reg", "Standard Serving", 2, fallbackPrice, "Freshly prepared"))
        }
    }

    private fun optionsToJson(options: List<com.example.model.PortionOption>): String {
        return try {
            val arr = org.json.JSONArray()
            for (opt in options) {
                val obj = org.json.JSONObject().apply {
                    put("id", opt.id)
                    put("label", opt.label)
                    put("pieceCount", opt.pieceCount)
                    put("price", opt.price)
                    put("description", opt.description)
                }
                arr.put(obj)
            }
            arr.toString()
        } catch (e: Exception) {
            ""
        }
    }
}
