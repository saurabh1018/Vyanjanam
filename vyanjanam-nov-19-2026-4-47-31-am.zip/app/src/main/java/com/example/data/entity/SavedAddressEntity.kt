package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "saved_addresses")
data class SavedAddressEntity(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val label: String = "Home", // Home, Work, Other
    val formattedAddress: String,
    val flatDoorNumber: String = "",
    val buildingSociety: String = "",
    val street: String = "",
    val area: String = "",
    val landmark: String = "",
    val pincode: String = "",
    val latitude: Double = 15.4989,
    val longitude: Double = 73.8278,
    val distanceKm: Double = 2.4,
    val deliveryZone: String = "Zone A",
    val isDefault: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
