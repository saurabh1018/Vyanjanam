package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeliveryDining
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.OutdoorGrill
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.OrderEntity
import com.example.model.DayScheduleInfo
import com.example.model.ScheduleHelper
import com.example.ui.theme.HerbGreen
import com.example.ui.theme.SaffronLight
import com.example.ui.theme.SaffronPrimary

/**
 * 4 Standard Kitchen Preparation Stages:
 * Scheduled -> Preparing -> Ready and Packed -> Order Delivered
 */
enum class KitchenPrepStatus(
    val label: String,
    val color: Color,
    val bgColor: Color,
    val nextActionLabel: String?,
    val nextStatus: String?
) {
    SCHEDULED(
        label = "Scheduled",
        color = Color(0xFF2563EB),
        bgColor = Color(0xFFEFF6FF),
        nextActionLabel = "Start Preparing ➔",
        nextStatus = "Preparing"
    ),
    PREPARING(
        label = "Preparing",
        color = Color(0xFFD97706),
        bgColor = Color(0xFFFFFBEB),
        nextActionLabel = "Ready and Packed ➔",
        nextStatus = "Ready and Packed"
    ),
    READY_AND_PACKED(
        label = "Ready and Packed",
        color = Color(0xFF7C3AED),
        bgColor = Color(0xFFF5F3FF),
        nextActionLabel = "Order Delivered ➔",
        nextStatus = "Order Delivered"
    ),
    DELIVERED(
        label = "Order Delivered",
        color = Color(0xFF059669),
        bgColor = Color(0xFFECFDF5),
        nextActionLabel = null,
        nextStatus = null
    );

    companion object {
        fun fromKitchenStatus(status: String): KitchenPrepStatus {
            val upper = status.uppercase().trim()
            return when {
                upper.contains("PREPAR") || upper.contains("COOK") -> PREPARING
                upper.contains("READY") || upper.contains("PACK") -> READY_AND_PACKED
                upper.contains("DELIVER") || upper.contains("DISPATCH") || upper.contains("COMPLETE") -> DELIVERED
                else -> SCHEDULED
            }
        }
    }
}

data class ParsedOrderItem(
    val quantity: Int,
    val dishName: String,
    val portion: String
)

data class AggregateDishCount(
    val dishName: String,
    val totalPortions: Int
)

object KdsOrderHelper {
    fun parseOrderItems(itemsSummary: String): List<ParsedOrderItem> {
        if (itemsSummary.isBlank()) return emptyList()
        val rawList = itemsSummary.split(",")
        return rawList.mapNotNull { itemStr ->
            val trimmed = itemStr.trim()
            if (trimmed.isBlank()) null
            else {
                val match = Regex("""(\d+)x\s+([^(]+)(?:\(([^)]+)\))?""").find(trimmed)
                if (match != null) {
                    val qty = match.groupValues[1].toIntOrNull() ?: 1
                    val name = match.groupValues[2].trim()
                    val portion = match.groupValues.getOrNull(3)?.trim() ?: ""
                    ParsedOrderItem(qty, name, portion)
                } else {
                    ParsedOrderItem(1, trimmed, "")
                }
            }
        }
    }

    fun aggregateDishes(orders: List<OrderEntity>): List<AggregateDishCount> {
        val dishMap = mutableMapOf<String, Int>()

        orders.forEach { order ->
            val items = parseOrderItems(order.itemsSummary)
            items.forEach { item ->
                dishMap[item.dishName] = (dishMap[item.dishName] ?: 0) + item.quantity
            }
        }

        return dishMap.entries.map { (name, total) ->
            AggregateDishCount(
                dishName = name,
                totalPortions = total
            )
        }.sortedByDescending { it.totalPortions }
    }
}

/**
 * Tablet-Friendly Kitchen Display System (KDS) View
 * Supports advance orders placed 1 day before delivery.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun KitchenDisplaySystemView(
    orders: List<OrderEntity>,
    onUpdateOrderStatus: (Long, String) -> Unit,
    onLockOrder: (Long) -> Unit,
    onVerifyPayment: ((Long, String) -> Unit)? = null,
    onRotateChefsDish: ((Long, String) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val isDark = isSystemInDarkTheme()
    val days = remember { ScheduleHelper.generate7Days() }
    val todayInfo = remember(days) { days.firstOrNull { it.isToday } ?: days.first() }
    val tomorrowInfo = remember(days) { days.firstOrNull { it.isTomorrow } ?: days.getOrElse(1) { days.first() } }

    // Date Filter State: Default to Tomorrow for advance preparation planning
    var selectedDateFilter by remember { mutableStateOf("TOMORROW") }
    var selectedSlotFilter by remember { mutableStateOf("ALL") }
    var selectedPrepStatusFilter by remember { mutableStateOf("ALL") }
    var searchQuery by remember { mutableStateOf("") }
    var showAdvancePlanningBoard by remember { mutableStateOf(true) }

    // Filter orders by date
    val dateFilteredOrders = remember(orders, selectedDateFilter, days) {
        when (selectedDateFilter) {
            "ALL" -> orders
            "TOMORROW" -> orders.filter { o ->
                o.targetDate.contains("Tomorrow", ignoreCase = true) ||
                    o.targetDate.contains(tomorrowInfo.fullDateString, ignoreCase = true) ||
                    o.targetDate.contains(tomorrowInfo.dateDisplay, ignoreCase = true) ||
                    o.dayOfWeek.equals(tomorrowInfo.dayOfWeek, ignoreCase = true)
            }
            "TODAY" -> orders.filter { o ->
                o.targetDate.contains("Today", ignoreCase = true) ||
                    o.targetDate.contains(todayInfo.fullDateString, ignoreCase = true) ||
                    o.targetDate.contains(todayInfo.dateDisplay, ignoreCase = true) ||
                    o.dayOfWeek.equals(todayInfo.dayOfWeek, ignoreCase = true)
            }
            else -> orders.filter { o ->
                o.targetDate.contains(selectedDateFilter, ignoreCase = true) ||
                    o.dayOfWeek.equals(selectedDateFilter, ignoreCase = true)
            }
        }
    }

    // Daily Summary Calculations for the selected delivery date
    val totalOrdersForDate = dateFilteredOrders.size
    val aggregatedDishes = remember(dateFilteredOrders) { KdsOrderHelper.aggregateDishes(dateFilteredOrders) }
    val totalMealCount = remember(aggregatedDishes) { aggregatedDishes.sumOf { it.totalPortions } }

    val scheduledCount = dateFilteredOrders.count { KitchenPrepStatus.fromKitchenStatus(it.kitchenStatus) == KitchenPrepStatus.SCHEDULED }
    val preparingCount = dateFilteredOrders.count { KitchenPrepStatus.fromKitchenStatus(it.kitchenStatus) == KitchenPrepStatus.PREPARING }
    val readyPackedCount = dateFilteredOrders.count { KitchenPrepStatus.fromKitchenStatus(it.kitchenStatus) == KitchenPrepStatus.READY_AND_PACKED }
    val deliveredCount = dateFilteredOrders.count { KitchenPrepStatus.fromKitchenStatus(it.kitchenStatus) == KitchenPrepStatus.DELIVERED }
    val pendingPrepCount = scheduledCount + preparingCount

    // Apply Slot, Prep Status & Search Filters
    val displayOrders = remember(dateFilteredOrders, selectedSlotFilter, selectedPrepStatusFilter, searchQuery) {
        dateFilteredOrders.filter { o ->
            val matchesSlot = if (selectedSlotFilter == "ALL") true else o.deliverySlot.contains(selectedSlotFilter, ignoreCase = true)
            val currentPrepStatus = KitchenPrepStatus.fromKitchenStatus(o.kitchenStatus)
            val matchesPrepStatus = if (selectedPrepStatusFilter == "ALL") true else currentPrepStatus.name == selectedPrepStatusFilter
            val matchesSearch = if (searchQuery.isBlank()) true else {
                o.orderNumber.contains(searchQuery, ignoreCase = true) ||
                    o.customerName.contains(searchQuery, ignoreCase = true) ||
                    o.itemsSummary.contains(searchQuery, ignoreCase = true) ||
                    o.deliveryAddress.contains(searchQuery, ignoreCase = true)
            }
            matchesSlot && matchesPrepStatus && matchesSearch
        }
    }

    // Group filtered orders by Delivery Slot for organized kitchen pacing
    val ordersBySlot = remember(displayOrders) {
        displayOrders.groupBy { it.deliverySlot }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. DATE FILTER TABS (Today, Tomorrow / Advance, Custom Days, All)
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Delivery Date Schedule Filter",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Tomorrow (Advance Orders Button - Primary Focus)
                    FilterChip(
                        selected = selectedDateFilter == "TOMORROW",
                        onClick = { selectedDateFilter = "TOMORROW" },
                        label = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Tomorrow (${tomorrowInfo.dateDisplay})", fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.width(4.dp))
                                Surface(
                                    color = if (selectedDateFilter == "TOMORROW") Color(0xFFFEF08A) else SaffronPrimary.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "ADVANCE PREP",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (selectedDateFilter == "TOMORROW") Color(0xFF854D0E) else SaffronPrimary,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF0B2046),
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("kds_filter_tomorrow")
                    )

                    // Today
                    FilterChip(
                        selected = selectedDateFilter == "TODAY",
                        onClick = { selectedDateFilter = "TODAY" },
                        label = { Text("Today (${todayInfo.dateDisplay})", fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF0B2046),
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("kds_filter_today")
                    )

                    // Remaining Rolling Days (Days 2 to 6)
                    days.drop(2).forEach { day ->
                        FilterChip(
                            selected = selectedDateFilter == day.fullDateString,
                            onClick = { selectedDateFilter = day.fullDateString },
                            label = { Text("${day.shortDay} (${day.dateDisplay})") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF0B2046),
                                selectedLabelColor = Color.White
                            )
                        )
                    }

                    // All Dates
                    FilterChip(
                        selected = selectedDateFilter == "ALL",
                        onClick = { selectedDateFilter = "ALL" },
                        label = { Text("All Dates (${orders.size})") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF0B2046),
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("kds_filter_all_dates")
                    )
                }
            }
        }

        // 2. DAILY SUMMARY & ADVANCE PLANNING BOARD
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("kds_advance_planning_card"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isDark) Color(0xFF1E293B) else Color(0xFFF8FAFC)
                ),
                border = BorderStroke(1.dp, if (isDark) Color(0xFF334155) else Color(0xFFCBD5E1))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.CalendarMonth,
                                    contentDescription = null,
                                    tint = SaffronPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = when (selectedDateFilter) {
                                        "TOMORROW" -> "Tomorrow's Advance Planning (${tomorrowInfo.dateDisplay})"
                                        "TODAY" -> "Today's Kitchen Schedule (${todayInfo.dateDisplay})"
                                        "ALL" -> "All Scheduled Orders Planning"
                                        else -> "Advance Planning for $selectedDateFilter"
                                    },
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = if (isDark) Color.White else Color(0xFF0B2046)
                                )
                            }
                            Text(
                                text = "$totalOrdersForDate scheduled orders • $totalMealCount total breakfast items",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        TextButton(
                            onClick = { showAdvancePlanningBoard = !showAdvancePlanningBoard },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = if (showAdvancePlanningBoard) "Hide Prep Board" else "Show Prep Board",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = SaffronPrimary
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = if (showAdvancePlanningBoard) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                contentDescription = null,
                                tint = SaffronPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Summary KPI Badges
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        KdsSummaryPill("Scheduled", "$scheduledCount", Color(0xFF2563EB), Color(0xFFEFF6FF))
                        KdsSummaryPill("Preparing", "$preparingCount", Color(0xFFD97706), Color(0xFFFFFBEB))
                        KdsSummaryPill("Ready & Packed", "$readyPackedCount", Color(0xFF7C3AED), Color(0xFFF5F3FF))
                        KdsSummaryPill("Order Delivered", "$deliveredCount", Color(0xFF059669), Color(0xFFECFDF5))
                    }

                    // Expandable Advance Item Quantities Board (Recipes strictly excluded as per requirements)
                    AnimatedVisibility(visible = showAdvancePlanningBoard) {
                        Column(modifier = Modifier.padding(top = 12.dp)) {
                            HorizontalDivider(color = if (isDark) Color(0xFF334155) else Color(0xFFE2E8F0))
                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Preparation Board (Menu Items & Quantities):",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Total Dishes: ${aggregatedDishes.size}",
                                    fontSize = 10.5.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))

                            if (aggregatedDishes.isEmpty()) {
                                Text(
                                    text = "No items scheduled for preparation on this date.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            } else {
                                FlowRow(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    aggregatedDishes.forEach { item ->
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = if (isDark) Color(0xFF0F172A) else Color.White,
                                            border = BorderStroke(1.dp, if (isDark) Color(0xFF334155) else Color(0xFFCBD5E1))
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(26.dp)
                                                        .clip(CircleShape)
                                                        .background(SaffronPrimary.copy(alpha = 0.15f)),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(
                                                        text = "${item.totalPortions}",
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.ExtraBold,
                                                        color = SaffronPrimary
                                                    )
                                                }
                                                Spacer(modifier = Modifier.width(8.dp))
                                                Text(
                                                    text = item.dishName,
                                                    fontSize = 12.5.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3. SEARCH & SECONDARY FILTERS (Delivery Slot & Prep Status)
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Search Input
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search by Order #, Customer, Dish, Address...", fontSize = 12.sp) },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = Color(0xFF64748B),
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    trailingIcon = {
                        if (searchQuery.isNotBlank()) {
                            IconButton(
                                onClick = { searchQuery = "" },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                            }
                        }
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = if (isDark) MaterialTheme.colorScheme.surface else Color.White,
                        unfocusedContainerColor = if (isDark) MaterialTheme.colorScheme.surface else Color.White,
                        focusedBorderColor = SaffronPrimary
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("kds_search_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Delivery Slot Filter Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Slot:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(end = 4.dp)
                    )
                    listOf(
                        "ALL" to "All Slots",
                        "7:00 AM" to "7:00 - 7:45 AM",
                        "7:45 AM" to "7:45 - 8:30 AM",
                        "8:30 AM" to "8:30 - 9:15 AM"
                    ).forEach { (key, label) ->
                        FilterChip(
                            selected = selectedSlotFilter == key,
                            onClick = { selectedSlotFilter = key },
                            label = { Text(label, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF0B2046),
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Prep Status Filter Tabs
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Status:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(end = 4.dp)
                    )
                    listOf(
                        "ALL" to "All Statuses",
                        "SCHEDULED" to "Scheduled ($scheduledCount)",
                        "PREPARING" to "Preparing ($preparingCount)",
                        "READY_AND_PACKED" to "Ready & Packed ($readyPackedCount)",
                        "DELIVERED" to "Delivered ($deliveredCount)"
                    ).forEach { (key, label) ->
                        FilterChip(
                            selected = selectedPrepStatusFilter == key,
                            onClick = { selectedPrepStatusFilter = key },
                            label = { Text(label, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF0B2046),
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }
        }

        // 4. ORDERS LIST ORGANIZED BY DELIVERY SLOT
        if (displayOrders.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isDark) MaterialTheme.colorScheme.surface else Color.White
                    ),
                    border = BorderStroke(1.dp, if (isDark) MaterialTheme.colorScheme.outlineVariant else Color(0xFFE2E8F0))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.FilterList,
                            contentDescription = null,
                            tint = Color(0xFF94A3B8),
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "No orders found for this schedule filter",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Try switching dates or clearing slot/status filters.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            // Group and display by delivery slot for kitchen timing
            ordersBySlot.forEach { (slot, ordersInSlot) ->
                item {
                    Surface(
                        color = SaffronPrimary.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "⏰ Delivery Slot: $slot",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 13.sp,
                                color = SaffronPrimary
                            )
                            Text(
                                text = "${ordersInSlot.size} orders",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = SaffronPrimary
                            )
                        }
                    }
                }

                items(ordersInSlot, key = { "${it.id}_${it.orderNumber}" }) { order ->
                    KdsOrderCard(
                        order = order,
                        onUpdateKitchenStatus = { newStatus -> onUpdateOrderStatus(order.id, newStatus) },
                        onLockOrder = { onLockOrder(order.id) },
                        onVerifyPayment = onVerifyPayment,
                        onRotateChefsDish = onRotateChefsDish
                    )
                }
            }
        }
    }
}

@Composable
private fun KdsSummaryPill(
    label: String,
    count: String,
    textColor: Color,
    bgColor: Color
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = bgColor,
        border = BorderStroke(1.dp, textColor.copy(alpha = 0.35f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = count,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 12.sp,
                color = textColor
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                fontWeight = FontWeight.Medium,
                fontSize = 11.sp,
                color = textColor
            )
        }
    }
}

/**
 * Tablet-Friendly Order Card for Vyanjanam Kitchen Staff
 * Strictly separates:
 * 1. Kitchen Preparation Status (Scheduled -> Preparing -> Ready for Packing -> Packed -> Ready for Dispatch)
 * 2. Payment Status (Reference Only for staff; Admin-controlled verification)
 * 3. Delivery Details (Address and delivery slot for tiffin packing)
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun KdsOrderCard(
    order: OrderEntity,
    onUpdateKitchenStatus: (String) -> Unit,
    onLockOrder: () -> Unit,
    onVerifyPayment: ((Long, String) -> Unit)? = null,
    onRotateChefsDish: ((Long, String) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val isDark = isSystemInDarkTheme()
    val prepStatus = KitchenPrepStatus.fromKitchenStatus(order.kitchenStatus)
    val parsedItems = remember(order.itemsSummary) { KdsOrderHelper.parseOrderItems(order.itemsSummary) }
    val isPaid = order.paymentStatus.equals("PAID", ignoreCase = true)

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isDark) MaterialTheme.colorScheme.surface else Color.White
        ),
        border = BorderStroke(
            1.5.dp,
            prepStatus.color.copy(alpha = 0.45f)
        ),
        modifier = modifier
            .fillMaxWidth()
            .testTag("kds_order_${order.orderNumber}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Row 1: Order ID, Delivery Target Date & Lock Indicator
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "#${order.orderNumber}",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace
                        ),
                        color = if (isDark) SaffronLight else Color(0xFF0B2046)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        color = SaffronPrimary.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "${order.targetDate} (${order.dayOfWeek})",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            ),
                            color = SaffronPrimary,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }

                // Payment Status Badge (REFERENCE ONLY for Kitchen Staff)
                Surface(
                    color = if (isPaid) Color(0xFFECFDF5) else Color(0xFFFEF3C7),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, if (isPaid) Color(0xFFA7F3D0) else Color(0xFFFDE68A))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isPaid) "PAID ✓" else "PAYMENT PENDING ⏳",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.5.sp
                            ),
                            color = if (isPaid) Color(0xFF047857) else Color(0xFFB45309)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Row 2: Customer Name, Delivery Slot & Address
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = order.customerName,
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Text(
                    text = "⏰ ${order.deliverySlot}",
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                    color = SaffronPrimary
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Delivery Address for Tiffin Packing
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = null,
                    tint = Color(0xFF64748B),
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = order.deliveryAddress,
                    style = MaterialTheme.typography.bodySmall,
                    fontSize = 11.5.sp,
                    color = Color(0xFF64748B)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            val isChefsChoice = order.itemsSummary.contains("Chef's Weekly Choice", ignoreCase = true) ||
                    order.paymentMethod.contains("Chef's Weekly Choice", ignoreCase = true)

            if (isChefsChoice) {
                Surface(
                    color = Color(0xFFF5F3FF),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, Color(0xFFDDD6FE)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp)
                        .testTag("kds_chefs_choice_badge_${order.orderNumber}")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val isJumbo = order.itemsSummary.contains("Jumbo", ignoreCase = true) ||
                                order.paymentMethod.contains("Jumbo", ignoreCase = true)
                        val plateBadge = if (isJumbo) "Jumbo Plate" else "Regular Plate"

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("👨‍🍳", fontSize = 15.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "Chef's Weekly Choice",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.ExtraBold),
                                        color = Color(0xFF7C3AED)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = if (isJumbo) Color(0xFFFEF3C7) else Color(0xFFEDE9FE)
                                    ) {
                                        Text(
                                            text = plateBadge.uppercase(),
                                            fontSize = 8.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isJumbo) Color(0xFFB45309) else Color(0xFF7C3AED),
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = "Round-robin rotation from listed menu",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.5.sp),
                                    color = Color(0xFF8B5CF6)
                                )
                            }
                        }

                        if (onRotateChefsDish != null) {
                            Button(
                                onClick = { onRotateChefsDish(order.id, order.itemsSummary) },
                                shape = RoundedCornerShape(6.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF7C3AED),
                                    contentColor = Color.White
                                ),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier
                                    .height(30.dp)
                                    .testTag("kds_rotate_dish_btn_${order.orderNumber}")
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Rotate Dish", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // Row 3: Food Items & Quantities
            Surface(
                color = if (isDark) MaterialTheme.colorScheme.surfaceVariant else Color(0xFFF8FAFC),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, if (isDark) MaterialTheme.colorScheme.outlineVariant else Color(0xFFE2E8F0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = "Food Items to Prepare:",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    if (parsedItems.isEmpty()) {
                        Text(
                            text = order.itemsSummary,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    } else {
                        parsedItems.forEach { item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = SaffronPrimary.copy(alpha = 0.15f)
                                    ) {
                                        Text(
                                            text = "${item.quantity}x",
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 11.sp,
                                            color = SaffronPrimary,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = item.dishName,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                                if (item.portion.isNotBlank()) {
                                    Text(
                                        text = item.portion,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Row 4: Kitchen Preparation Status Pipeline (4 Stages)
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Kitchen Preparation Status:",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = prepStatus.bgColor,
                        border = BorderStroke(1.dp, prepStatus.color)
                    ) {
                        Text(
                            text = "Current: ${prepStatus.label}",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 11.sp,
                            color = prepStatus.color,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Interactive 4-Stage Status Bar for Kitchen Staff
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    KitchenPrepStatus.values().forEach { status ->
                        val isCurrent = prepStatus == status
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isCurrent) status.color else if (isDark) MaterialTheme.colorScheme.surfaceVariant else Color(0xFFF1F5F9),
                            border = BorderStroke(1.dp, if (isCurrent) status.color else Color(0xFFCBD5E1)),
                            modifier = Modifier
                                .clickable { onUpdateKitchenStatus(status.label) }
                                .testTag("prep_status_${status.name}_order_${order.orderNumber}")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (isCurrent) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                }
                                Text(
                                    text = status.label,
                                    fontSize = 11.sp,
                                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                                    color = if (isCurrent) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Next Step Quick Advance Action Button
                if (prepStatus.nextStatus != null && prepStatus.nextActionLabel != null) {
                    Button(
                        onClick = { onUpdateKitchenStatus(prepStatus.nextStatus) },
                        colors = ButtonDefaults.buttonColors(containerColor = prepStatus.color),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("advance_status_btn_${order.orderNumber}")
                    ) {
                        Text(
                            text = prepStatus.nextActionLabel,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.5.sp,
                            color = Color.White
                        )
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFECFDF5),
                        border = BorderStroke(1.dp, Color(0xFFA7F3D0)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(vertical = 10.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = Color(0xFF059669),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Order Delivered to Customer ✓",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = Color(0xFF059669)
                            )
                        }
                    }
                }
            }

            // Payment verification for authorized admin only (Requirement 7)
            if (!isPaid && onVerifyPayment != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    color = Color(0xFFFEF3C7),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, Color(0xFFFDE68A)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Admin Control: Payment Verification",
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF92400E)
                            )
                            Text(
                                text = "Verify bank credit to vyanjanamm@ybl before dispatching.",
                                fontSize = 9.5.sp,
                                color = Color(0xFFB45309)
                            )
                        }
                        Button(
                            onClick = { onVerifyPayment(order.id, order.orderNumber) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text("✓ Mark Paid", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
