package com.example.ui.components

import android.Manifest
import android.annotation.SuppressLint
import androidx.compose.material.icons.filled.ContentPaste
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.Lifecycle
import androidx.compose.runtime.DisposableEffect
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.horizontalScroll
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.PinDrop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.SavedAddressEntity
import com.example.ui.theme.HerbGreen
import com.example.ui.theme.SaffronPrimary
import com.example.util.DeliveryLocationInfo
import com.example.util.DeliveryLocationService
import kotlin.math.roundToInt

enum class AddressEntryMode {
    DETECT_GPS,
    @Deprecated("Manual entry option has been removed in favor of GPS-verified mandatory address fields")
    MANUAL_ENTRY,
    @Deprecated("Use DETECT_GPS")
    GOOGLE_MAPS_PIN
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddressSelectionModal(
    initialMode: AddressEntryMode = AddressEntryMode.DETECT_GPS,
    editingAddress: SavedAddressEntity? = null,
    currentAddress: String = "",
    currentLocationInfo: DeliveryLocationInfo? = null,
    onSavePinnedLocation: (id: String?, label: String, lat: Double, lng: Double, buildingDetail: String, isDefault: Boolean) -> Unit,
    onSaveManualAddress: ((id: String?, label: String, flatDoor: String, building: String, street: String, area: String, landmark: String, pincode: String, isDefault: Boolean) -> Unit)? = null,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var selectedLabel by remember(editingAddress) {
        mutableStateOf(editingAddress?.label ?: "Home")
    }
    var isDefaultAddress by remember(editingAddress) {
        mutableStateOf(editingAddress?.isDefault ?: false)
    }

    // Pinning on Map state
    val initLat = editingAddress?.latitude ?: currentLocationInfo?.latitude ?: DeliveryLocationService.KITCHEN_LAT
    val initLng = editingAddress?.longitude ?: currentLocationInfo?.longitude ?: DeliveryLocationService.KITCHEN_LNG
    var pinLat by remember(editingAddress) { mutableDoubleStateOf(initLat) }
    var pinLng by remember(editingAddress) { mutableDoubleStateOf(initLng) }
    var hasGpsFix by remember(editingAddress) {
        mutableStateOf(editingAddress != null || currentLocationInfo != null)
    }
    var resolvedRoadAddress by remember(editingAddress) {
        mutableStateOf(
            when {
                editingAddress != null -> ""
                currentLocationInfo != null -> currentLocationInfo.addressFormatted
                else -> ""
            }
        )
    }
    var resolvedLocality by remember(editingAddress) {
        mutableStateOf(
            when {
                editingAddress != null -> editingAddress.area.ifBlank { "Saved Location" }
                currentLocationInfo != null -> currentLocationInfo.locality
                else -> "Detecting Location"
            }
        )
    }
    var resolvedPostalCode by remember(editingAddress) {
        mutableStateOf(editingAddress?.pincode ?: currentLocationInfo?.postalCode ?: "")
    }

    // Mandatory Client Address Fields (House / Flat / Door, Floor, Building / Society, PIN Code)
    val initialHouseNumber = editingAddress?.flatDoorNumber ?: ""
    val initialFloor = if (editingAddress != null && editingAddress.buildingSociety.contains("Floor:")) {
        editingAddress.buildingSociety.substringAfter("Floor:").substringBefore(",").trim()
    } else ""
    val initialBuilding = if (editingAddress != null && editingAddress.buildingSociety.contains("Floor:")) {
        editingAddress.buildingSociety.substringAfter(",").trim()
    } else {
        editingAddress?.buildingSociety ?: ""
    }
    val initialPincode = editingAddress?.pincode ?: ""

    var houseNumberInput by remember(editingAddress) { mutableStateOf(initialHouseNumber) }
    var floorInput by remember(editingAddress) { mutableStateOf(initialFloor) }
    var buildingInput by remember(editingAddress) { mutableStateOf(initialBuilding) }
    var pincodeInput by remember(editingAddress) { mutableStateOf(initialPincode) }

    // Validation Errors
    var houseNumberError by remember { mutableStateOf<String?>(null) }
    var floorError by remember { mutableStateOf<String?>(null) }
    var buildingError by remember { mutableStateOf<String?>(null) }
    var pincodeError by remember { mutableStateOf<String?>(null) }

    // GPS Status & Feedback State
    var isLocatingGps by remember { mutableStateOf(false) }
    var gpsNoticeMessage by remember { mutableStateOf<String?>(null) }
    var isGpsError by remember { mutableStateOf(false) }

    fun triggerGpsFetch() {
        isLocatingGps = true
        isGpsError = false
        gpsNoticeMessage = null
        DeliveryLocationService.detectPreciseLocation(
            context = context,
            onSuccess = { loc ->
                isLocatingGps = false
                hasGpsFix = true
                pinLat = loc.latitude
                pinLng = loc.longitude
                resolvedRoadAddress = loc.addressFormatted
                resolvedLocality = loc.locality
                resolvedPostalCode = loc.postalCode
                if (pincodeInput.isBlank() && loc.postalCode.matches(Regex("^[1-9][0-9]{5}$"))) {
                    pincodeInput = loc.postalCode
                    pincodeError = null
                }
                isGpsError = false
                gpsNoticeMessage = "📍 GPS location acquired (${loc.distanceKm} km from kitchen)"
            },
            onError = { err ->
                isLocatingGps = false
                isGpsError = true
                gpsNoticeMessage = "GPS signal note: $err"
            }
        )
    }

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true
        val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (fineGranted || coarseGranted) {
            triggerGpsFetch()
        } else {
            isLocatingGps = false
            isGpsError = true
            gpsNoticeMessage = "Location permission denied. Grant location permission and tap 'Detect Current GPS Location'."
        }
    }

    // Automatically fetch live GPS when opening the modal to add a new delivery address
    LaunchedEffect(editingAddress) {
        if (editingAddress == null) {
            if (DeliveryLocationService.hasLocationPermission(context)) {
                triggerGpsFetch()
            } else {
                locationPermissionLauncher.launch(
                    arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    )
                )
            }
        }
    }

    // Asynchronously reverse-geocode coordinates off the main thread when needed
    LaunchedEffect(pinLat, pinLng, hasGpsFix) {
        if (hasGpsFix && (resolvedRoadAddress.isBlank() || resolvedRoadAddress.startsWith("Pinned Location ("))) {
            DeliveryLocationService.reverseGeocodeCoordinates(
                context = context,
                lat = pinLat,
                lng = pinLng
            ) { formatted, locality, postalCode ->
                resolvedRoadAddress = formatted
                resolvedLocality = locality
                if (postalCode.isNotBlank()) {
                    resolvedPostalCode = postalCode
                    if (pincodeInput.isBlank() && postalCode.matches(Regex("^[1-9][0-9]{5}$"))) {
                        pincodeInput = postalCode
                        pincodeError = null
                    }
                }
            }
        }
    }

    val isDark = isSystemInDarkTheme()

    val combinedBuildingDetail = remember(houseNumberInput, floorInput, buildingInput, pincodeInput) {
        listOfNotNull(
            houseNumberInput.takeIf { it.isNotBlank() },
            floorInput.takeIf { it.isNotBlank() }?.let { "Floor: $it" },
            buildingInput.takeIf { it.isNotBlank() },
            pincodeInput.takeIf { it.isNotBlank() }?.let { "PIN: $it" }
        ).joinToString(", ")
    }

    // Real-time calculated info for the current pin coordinates (never blocks UI thread on Geocoder)
    val calculatedPinInfo = remember(
        pinLat,
        pinLng,
        combinedBuildingDetail,
        resolvedRoadAddress,
        resolvedLocality,
        resolvedPostalCode
    ) {
        val safePreResolved = resolvedRoadAddress.ifBlank { "Pinned Location ($pinLat, $pinLng)" }
        DeliveryLocationService.createLocationInfoForCoordinates(
            context = context,
            lat = pinLat,
            lng = pinLng,
            buildingDetail = combinedBuildingDetail.trim(),
            preResolvedAddress = safePreResolved,
            preResolvedLocality = resolvedLocality,
            preResolvedPostalCode = resolvedPostalCode
        )
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        dragHandle = null,
        modifier = Modifier.testTag("address_selection_modal")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(SaffronPrimary.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = SaffronPrimary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = if (editingAddress != null) "Edit Delivery Address" else "Add Delivery Address",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "GPS verified location & mandatory door details",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("close_address_modal_btn")
                ) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Column(modifier = Modifier.fillMaxWidth()) {
                    // 1. GPS Detection Card
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("detect_gps_launcher_card"),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
                        ),
                        border = BorderStroke(1.dp, SaffronPrimary.copy(alpha = 0.35f))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.MyLocation,
                                        contentDescription = null,
                                        tint = SaffronPrimary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Current GPS Location",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = SaffronPrimary.copy(alpha = 0.15f)
                                ) {
                                    Text(
                                        text = "Margao, Goa Base",
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = SaffronPrimary,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Detect your live location using device GPS. We will automatically capture your coordinates, formatted address, and verify distance within our 14 km fresh delivery radius.",
                                fontSize = 11.5.sp,
                                lineHeight = 16.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Large Primary Detect GPS Button
                            Button(
                                onClick = {
                                    if (DeliveryLocationService.hasLocationPermission(context)) {
                                        triggerGpsFetch()
                                    } else {
                                        locationPermissionLauncher.launch(
                                            arrayOf(
                                                Manifest.permission.ACCESS_FINE_LOCATION,
                                                Manifest.permission.ACCESS_COARSE_LOCATION
                                            )
                                        )
                                    }
                                },
                                enabled = !isLocatingGps,
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("modal_detect_gps_btn"),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                if (isLocatingGps) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(18.dp),
                                        strokeWidth = 2.dp,
                                        color = Color.White
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Acquiring Live GPS...", fontSize = 13.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                } else {
                                    Icon(Icons.Default.MyLocation, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color.White)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "📍 Detect Current GPS Location",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }

                            if (gpsNoticeMessage != null) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = gpsNoticeMessage ?: "",
                                    fontSize = 11.5.sp,
                                    color = if (isGpsError) MaterialTheme.colorScheme.error else HerbGreen,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 2. Captured Location Details Card (Latitude, Longitude & Formatted Address)
                    val cardContainerColor = when {
                        isLocatingGps || !hasGpsFix -> Color(0xFFFFFBEB)
                        calculatedPinInfo.isDeliverable -> Color(0xFFF0FDF4)
                        else -> Color(0xFFFEF2F2)
                    }
                    val cardBorderColor = when {
                        isLocatingGps || !hasGpsFix -> Color(0xFFFCD34D)
                        calculatedPinInfo.isDeliverable -> Color(0xFF86EFAC)
                        else -> Color(0xFFFCA5A5)
                    }
                    val cardAccentColor = when {
                        isLocatingGps || !hasGpsFix -> Color(0xFFB45309)
                        calculatedPinInfo.isDeliverable -> HerbGreen
                        else -> Color(0xFFDC2626)
                    }
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("captured_location_details_card"),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = cardContainerColor),
                        border = BorderStroke(1.5.dp, cardBorderColor)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = when {
                                            isLocatingGps -> Icons.Default.MyLocation
                                            !hasGpsFix -> Icons.Default.ErrorOutline
                                            calculatedPinInfo.isDeliverable -> Icons.Default.CheckCircle
                                            else -> Icons.Default.ErrorOutline
                                        },
                                        contentDescription = null,
                                        tint = cardAccentColor,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = when {
                                            isLocatingGps -> "Acquiring Live GPS..."
                                            !hasGpsFix -> "GPS Location Pending"
                                            calculatedPinInfo.isDeliverable -> "Captured & Deliverable (Within 14 km)"
                                            else -> "🚫 Not Serviceable (> 14 km Range)"
                                        },
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.5.sp,
                                        color = cardAccentColor
                                    )
                                }
                                Text(
                                    text = if (hasGpsFix) "${calculatedPinInfo.distanceKm} km from kitchen" else "Awaiting GPS",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = cardAccentColor
                                )
                            }

                            HorizontalDivider(
                                modifier = Modifier.padding(vertical = 10.dp),
                                color = when {
                                    isLocatingGps || !hasGpsFix -> Color(0xFFFDE68A)
                                    calculatedPinInfo.isDeliverable -> Color(0xFFBBF7D0)
                                    else -> Color(0xFFFECACA)
                                }
                            )

                            // Captured Formatted Address
                            Text(
                                text = "Captured Formatted Address:",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(3.dp))
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f),
                                border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.Top
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.LocationOn,
                                        contentDescription = null,
                                        tint = SaffronPrimary,
                                        modifier = Modifier.size(16.dp).padding(top = 2.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = when {
                                            isLocatingGps -> "Fetching live GPS coordinates and street address..."
                                            !hasGpsFix -> "Tap 'Detect Current GPS Location' above to fetch your live delivery coordinates."
                                            else -> calculatedPinInfo.addressFormatted
                                        },
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                        color = MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.testTag("captured_formatted_address_text")
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = if (hasGpsFix) {
                                    "${calculatedPinInfo.deliveryZone} • Estimated transit: ~${calculatedPinInfo.estimatedMinutes} mins • GPS: $pinLat, $pinLng"
                                } else {
                                    "Coordinates will appear once device GPS lock succeeds."
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            if (hasGpsFix && !calculatedPinInfo.isDeliverable) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "⚠️ We are not serviceable to this location (${calculatedPinInfo.distanceKm} km away). Orders can be placed only within 14 km range from our Margao kitchen.",
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color(0xFFDC2626)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 3. Address Details
                    Text(
                        text = "Address Details",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Field 1: House / Flat / Door Number
                    OutlinedTextField(
                        value = houseNumberInput,
                        onValueChange = {
                            houseNumberInput = it
                            if (it.isNotBlank()) houseNumberError = null
                        },
                        label = { Text("House / Flat / Door Number *") },
                        placeholder = { Text("e.g. Flat 402 / House No. 12") },
                        isError = houseNumberError != null,
                        supportingText = houseNumberError?.let { { Text(it, color = MaterialTheme.colorScheme.error) } },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("house_number_input"),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Field 2: Floor (Optional)
                    OutlinedTextField(
                        value = floorInput,
                        onValueChange = { floorInput = it },
                        label = { Text("Floor (Optional)") },
                        placeholder = { Text("e.g. Ground Floor / 4th Floor") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("floor_input"),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Field 3: Building / Society Name (Optional)
                    OutlinedTextField(
                        value = buildingInput,
                        onValueChange = { buildingInput = it },
                        label = { Text("Building / Society Name (Optional)") },
                        placeholder = { Text("e.g. Green Valley Heights / Sunrise Apts") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("building_input"),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Field 4: PIN Code (6 digits)
                    OutlinedTextField(
                        value = pincodeInput,
                        onValueChange = {
                            if (it.length <= 6 && it.all { char -> char.isDigit() }) {
                                pincodeInput = it
                                if (it.matches(Regex("^[1-9][0-9]{5}$"))) pincodeError = null
                            }
                        },
                        label = { Text("PIN Code (6 digits) *") },
                        placeholder = { Text("e.g. 403601") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        isError = pincodeError != null,
                        supportingText = pincodeError?.let { { Text(it, color = MaterialTheme.colorScheme.error) } },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pincode_input"),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // 4. Address Label Selector (Home / Work / Other)
                    Text(
                        text = "Address Label",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Home" to Icons.Default.Home, "Work" to Icons.Default.Business, "Other" to Icons.Default.LocationOn).forEach { (lbl, icon) ->
                            val isSelected = selectedLabel == lbl
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) SaffronPrimary else MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { selectedLabel = lbl }
                                    .testTag("address_label_chip_$lbl")
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 8.dp),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = null,
                                        modifier = Modifier.size(15.dp),
                                        tint = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = lbl,
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // 5. Default Address Checkbox
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isDefaultAddress = !isDefaultAddress }
                    ) {
                        Checkbox(
                            checked = isDefaultAddress,
                            onCheckedChange = { isDefaultAddress = it },
                            colors = CheckboxDefaults.colors(checkedColor = SaffronPrimary),
                            modifier = Modifier.testTag("pin_set_default_checkbox")
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Set as default delivery address",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 6. Action Button: Save Address
                    Button(
                        onClick = {
                            if (!hasGpsFix) {
                                isGpsError = true
                                gpsNoticeMessage = "GPS location is required before saving. Fetching GPS now..."
                                if (DeliveryLocationService.hasLocationPermission(context)) {
                                    triggerGpsFetch()
                                } else {
                                    locationPermissionLauncher.launch(
                                        arrayOf(
                                            Manifest.permission.ACCESS_FINE_LOCATION,
                                            Manifest.permission.ACCESS_COARSE_LOCATION
                                        )
                                    )
                                }
                                return@Button
                            }

                            var hasError = false

                            if (houseNumberInput.trim().isBlank()) {
                                houseNumberError = "House / Flat number is required"
                                hasError = true
                            } else {
                                houseNumberError = null
                            }

                            // Floor and Society name are optional
                            floorError = null
                            buildingError = null

                            val cleanPin = pincodeInput.trim()
                            if (!cleanPin.matches(Regex("^[1-9][0-9]{5}$"))) {
                                pincodeError = "Enter valid 6-digit PIN"
                                hasError = true
                            } else {
                                pincodeError = null
                            }

                            if (!calculatedPinInfo.isDeliverable) {
                                hasError = true
                            }

                            if (!hasError) {
                                val fullDetail = listOfNotNull(
                                    houseNumberInput.trim().takeIf { it.isNotBlank() },
                                    floorInput.trim().takeIf { it.isNotBlank() }?.let { "Floor: $it" },
                                    buildingInput.trim().takeIf { it.isNotBlank() },
                                    cleanPin.takeIf { it.isNotBlank() }?.let { "PIN: $it" }
                                ).joinToString(", ")

                                onSavePinnedLocation(
                                    editingAddress?.id,
                                    selectedLabel,
                                    pinLat,
                                    pinLng,
                                    fullDetail,
                                    isDefaultAddress
                                )
                                onDismiss()
                            }
                        },
                        enabled = !isLocatingGps && (!hasGpsFix || calculatedPinInfo.isDeliverable),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = when {
                                !hasGpsFix -> SaffronPrimary
                                calculatedPinInfo.isDeliverable -> SaffronPrimary
                                else -> MaterialTheme.colorScheme.error
                            }
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("save_pinned_location_btn")
                    ) {
                        Icon(
                            imageVector = when {
                                !hasGpsFix -> Icons.Default.MyLocation
                                calculatedPinInfo.isDeliverable -> Icons.Default.Check
                                else -> Icons.Default.ErrorOutline
                            },
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = when {
                                isLocatingGps -> "Waiting for GPS..."
                                !hasGpsFix -> "Detect GPS Location to Save"
                                !calculatedPinInfo.isDeliverable -> "🚫 Out of 14km Range"
                                editingAddress != null -> "Update Address"
                                else -> "Save & Set Delivery Address"
                            },
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 13.sp
                        )
                    }
                }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}
