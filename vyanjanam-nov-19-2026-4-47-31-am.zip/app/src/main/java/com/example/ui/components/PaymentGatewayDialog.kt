package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.TextButton
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import coil.compose.AsyncImage
import androidx.compose.ui.layout.ContentScale
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.isSystemInDarkTheme
import com.example.payment.PaymentMethodType
import com.example.payment.PaymentRequest
import com.example.ui.theme.HerbGreen
import com.example.ui.theme.SaffronPrimary
import com.example.ui.theme.SaffronLight
import com.example.util.DeliveryLocationInfo
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

import android.content.Intent
import android.net.Uri
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.ui.platform.LocalContext
import com.example.data.entity.SavedAddressEntity
import com.example.payment.WhatsAppPaymentHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentGatewayDialog(
    request: PaymentRequest,
    walletBalance: Double = 0.0,
    deliveryAddress: String = "",
    locationInfo: DeliveryLocationInfo? = null,
    customerPhoneNumber: String = "+91 98765 43210",
    savedAddresses: List<SavedAddressEntity> = emptyList(),
    onDismiss: () -> Unit,
    onPaymentSuccess: (
        method: PaymentMethodType,
        details: String,
        lockOrder: Boolean,
        isVerified: Boolean,
        txnId: String?,
        chosenAddress: String,
        latitude: Double,
        longitude: Double,
        distanceKm: Double
    ) -> Unit
) {
    val context = LocalContext.current

    val defaultAddress = remember(savedAddresses, request.preSelectedAddressId) {
        if (request.preSelectedAddressId != null) {
            savedAddresses.find { it.id == request.preSelectedAddressId }
                ?: (savedAddresses.find { it.isDefault } ?: savedAddresses.firstOrNull())
        } else {
            savedAddresses.find { it.isDefault } ?: savedAddresses.firstOrNull()
        }
    }
    var selectedAddressId by remember(savedAddresses, request.preSelectedAddressId) {
        mutableStateOf(request.preSelectedAddressId ?: defaultAddress?.id)
    }
    val activeAddress = remember(selectedAddressId, savedAddresses) {
        savedAddresses.find { it.id == selectedAddressId } ?: defaultAddress
    }
    val finalDeliveryAddress = activeAddress?.formattedAddress ?: deliveryAddress
    val finalLat = activeAddress?.latitude ?: locationInfo?.latitude ?: 15.4989
    val finalLng = activeAddress?.longitude ?: locationInfo?.longitude ?: 73.8278
    val finalDist = activeAddress?.distanceKm ?: locationInfo?.distanceKm ?: 2.4
    val isServiceable = finalDist <= 14.0
    val finalZone = if (isServiceable) {
        activeAddress?.deliveryZone ?: locationInfo?.deliveryZone ?: "Zone A • Express Margao & Fatorda (15-20m)"
    } else {
        "Not Serviceable (> 14 km from Margao Kitchen)"
    }

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = Modifier.testTag("payment_gateway_bottom_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            // Header with Security Trust Badges
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(HerbGreen.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = "Secure",
                            tint = HerbGreen,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Secure Payment Gateway",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "256-Bit SSL Encrypted • RBI Compliant",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                            color = HerbGreen
                        )
                    }
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("close_payment_button")
                ) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Order Payable Card
            val isDark = isSystemInDarkTheme()
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant else Color(0xFFFFF8F0)
                )
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = request.orderTitle,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Breakfast Slot: ${request.deliverySlot}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = "₹${request.amount.toInt()}",
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = if (isDark) SaffronLight else SaffronPrimary
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = if (isDark) MaterialTheme.colorScheme.outlineVariant else Color(0xFFFFE0B2))
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Cloud Kitchen Delivery",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "FREE",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = HerbGreen
                            )
                        )
                    }

                    if (locationInfo != null) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "📍 GPS Delivery Catchment",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "${locationInfo.deliveryZone} (${locationInfo.distanceKm} km)",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = HerbGreen
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "📞 Rider Contact Phone",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = customerPhoneNumber,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Delivery Destination Card: Shown only if user has multiple saved addresses and hideAddressSection is false
            val showAddressCard = (savedAddresses.size > 1) && !request.hideAddressSection
            if (showAddressCard) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("checkout_delivery_address_card"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant else Color(0xFFF9FAFB)
                ),
                border = BorderStroke(1.dp, if (isDark) MaterialTheme.colorScheme.outlineVariant else Color(0xFFE5E7EB))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(if (isDark) Color(0xFF382315) else Color(0xFFFFF3E0)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = "Delivery Address",
                                tint = SaffronPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Delivery Destination",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Select address • Manage addresses in Profile",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    if (savedAddresses.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            savedAddresses.forEach { addr ->
                                val isSelected = (addr.id == selectedAddressId) || (selectedAddressId == null && addr.isDefault)
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSelected) SaffronPrimary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface,
                                    border = BorderStroke(
                                        if (isSelected) 1.5.dp else 1.dp,
                                        if (isSelected) SaffronPrimary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { selectedAddressId = addr.id }
                                        .testTag("checkout_select_address_${addr.id}")
                                ) {
                                    Column(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = if (addr.label.equals("Work", ignoreCase = true)) Icons.Default.CreditCard else Icons.Default.LocationOn,
                                                contentDescription = null,
                                                tint = if (isSelected) SaffronPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.size(13.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = addr.label,
                                                fontSize = 11.5.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isSelected) SaffronPrimary else MaterialTheme.colorScheme.onSurface
                                            )
                                            if (addr.isDefault) {
                                                Spacer(modifier = Modifier.width(3.dp))
                                                Text("★", fontSize = 10.sp, color = HerbGreen)
                                            }
                                        }
                                        Text(
                                            text = "${addr.distanceKm} km",
                                            fontSize = 10.sp,
                                            color = if (isSelected) HerbGreen else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = finalDeliveryAddress,
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Live Google Maps coordinates & navigation badge
                    Surface(
                        color = Color(0xFFF0FDF4),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Navigation,
                                        contentDescription = null,
                                        tint = Color(0xFF047857),
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Google Maps Pin: $finalLat, $finalLng",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = Color(0xFF065F46)
                                    )
                                }
                                Surface(
                                    color = Color(0xFFDCFCE7),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(
                                        text = "$finalDist km away",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF047857),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "$finalZone • Real-time rider route mapped",
                                fontSize = 11.sp,
                                color = Color(0xFF047857)
                            )

                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = {
                                    com.example.util.DeliveryLocationService.openGoogleMaps(
                                        context = context,
                                        lat = finalLat,
                                        lng = finalLng,
                                        label = "Vyanjanam Breakfast Delivery Pin"
                                    )
                                },
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.2.dp, Color(0xFF059669)),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = Color(0xFFECFDF5)
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("view_on_google_maps_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Map,
                                    contentDescription = null,
                                    tint = Color(0xFF047857),
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "🗺️ Open & Verify on Google Maps",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFF047857)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
        }

            // Payment Method Section: Clutter-free WhatsApp Official Desk
            Text(
                text = "Payment Method",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(8.dp))

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("whatsapp_payment_desk_card"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isDark) Color(0xFF1E2F23) else Color(0xFFF0FDF4)
                ),
                border = BorderStroke(1.5.dp, if (isDark) Color(0xFF166534) else Color(0xFFBBF7D0))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF22C55E).copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Chat,
                                    contentDescription = "WhatsApp",
                                    tint = Color(0xFF16A34A),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Pay via Official WhatsApp Desk",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = if (isDark) Color(0xFF86EFAC) else Color(0xFF15803D)
                                )
                                Text(
                                    text = WhatsAppPaymentHelper.OFFICIAL_WHATSAPP_DISPLAY,
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color(0xFF16A34A)
                                )
                            }
                        }

                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Selected",
                            tint = Color(0xFF16A34A),
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "• Tap below to lock your order and connect directly with our kitchen desk on WhatsApp.\n• Confirm your payment details with our team for instant meal preparation and delivery dispatch.",
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 18.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Action Pay Button
            Button(
                onClick = {
                    val orderNum = if (request.isChefsWeeklyChoice) "CW${(1000..9999).random()}" else "RK${(1000..9999).random()}"
                    val purpose = if (request.isChefsWeeklyChoice) "Chef's Weekly Choice (7-Day Advance Payment)" else ""
                    val waUrl = WhatsAppPaymentHelper.buildWhatsAppUrl(orderNum, request.amount, purpose)
                    val waIntent = Intent(Intent.ACTION_VIEW, Uri.parse(waUrl)).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    try {
                        context.startActivity(waIntent)
                    } catch (_: Exception) {
                        // Browser or WhatsApp intent fallback
                    }
                    onPaymentSuccess(
                        PaymentMethodType.WHATSAPP_UPI,
                        "WhatsApp Support (${WhatsAppPaymentHelper.OFFICIAL_WHATSAPP_DISPLAY})",
                        true, // lockOrder = true
                        false, // isVerified = false -> PAYMENT_PENDING until desk confirms
                        null,
                        finalDeliveryAddress,
                        finalLat,
                        finalLng,
                        finalDist
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("pay_securely_button"),
                shape = RoundedCornerShape(12.dp),
                enabled = isServiceable,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (!isServiceable) MaterialTheme.colorScheme.error else Color(0xFF16A34A),
                    disabledContainerColor = if (!isServiceable) MaterialTheme.colorScheme.error.copy(alpha = 0.5f) else Color(0xFFE0E0E0)
                )
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Chat,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (!isServiceable)
                            "🚫 Not Serviceable (${finalDist} km > 14 km)"
                        else if (request.isChefsWeeklyChoice)
                            "Advance Pay ₹${request.amount.toInt()} via WhatsApp ➔"
                        else
                            "Pay ₹${request.amount.toInt()} via WhatsApp Desk ➔",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }

            Spacer(modifier = Modifier.height(28.dp))
        }
    }
}
