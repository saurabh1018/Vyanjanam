package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = SaffronLight,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF382315),
    onPrimaryContainer = Color(0xFFFFCC80),
    secondary = ButterAmber,
    onSecondary = Color.Black,
    tertiary = HerbGreenLight,
    onTertiary = Color.Black,
    background = Color(0xFF14100D),
    surface = Color(0xFF201B17),
    onBackground = Color(0xFFF7EFE6),
    onSurface = Color(0xFFF7EFE6),
    surfaceVariant = Color(0xFF322A23),
    onSurfaceVariant = Color(0xFFDDD2CB),
    outline = Color(0xFF7A6D63),
    outlineVariant = Color(0xFF4A3F36)
)

private val LightColorScheme = lightColorScheme(
    primary = SaffronPrimary,
    onPrimary = Color.White,
    primaryContainer = WarmCardElevated,
    onPrimaryContainer = SaffronDark,
    secondary = ButterAmber,
    onSecondary = Color.Black,
    tertiary = HerbGreen,
    onTertiary = Color.White,
    background = WarmCreamBackground,
    surface = WarmCardSurface,
    onBackground = CharcoalText,
    onSurface = CharcoalText,
    surfaceVariant = WarmCardElevated,
    onSurfaceVariant = CharcoalSubtext,
    outline = WarmOutline
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep brand culinary look consistent
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
