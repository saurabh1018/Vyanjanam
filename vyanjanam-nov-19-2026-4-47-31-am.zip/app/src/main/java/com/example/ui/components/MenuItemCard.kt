package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.PlainTooltip
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TooltipBox
import androidx.compose.material3.TooltipDefaults
import androidx.compose.material3.rememberTooltipState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.MenuDish
import com.example.model.PortionOption
import com.example.ui.theme.HerbGreen
import com.example.ui.theme.HerbGreenLight
import com.example.ui.theme.SaffronPrimary
import com.example.ui.theme.SaffronLight

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuItemCard(
    dish: MenuDish,
    targetDayName: String,
    onQuickAdd: (PortionOption) -> Unit,
    onCustomizeClick: () -> Unit,
    isPastCutoff: Boolean = false,
    isAdmin: Boolean = false,
    onToggleAvailability: (() -> Unit)? = null,
    onRemoveDish: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val isDark = isSystemInDarkTheme()
    var selectedOption by remember(dish.options) { mutableStateOf(dish.options.first()) }
    var isHovered by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    val tooltipState = rememberTooltipState()

    val cardBorder = if (!dish.isAvailable) {
        BorderStroke(1.dp, if (isDark) Color(0xFF424242) else Color(0xFFD6D6D6))
    } else null

    val cardContainerColor = if (!dish.isAvailable) {
        if (isDark) Color(0xFF1E1E1E) else Color(0xFFF3F3F3)
    } else {
        MaterialTheme.colorScheme.surface
    }

    TooltipBox(
        positionProvider = TooltipDefaults.rememberPlainTooltipPositionProvider(),
        tooltip = {
            if (!dish.isAvailable) {
                PlainTooltip(
                    containerColor = Color(0xFF1E293B),
                    contentColor = Color.White,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "Item unavailable",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        },
        state = tooltipState
    ) {
        Box(
            modifier = modifier
                .fillMaxWidth()
                .pointerInput(dish.id, dish.isAvailable) {
                    awaitPointerEventScope {
                        while (true) {
                            val event = awaitPointerEvent()
                            when (event.type) {
                                PointerEventType.Enter -> isHovered = true
                                PointerEventType.Exit -> isHovered = false
                                PointerEventType.Move -> isHovered = true
                            }
                        }
                    }
                }
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("menu_item_card_${dish.id}"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = cardContainerColor),
                border = cardBorder,
                elevation = CardDefaults.cardElevation(defaultElevation = if (dish.isAvailable) 2.dp else 0.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    // Content wrapped with dimming/grayscale alpha if unavailable
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .graphicsLayer {
                                alpha = if (!dish.isAvailable) 0.55f else 1f
                            }
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    // Pure Veg square green dot
                                    Box(
                                        modifier = Modifier
                                            .size(16.dp)
                                            .clip(RoundedCornerShape(3.dp))
                                            .background(if (isDark) MaterialTheme.colorScheme.surfaceVariant else Color.White)
                                            .padding(1.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(14.dp)
                                                .clip(RoundedCornerShape(2.dp))
                                                .background((if (isDark) HerbGreenLight else HerbGreen).copy(alpha = 0.25f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(6.dp)
                                                    .clip(CircleShape)
                                                    .background(if (isDark) HerbGreenLight else HerbGreen)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(6.dp))

                                    Text(
                                        text = dish.category,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (isDark) SaffronLight else SaffronPrimary
                                        )
                                    )

                                    if (!dish.isAvailable) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = MaterialTheme.colorScheme.error.copy(alpha = 0.15f)
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Block,
                                                    contentDescription = null,
                                                    tint = MaterialTheme.colorScheme.error,
                                                    modifier = Modifier.size(12.dp)
                                                )
                                                Spacer(modifier = Modifier.width(3.dp))
                                                Text(
                                                    text = "Item unavailable",
                                                    style = MaterialTheme.typography.labelSmall.copy(
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = MaterialTheme.colorScheme.error
                                                    )
                                                )
                                            }
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                Text(
                                    text = dish.name,
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    ),
                                    color = if (!dish.isAvailable) {
                                        MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                    } else {
                                        MaterialTheme.colorScheme.onSurface
                                    }
                                )

                                Text(
                                    text = dish.subName,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (!dish.isAvailable) {
                                        MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                                    } else {
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                    }
                                )
                            }

                            // Price display badge
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        if (!dish.isAvailable) {
                                            if (isDark) Color(0xFF2C2C2C) else Color(0xFFE0E0E0)
                                        } else {
                                            if (isDark) Color(0xFF382315) else Color(0xFFFFF3E0)
                                        }
                                    )
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = "₹${selectedOption.price.toInt()}",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (!dish.isAvailable) {
                                            if (isDark) Color.LightGray else Color.DarkGray
                                        } else {
                                            if (isDark) SaffronLight else SaffronPrimary
                                        }
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = dish.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Portion options chips
                        Text(
                            text = "Select Portion:",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            dish.options.forEach { option ->
                                val isChosen = (option.id == selectedOption.id)
                                Card(
                                    modifier = Modifier
                                        .clickable(enabled = dish.isAvailable) { selectedOption = option }
                                        .testTag("portion_chip_${option.id}"),
                                    shape = RoundedCornerShape(10.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isChosen) {
                                            if (dish.isAvailable) {
                                                if (isDark) SaffronLight else SaffronPrimary
                                            } else {
                                                if (isDark) Color(0xFF424242) else Color(0xFFBDBDBD)
                                            }
                                        } else {
                                            MaterialTheme.colorScheme.surfaceVariant
                                        }
                                    )
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        if (isChosen) {
                                            Icon(
                                                imageVector = Icons.Default.Check,
                                                contentDescription = null,
                                                tint = if (dish.isAvailable) {
                                                    if (isDark) Color.Black else Color.White
                                                } else Color.White,
                                                modifier = Modifier.size(14.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                        }
                                        Text(
                                            text = "${option.label} • ₹${option.price.toInt()}",
                                            style = MaterialTheme.typography.labelMedium.copy(
                                                fontWeight = if (isChosen) FontWeight.Bold else FontWeight.Normal
                                            ),
                                            color = if (isChosen) {
                                                if (dish.isAvailable) {
                                                    if (isDark) Color.Black else Color.White
                                                } else Color.White
                                            } else {
                                                MaterialTheme.colorScheme.onSurfaceVariant
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Actions row: Quick Add + Customize
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = onCustomizeClick,
                                enabled = dish.isAvailable,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("customize_button_${dish.id}")
                            ) {
                                Text(
                                    text = "Customize Add-ons",
                                    style = MaterialTheme.typography.labelMedium
                                )
                            }

                            Button(
                                onClick = { onQuickAdd(selectedOption) },
                                enabled = !isPastCutoff && dish.isAvailable,
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isDark) SaffronLight else SaffronPrimary,
                                    contentColor = if (isDark) Color.Black else Color.White,
                                    disabledContainerColor = if (isDark) Color(0xFF382F28) else Color(0xFFE0E0E0),
                                    disabledContentColor = if (isDark) Color(0xFF8D8379) else Color(0xFF757575)
                                ),
                                modifier = Modifier.testTag("quick_add_button_${dish.id}")
                            ) {
                                Icon(
                                    imageVector = if (!dish.isAvailable) Icons.Default.Block else Icons.Default.Add,
                                    contentDescription = if (!dish.isAvailable) "Unavailable" else "Add",
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = when {
                                        !dish.isAvailable -> "Item unavailable"
                                        isPastCutoff -> "Cutoff Closed"
                                        else -> "Add to $targetDayName"
                                    },
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }

                    // Admin Quick Controls Bar (when viewed by admin)
                    if (isAdmin && (onToggleAvailability != null || onRemoveDish != null)) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isDark) Color(0xFF1E293B) else Color(0xFFF1F5F9))
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AdminPanelSettings,
                                    contentDescription = null,
                                    tint = SaffronPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (dish.isAvailable) "Available" else "Unavailable",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                if (onToggleAvailability != null) {
                                    Switch(
                                        checked = dish.isAvailable,
                                        onCheckedChange = { onToggleAvailability() },
                                        modifier = Modifier.testTag("admin_switch_${dish.id}")
                                    )
                                }

                                if (onRemoveDish != null) {
                                    IconButton(
                                        onClick = { showDeleteConfirm = true },
                                        modifier = Modifier
                                            .size(36.dp)
                                            .testTag("admin_delete_dish_${dish.id}")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DeleteOutline,
                                            contentDescription = "Remove Dish",
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (showDeleteConfirm) {
                        AlertDialog(
                            onDismissRequest = { showDeleteConfirm = false },
                            title = {
                                Text(
                                    text = "Remove from Menu?",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            },
                            text = {
                                Text(
                                    text = "Are you sure you want to remove \"${dish.name}\"? It will be deleted from the live kitchen menu catalog.",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            },
                            confirmButton = {
                                Button(
                                    onClick = {
                                        showDeleteConfirm = false
                                        onRemoveDish?.invoke()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                                    modifier = Modifier.testTag("confirm_delete_dish_${dish.id}")
                                ) {
                                    Text("Remove Item")
                                }
                            },
                            dismissButton = {
                                OutlinedButton(
                                    onClick = { showDeleteConfirm = false }
                                ) {
                                    Text("Cancel")
                                }
                            }
                        )
                    }
                }
            }

            // Interactive Hover Pill Overlay: Appears when hovering over an unavailable item
            if (isHovered && !dish.isAvailable) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xEE0F172A),
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .testTag("hover_item_unavailable_${dish.id}")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Block,
                            contentDescription = null,
                            tint = Color(0xFFFF8A80),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Item unavailable",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                    }
                }
            }
        }
    }
}
