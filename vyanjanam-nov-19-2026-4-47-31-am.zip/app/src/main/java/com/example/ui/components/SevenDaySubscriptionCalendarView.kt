package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeliveryDining
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PauseCircle
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DayScheduleInfo
import com.example.model.SchedulePreset
import com.example.model.SelectedMealItem
import com.example.ui.theme.HerbGreen
import com.example.ui.theme.HerbGreenLight
import com.example.ui.theme.LockWarningRed
import com.example.ui.theme.SaffronPrimary
import com.example.ui.theme.SaffronLight
import androidx.compose.foundation.isSystemInDarkTheme

@Composable
fun SevenDaySubscriptionCalendarView(
    days: List<DayScheduleInfo>,
    enabledDays: Set<Int>,
    dayCarts: Map<Int, List<SelectedMealItem>>,
    cutoffCountdown: String,
    deliverySlot: String,
    onToggleDay: (dayIndex: Int, isEnabled: Boolean) -> Unit,
    onApplyPreset: (SchedulePreset) -> Unit,
    onCustomizeDay: (dayIndex: Int) -> Unit,
    onProceedCheckout: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeDaysCount = enabledDays.size
    val isDark = isSystemInDarkTheme()
    val firstDate = days.firstOrNull()?.dateDisplay ?: "This Week"
    val lastDate = days.lastOrNull()?.dateDisplay ?: "Next Week"

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("seven_day_calendar_view"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Calendar Header Card with Week Range & Active Days Indicator
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("calendar_header_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(SaffronPrimary.copy(alpha = 0.12f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CalendarMonth,
                                    contentDescription = "Calendar",
                                    tint = SaffronPrimary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "7-Day Subscription Schedule",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "$firstDate – $lastDate",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        // Active days count chip
                        val isDark = isSystemInDarkTheme()
                        val activeDaysBg = if (activeDaysCount > 0) {
                            if (isDark) Color(0xFF1B3822) else HerbGreen.copy(alpha = 0.15f)
                        } else {
                            if (isDark) Color(0xFF3B1818) else Color(0xFFFFEBEE)
                        }
                        val activeDaysColor = if (activeDaysCount > 0) {
                            if (isDark) HerbGreenLight else HerbGreen
                        } else {
                            if (isDark) Color(0xFFFF8A80) else LockWarningRed
                        }

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = activeDaysBg
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(activeDaysColor)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "$activeDaysCount/7 Days Active",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = activeDaysColor
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Customize your morning routine. Toggle delivery ON or OFF for any individual day. Pause whenever you have plans or are traveling!",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // 10:30 PM Lock Policy pill
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isDark) Color(0xFF382315) else Color(0xFFFFF3E0),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Schedule,
                                contentDescription = null,
                                tint = if (isDark) SaffronLight else SaffronPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Daily Cutoff: Lock or pause days by 10:30 PM the previous night for fresh cooking.",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                                color = if (isDark) Color(0xFFFFCC80) else Color(0xFF795548)
                            )
                        }
                    }
                }
            }
        }

        // 2. Schedule Presets & Fast Toggles
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Quick Schedule Presets",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth().testTag("preset_chips_row")
                ) {
                    item {
                        FilterChip(
                            selected = (activeDaysCount == 7),
                            onClick = { onApplyPreset(SchedulePreset.ALL_7_DAYS) },
                            label = { Text("All 7 Days") },
                            leadingIcon = {
                                if (activeDaysCount == 7) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                }
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = SaffronPrimary,
                                selectedLabelColor = Color.White,
                                selectedLeadingIconColor = Color.White
                            ),
                            modifier = Modifier.testTag("preset_all_7_days")
                        )
                    }

                    item {
                        val weekdaysActive = days.filter { !it.isWeekend }.all { enabledDays.contains(it.dayIndex) } &&
                                days.filter { it.isWeekend }.none { enabledDays.contains(it.dayIndex) }
                        FilterChip(
                            selected = weekdaysActive,
                            onClick = { onApplyPreset(SchedulePreset.WEEKDAYS_ONLY) },
                            label = { Text("Weekdays (Mon-Fri)") },
                            leadingIcon = {
                                if (weekdaysActive) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                }
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = SaffronPrimary,
                                selectedLabelColor = Color.White,
                                selectedLeadingIconColor = Color.White
                            ),
                            modifier = Modifier.testTag("preset_weekdays_only")
                        )
                    }

                    item {
                        val weekendsActive = days.filter { it.isWeekend }.all { enabledDays.contains(it.dayIndex) } &&
                                days.filter { !it.isWeekend }.none { enabledDays.contains(it.dayIndex) }
                        FilterChip(
                            selected = weekendsActive,
                            onClick = { onApplyPreset(SchedulePreset.WEEKENDS_ONLY) },
                            label = { Text("Weekends Only") },
                            leadingIcon = {
                                if (weekendsActive) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                }
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = SaffronPrimary,
                                selectedLabelColor = Color.White,
                                selectedLeadingIconColor = Color.White
                            ),
                            modifier = Modifier.testTag("preset_weekends_only")
                        )
                    }

                    item {
                        val allPaused = activeDaysCount == 0
                        FilterChip(
                            selected = allPaused,
                            onClick = { onApplyPreset(SchedulePreset.PAUSE_ALL) },
                            label = { Text("Pause All") },
                            leadingIcon = {
                                if (allPaused) {
                                    Icon(Icons.Default.PauseCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                }
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF757575),
                                selectedLabelColor = Color.White,
                                selectedLeadingIconColor = Color.White
                            ),
                            modifier = Modifier.testTag("preset_pause_all")
                        )
                    }
                }
            }
        }

        // 3. Mini Week Calendar Overview Strip
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth().testTag("mini_week_calendar_strip")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp, horizontal = 8.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    val isDark = isSystemInDarkTheme()
                    days.forEach { day ->
                        val isEnabled = enabledDays.contains(day.dayIndex)
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.clickable { onCustomizeDay(day.dayIndex) }
                        ) {
                            Text(
                                text = day.shortDay.take(1),
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = if (isEnabled) (if (isDark) SaffronLight else SaffronPrimary) else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when {
                                            day.isPastCutoff -> if (isDark) Color(0xFF382F28) else Color(0xFFEEEEEE)
                                            isEnabled -> if (isDark) SaffronLight else SaffronPrimary
                                            else -> Color.Transparent
                                        }
                                    )
                                    .border(
                                        width = if (!isEnabled && !day.isPastCutoff) 1.dp else 0.dp,
                                        color = MaterialTheme.colorScheme.outlineVariant,
                                        shape = CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = day.dateDisplay.filter { it.isDigit() },
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    ),
                                    color = if (isEnabled && !day.isPastCutoff) {
                                        if (isDark) Color.Black else Color.White
                                    } else MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            // Small indicator dot
                            Box(
                                modifier = Modifier
                                    .size(5.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when {
                                            day.isPastCutoff -> if (isDark) Color(0xFFFF8A80) else LockWarningRed
                                            isEnabled -> if (isDark) HerbGreenLight else HerbGreen
                                            else -> if (isDark) Color(0xFF6E6359) else Color(0xFFBDBDBD)
                                        }
                                    )
                            )
                        }
                    }
                }
            }
        }

        // Section Title: Detailed 7-Day Schedule
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Daily Breakfast Deliveries",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Tap switch to toggle",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        // 4. Individual 7 Day Cards with On/Off Toggle
        itemsIndexed(days) { index, day ->
            val isEnabled = enabledDays.contains(index)
            val dayItems = dayCarts[index] ?: emptyList()
            val hasCustomItems = dayItems.isNotEmpty()

            val primaryMealTitle = if (hasCustomItems) {
                dayItems.joinToString(", ") { "${it.quantity}x ${it.dishName}" }
            } else {
                day.suggestedDish?.name ?: "Chef's Morning Special"
            }

            val portionSubtitle = if (hasCustomItems) {
                dayItems.firstOrNull()?.optionLabel ?: "Customized Selection"
            } else {
                day.suggestedDish?.options?.firstOrNull()?.label ?: "Fresh Breakfast Plate"
            }

            val dayPrice = if (hasCustomItems) {
                dayItems.sumOf { it.totalPrice }
            } else {
                day.suggestedDish?.options?.firstOrNull()?.price ?: 60.0
            }

            CalendarDayCard(
                day = day,
                isEnabled = isEnabled,
                mealTitle = primaryMealTitle,
                portionSubtitle = portionSubtitle,
                mealPrice = dayPrice,
                hasCustomItems = hasCustomItems,
                deliverySlot = deliverySlot,
                cutoffCountdown = cutoffCountdown,
                onToggle = { newState -> onToggleDay(index, newState) },
                onCustomize = { onCustomizeDay(index) }
            )
        }

        // 5. Subscription Summary Card & Checkout Button
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .testTag("subscription_summary_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Text(
                        text = "Subscription Summary",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Active Breakfast Deliveries", style = MaterialTheme.typography.bodyMedium)
                        Text("$activeDaysCount days scheduled", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Free Morning Delivery", style = MaterialTheme.typography.bodyMedium)
                        Text("FREE (Saved ₹${activeDaysCount * 25})", style = MaterialTheme.typography.bodyMedium.copy(color = HerbGreen, fontWeight = FontWeight.Bold))
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                    Button(
                        onClick = onProceedCheckout,
                        enabled = activeDaysCount > 0,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("confirm_subscription_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (activeDaysCount > 0)
                                    "Save & Confirm $activeDaysCount-Day Plan"
                                else
                                    "Toggle on at least 1 day to subscribe",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CalendarDayCard(
    day: DayScheduleInfo,
    isEnabled: Boolean,
    mealTitle: String,
    portionSubtitle: String,
    mealPrice: Double,
    hasCustomItems: Boolean,
    deliverySlot: String,
    cutoffCountdown: String,
    onToggle: (Boolean) -> Unit,
    onCustomize: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isDark = isSystemInDarkTheme()
    val borderColor by animateColorAsState(
        targetValue = when {
            day.isPastCutoff -> if (isDark) Color(0xFF423830) else Color(0xFFE0E0E0)
            isEnabled -> if (isDark) SaffronLight.copy(alpha = 0.8f) else SaffronPrimary.copy(alpha = 0.6f)
            else -> MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
        },
        animationSpec = tween(durationMillis = 250),
        label = "border_color"
    )

    val cardBgColor by animateColorAsState(
        targetValue = when {
            day.isPastCutoff -> if (isDark) Color(0xFF1E1814) else Color(0xFFF9F9F9)
            isEnabled -> MaterialTheme.colorScheme.surface
            else -> if (isDark) Color(0xFF1A1512) else Color(0xFFFAFAFA)
        },
        animationSpec = tween(durationMillis = 250),
        label = "bg_color"
    )

    Card(
        modifier = modifier
            .fillMaxWidth()
            .border(width = if (isEnabled && !day.isPastCutoff) 1.5.dp else 1.dp, color = borderColor, shape = RoundedCornerShape(18.dp))
            .testTag("calendar_day_card_${day.dayIndex}"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = cardBgColor),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isEnabled) 3.dp else 0.5.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Header: Day Label & Toggle Switch
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Day Date Badge
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = when {
                            day.isPastCutoff -> if (isDark) Color(0xFF2E251E) else Color(0xFFEEEEEE)
                            isEnabled -> if (isDark) SaffronPrimary.copy(alpha = 0.25f) else SaffronPrimary.copy(alpha = 0.12f)
                            else -> if (isDark) Color(0xFF261F1A) else Color(0xFFF0F0F0)
                        }
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = day.shortDay.uppercase(),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                ),
                                color = if (isEnabled && !day.isPastCutoff) {
                                    if (isDark) SaffronLight else SaffronPrimary
                                } else {
                                    if (isDark) Color(0xFFA89F95) else Color(0xFF757575)
                                }
                            )
                            Text(
                                text = day.dateDisplay.filter { it.isDigit() },
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 17.sp
                                ),
                                color = if (isEnabled && !day.isPastCutoff) {
                                    if (isDark) SaffronLight else SaffronPrimary
                                } else {
                                    if (isDark) Color(0xFFDDD2CB) else Color(0xFF424242)
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${day.dayOfWeek}, ${day.dateDisplay}",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = if (isEnabled) MaterialTheme.colorScheme.onSurface else (if (isDark) Color(0xFFA89F95) else Color(0xFF757575))
                            )

                            if (day.isToday || day.isTomorrow) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (day.isToday) (if (isDark) SaffronLight else SaffronPrimary) else (if (isDark) HerbGreenLight else HerbGreen)
                                ) {
                                    Text(
                                        text = if (day.isToday) "TODAY" else "TOMORROW",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = if (isDark) Color.Black else Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 9.sp
                                        ),
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(2.dp))

                        // Status subtitle pill
                        when {
                            day.isPastCutoff -> {
                                Text(
                                    text = "🔒 Cutoff Closed (10:30 PM passed)",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontSize = 11.sp,
                                        color = if (isDark) Color(0xFFFF8A80) else LockWarningRed,
                                        fontWeight = FontWeight.Medium
                                    )
                                )
                            }
                            isEnabled -> {
                                Text(
                                    text = "🟢 Delivery Active",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontSize = 11.sp,
                                        color = if (isDark) HerbGreenLight else HerbGreen,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                )
                            }
                            else -> {
                                Text(
                                    text = "⏸️ Delivery Paused / Skipped",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontSize = 11.sp,
                                        color = if (isDark) Color(0xFFFFB74D) else Color(0xFFF57C00),
                                        fontWeight = FontWeight.Medium
                                    )
                                )
                            }
                        }
                    }
                }

                // The Toggle Switch for Day On / Off
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(
                        checked = isEnabled,
                        onCheckedChange = { onToggle(it) },
                        enabled = !day.isPastCutoff,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = if (isDark) Color.Black else Color.White,
                            checkedTrackColor = if (isDark) SaffronLight else SaffronPrimary,
                            uncheckedThumbColor = if (isDark) Color(0xFF757575) else Color(0xFFBDBDBD),
                            uncheckedTrackColor = if (isDark) Color(0xFF382F28) else Color(0xFFE0E0E0),
                            disabledCheckedTrackColor = (if (isDark) SaffronLight else SaffronPrimary).copy(alpha = 0.5f),
                            disabledUncheckedTrackColor = if (isDark) Color(0xFF28211A) else Color(0xFFEEEEEE)
                        ),
                        modifier = Modifier.testTag("day_switch_${day.dayIndex}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
            Spacer(modifier = Modifier.height(10.dp))

            // Body: Meal Information or Paused Notice
            if (isEnabled && !day.isPastCutoff) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.RestaurantMenu,
                                contentDescription = null,
                                tint = if (isDark) SaffronLight else SaffronPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = mealTitle,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Spacer(modifier = Modifier.height(3.dp))

                        Text(
                            text = "$portionSubtitle • ₹${mealPrice.toInt()}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.DeliveryDining,
                                contentDescription = null,
                                tint = if (isDark) Color(0xFFA89F95) else Color(0xFF757575),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Slot: $deliverySlot",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // Customize Dish Button
                    OutlinedButton(
                        onClick = onCustomize,
                        modifier = Modifier.testTag("customize_button_${day.dayIndex}"),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Customize",
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (hasCustomItems) "Edit" else "Change",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            } else if (!isEnabled && !day.isPastCutoff) {
                // Paused State Content
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isDark) Color(0xFF382315) else Color(0xFFFFF8E1).copy(alpha = 0.7f))
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Delivery paused for ${day.shortDay}",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                            color = if (isDark) SaffronLight else Color(0xFFE65100)
                        )
                        Text(
                            text = "Kitchen will not prepare breakfast. No charges deducted.",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                            color = if (isDark) Color(0xFFDDD2CB) else Color(0xFF757575)
                        )
                    }

                    OutlinedButton(
                        onClick = { onToggle(true) },
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("resume_button_${day.dayIndex}")
                    ) {
                        Text(
                            "Resume",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isDark) SaffronLight else SaffronPrimary
                        )
                    }
                }
            } else {
                // Past Cutoff State Content
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isDark) Color(0xFF3B1818) else Color(0xFFFFEBEE))
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Locked",
                        tint = if (isDark) Color(0xFFFF8A80) else LockWarningRed,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Orders locked at 10:30 PM prior evening. Morning preparation in progress.",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                        color = if (isDark) Color(0xFFFF8A80) else Color(0xFFB71C1C)
                    )
                }
            }
        }
    }
}
