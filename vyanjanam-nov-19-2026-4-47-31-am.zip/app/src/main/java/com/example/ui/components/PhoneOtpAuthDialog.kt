package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MarkEmailRead
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.isSystemInDarkTheme
import com.example.ui.theme.HerbGreen
import com.example.ui.theme.SaffronDark
import com.example.ui.theme.SaffronPrimary
import com.example.ui.theme.SaffronLight
import com.example.viewmodel.KitchenViewModel

@Composable
fun PhoneOtpAuthDialog(
    authStep: KitchenViewModel.AuthStep,
    phoneInput: String,
    nameInput: String,
    otpInput: String,
    activeOtpCode: String?,
    otpTimerSeconds: Int,
    isSendingOtp: Boolean,
    errorMessage: String?,
    onPhoneChange: (String) -> Unit,
    onNameChange: (String) -> Unit,
    onOtpChange: (String) -> Unit,
    onSendOtp: () -> Unit,
    onResendOtp: () -> Unit,
    onAutoFillOtp: () -> Unit,
    onVerifyOtp: () -> Unit,
    onSwitchToGoogleSignIn: () -> Unit = {},
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .clip(RoundedCornerShape(28.dp))
                .testTag("phone_otp_auth_dialog"),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp)
            ) {
                // Top Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (authStep == KitchenViewModel.AuthStep.OTP_VERIFICATION) {
                        IconButton(
                            onClick = { onDismiss() },
                            modifier = Modifier.testTag("auth_back_btn")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    } else {
                        // Brand Icon Badge
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(SaffronPrimary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PhoneAndroid,
                                contentDescription = null,
                                tint = SaffronPrimary,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("auth_close_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                when (authStep) {
                    KitchenViewModel.AuthStep.PHONE_INPUT -> {
                        PhoneInputContent(
                            phoneInput = phoneInput,
                            nameInput = nameInput,
                            isSendingOtp = isSendingOtp,
                            errorMessage = errorMessage,
                            onPhoneChange = onPhoneChange,
                            onNameChange = onNameChange,
                            onSendOtp = onSendOtp,
                            onSwitchToGoogleSignIn = onSwitchToGoogleSignIn
                        )
                    }
                    KitchenViewModel.AuthStep.OTP_VERIFICATION -> {
                        OtpVerificationContent(
                            phoneInput = phoneInput,
                            otpInput = otpInput,
                            activeOtpCode = activeOtpCode,
                            otpTimerSeconds = otpTimerSeconds,
                            isSendingOtp = isSendingOtp,
                            errorMessage = errorMessage,
                            onOtpChange = onOtpChange,
                            onAutoFillOtp = onAutoFillOtp,
                            onResendOtp = onResendOtp,
                            onVerifyOtp = onVerifyOtp
                        )
                    }
                    KitchenViewModel.AuthStep.VERIFIED_SUCCESS -> {
                        VerifiedSuccessContent(nameInput = nameInput)
                    }
                }
            }
        }
    }
}

@Composable
private fun PhoneInputContent(
    phoneInput: String,
    nameInput: String,
    isSendingOtp: Boolean,
    errorMessage: String?,
    onPhoneChange: (String) -> Unit,
    onNameChange: (String) -> Unit,
    onSendOtp: () -> Unit,
    onSwitchToGoogleSignIn: () -> Unit = {}
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "Sign in to Vyanjanam",
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
        )

        Text(
            text = "Pure Ingredients , unmatched taste",
            style = MaterialTheme.typography.bodySmall.copy(
                fontStyle = FontStyle.Italic,
                color = SaffronDark
            ),
            modifier = Modifier.padding(top = 2.dp, bottom = 4.dp)
        )

        Text(
            text = "Enter your mobile number to receive an instant OTP for login and subscription management.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(18.dp))

        // Phone Number Input with +91 Prefix
        OutlinedTextField(
            value = phoneInput,
            onValueChange = onPhoneChange,
            label = { Text("Mobile Number") },
            placeholder = { Text("98765 43210") },
            leadingIcon = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(start = 12.dp, end = 6.dp)
                ) {
                    Text(text = "🇮🇳", fontSize = 18.sp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "+91",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(18.dp)
                            .background(MaterialTheme.colorScheme.outlineVariant)
                    )
                }
            },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Phone,
                imeAction = ImeAction.Next
            ),
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("auth_phone_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = SaffronPrimary,
                focusedLabelColor = SaffronPrimary
            )
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Optional Name input for profile personalization
        OutlinedTextField(
            value = nameInput,
            onValueChange = onNameChange,
            label = { Text("Your Name (Optional)") },
            placeholder = { Text("e.g. Saurabh M") },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Text,
                imeAction = ImeAction.Done
            ),
            keyboardActions = KeyboardActions(
                onDone = { if (phoneInput.length == 10 && !isSendingOtp) onSendOtp() }
            ),
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("auth_name_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = SaffronPrimary,
                focusedLabelColor = SaffronPrimary
            )
        )

        // Error message if any
        if (errorMessage != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = errorMessage,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Quick Demo Fill chip for instant testing
        val isDark = isSystemInDarkTheme()
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(if (isDark) MaterialTheme.colorScheme.surfaceVariant else Color(0xFFFFF8F0))
                .clickable {
                    onPhoneChange("9876543210")
                    if (nameInput.isBlank()) onNameChange("Saurabh M")
                }
                .padding(horizontal = 12.dp, vertical = 8.dp)
                .testTag("auth_demo_fill_btn"),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "⚡ Quick Test:",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                color = if (isDark) SaffronLight else SaffronDark
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "Tap to auto-fill +91 98765 43210",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Send OTP Button
        Button(
            onClick = onSendOtp,
            enabled = phoneInput.length == 10 && !isSendingOtp,
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("auth_send_otp_btn"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
        ) {
            if (isSendingOtp) {
                CircularProgressIndicator(
                    modifier = Modifier.size(22.dp),
                    color = Color.White,
                    strokeWidth = 2.dp
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text("Sending OTP via SMS...", fontWeight = FontWeight.Bold)
            } else {
                Text(
                    text = "Get OTP",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Security assurance
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Shield,
                contentDescription = null,
                tint = HerbGreen,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "Secure OTP verification • Zero spam guarantee",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
        Spacer(modifier = Modifier.height(14.dp))

        // Google Sign-In Alternative
        OutlinedButton(
            onClick = onSwitchToGoogleSignIn,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("switch_to_google_btn")
        ) {
            GoogleLogoIcon(modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(10.dp))
            Text("Sign in with Google", fontWeight = FontWeight.Bold, fontSize = 14.sp)
        }
    }
}

@Composable
private fun OtpVerificationContent(
    phoneInput: String,
    otpInput: String,
    activeOtpCode: String?,
    otpTimerSeconds: Int,
    isSendingOtp: Boolean,
    errorMessage: String?,
    onOtpChange: (String) -> Unit,
    onAutoFillOtp: () -> Unit,
    onResendOtp: () -> Unit,
    onVerifyOtp: () -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "Verify Mobile Number",
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(4.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "OTP sent to +91 $phoneInput",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Simulated SMS Message notification card with instant auto-fill button
        activeOtpCode?.let { code ->
            val isDark = isSystemInDarkTheme()
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, SaffronPrimary.copy(alpha = 0.4f), RoundedCornerShape(14.dp)),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant else Color(0xFFFFF9F2)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(SaffronPrimary.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.MarkEmailRead,
                                contentDescription = null,
                                tint = if (isDark) SaffronLight else SaffronPrimary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "SMS from VYANJANAM",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = if (isDark) SaffronLight else SaffronDark
                            )
                            Text(
                                text = "Code: $code",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 2.sp
                                ),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    Button(
                        onClick = onAutoFillOtp,
                        shape = RoundedCornerShape(20.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                        modifier = Modifier.testTag("auth_autofill_btn")
                    ) {
                        Text(
                            text = "Auto-Fill",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // 6 Digit Visual Display Boxes
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            for (i in 0 until 6) {
                val digitChar = otpInput.getOrNull(i)?.toString() ?: ""
                val isCurrent = otpInput.length == i
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            if (isCurrent) SaffronPrimary.copy(alpha = 0.08f)
                            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        )
                        .border(
                            width = if (isCurrent) 2.dp else 1.dp,
                            color = when {
                                errorMessage != null -> MaterialTheme.colorScheme.error
                                isCurrent -> SaffronPrimary
                                digitChar.isNotEmpty() -> SaffronDark
                                else -> MaterialTheme.colorScheme.outlineVariant
                            },
                            shape = RoundedCornerShape(10.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = digitChar,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Hidden / Transparent TextField capturing keyboard input
        OutlinedTextField(
            value = otpInput,
            onValueChange = onOtpChange,
            label = { Text("Enter 6-Digit OTP") },
            placeholder = { Text("e.g. 123456") },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.NumberPassword,
                imeAction = ImeAction.Done
            ),
            keyboardActions = KeyboardActions(
                onDone = { if (otpInput.length == 6) onVerifyOtp() }
            ),
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("auth_otp_input"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = SaffronPrimary,
                focusedLabelColor = SaffronPrimary
            )
        )

        // Error message if any
        if (errorMessage != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = errorMessage,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(horizontal = 4.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Timer and Resend Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (otpTimerSeconds > 0) {
                Text(
                    text = "Resend OTP in 0:${if (otpTimerSeconds < 10) "0$otpTimerSeconds" else "$otpTimerSeconds"}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                TextButton(
                    onClick = onResendOtp,
                    enabled = !isSendingOtp,
                    modifier = Modifier.testTag("auth_resend_otp_btn")
                ) {
                    Text(
                        text = "Resend OTP",
                        color = SaffronPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Verify & Sign In Button
        Button(
            onClick = onVerifyOtp,
            enabled = otpInput.length == 6 && !isSendingOtp,
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("auth_verify_btn"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
        ) {
            Text(
                text = "Verify & Proceed",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = Color.White
            )
        }
    }
}

@Composable
private fun VerifiedSuccessContent(nameInput: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(HerbGreen.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = "Success",
                tint = HerbGreen,
                modifier = Modifier.size(48.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Welcome to Vyanjanam!",
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = if (nameInput.isNotBlank()) "Signed in as $nameInput" else "Phone verified successfully!",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "Ready to explore pure ingredients and 7-day breakfast subscriptions.",
            style = MaterialTheme.typography.bodySmall,
            color = HerbGreen,
            textAlign = TextAlign.Center
        )
    }
}
