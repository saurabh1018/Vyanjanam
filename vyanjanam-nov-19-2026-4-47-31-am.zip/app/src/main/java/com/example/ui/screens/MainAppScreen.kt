package com.example.ui.screens

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.DeliveryDining
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import com.example.util.DeliveryLocationService
import com.example.model.SchedulePreset
import com.example.ui.components.AdminPasscodeDialog
import com.example.ui.components.GoogleSignInDialog
import com.example.ui.components.ItemCustomizeSheet
import com.example.ui.components.OrderReceiptDialog
import com.example.ui.components.PaymentGatewayDialog
import com.example.ui.components.PhoneOtpAuthDialog
import com.example.ui.components.TopKitchenBar
import com.example.ui.components.UserProfileSheet
import com.example.ui.theme.SaffronPrimary
import com.example.ui.theme.SaffronLight
import androidx.compose.foundation.isSystemInDarkTheme
import com.example.ui.components.AddressSelectionModal
import com.example.ui.components.AddressEntryMode
import com.example.ui.components.ChooseSavedAddressModal
import com.example.viewmodel.KitchenViewModel

@Composable
fun MainAppScreen(
    viewModel: KitchenViewModel,
    modifier: Modifier = Modifier
) {
    var currentNavTab by remember { mutableIntStateOf(0) }
    var adminUnlockedSession by remember { mutableStateOf(false) }
    var showAdminPasscodeDialog by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }

    val days by viewModel.daysSchedule.collectAsStateWithLifecycle()
    val enabledDays by viewModel.enabledDays.collectAsStateWithLifecycle()
    val selectedDayIndex by viewModel.selectedDayIndex.collectAsStateWithLifecycle()
    val dayCarts by viewModel.dayCarts.collectAsStateWithLifecycle()
    val cutoffText by viewModel.cutoffCountdownText.collectAsStateWithLifecycle()
    val orders by viewModel.orders.collectAsStateWithLifecycle()
    val walletBalance by viewModel.walletBalance.collectAsStateWithLifecycle()
    val deliveryAddress by viewModel.deliveryAddress.collectAsStateWithLifecycle()
    val savedAddresses by viewModel.savedAddresses.collectAsStateWithLifecycle()
    val deliverySlot by viewModel.deliverySlot.collectAsStateWithLifecycle()
    val autoLockEnabled by viewModel.autoLockEnabled.collectAsStateWithLifecycle()
    val firebaseSyncStatus by viewModel.firebaseSyncStatus.collectAsStateWithLifecycle()
    val databaseStatus by viewModel.databaseStatus.collectAsStateWithLifecycle()
    val menuDishes by viewModel.menuDishes.collectAsStateWithLifecycle()
    val scheduledItemsCount = dayCarts.values.sumOf { it.size }

    val context = LocalContext.current
    val deliveryLocationInfo by viewModel.deliveryLocationInfo.collectAsStateWithLifecycle()
    val isDetectingLocation by viewModel.isDetectingLocation.collectAsStateWithLifecycle()

    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true
        val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (fineGranted || coarseGranted) {
            viewModel.detectCurrentLocation(context)
        }
    }

    LaunchedEffect(Unit) {
        if (DeliveryLocationService.hasLocationPermission(context) && deliveryLocationInfo == null) {
            viewModel.detectCurrentLocation(context)
        }
    }

    val isLoggedIn by viewModel.isLoggedIn.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val showGoogleSignInDialog by viewModel.showGoogleSignInDialog.collectAsStateWithLifecycle()
    val isGoogleSigningIn by viewModel.isGoogleSigningIn.collectAsStateWithLifecycle()
    val googleAuthError by viewModel.googleAuthError.collectAsStateWithLifecycle()
    val showProfileSheet by viewModel.showProfileSheet.collectAsStateWithLifecycle()
    val showPhoneOtpDialog by viewModel.showPhoneOtpDialog.collectAsStateWithLifecycle()
    val authStep by viewModel.authStep.collectAsStateWithLifecycle()
    val phoneInput by viewModel.phoneInput.collectAsStateWithLifecycle()
    val authNameInput by viewModel.authNameInput.collectAsStateWithLifecycle()
    val otpInput by viewModel.otpInput.collectAsStateWithLifecycle()
    val activeOtpCode by viewModel.activeOtpCode.collectAsStateWithLifecycle()
    val otpTimerSeconds by viewModel.otpTimerSeconds.collectAsStateWithLifecycle()
    val isSendingOtp by viewModel.isSendingOtp.collectAsStateWithLifecycle()
    val phoneAuthError by viewModel.phoneAuthError.collectAsStateWithLifecycle()

    val customizingDish by viewModel.customizingDish.collectAsStateWithLifecycle()
    val activePaymentRequest by viewModel.activePaymentRequest.collectAsStateWithLifecycle()
    val showAddressChooserForOrder by viewModel.showAddressChooserForOrder.collectAsStateWithLifecycle()
    val showAddressSetupPrompt by viewModel.showAddressSetupPrompt.collectAsStateWithLifecycle()
    var showAddressModalInMain by remember { mutableStateOf(false) }
    val completedReceipt by viewModel.completedOrderReceipt.collectAsStateWithLifecycle()
    val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()

    val chefsWeeklyMenu by viewModel.chefsWeeklyMenu.collectAsStateWithLifecycle()
    val chefsRegularPrice by viewModel.chefsRegularPrice.collectAsStateWithLifecycle()
    val chefsJumboPrice by viewModel.chefsJumboPrice.collectAsStateWithLifecycle()

    LaunchedEffect(toastMessage) {
        toastMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearToast()
        }
    }

    val isSuperAdmin = (currentUser?.email?.equals("msaurabh1018@gmail.com", ignoreCase = true) == true) ||
                       (currentUser?.memberTier?.contains("Admin", ignoreCase = true) == true) ||
                       adminUnlockedSession

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopKitchenBar(
                walletBalance = walletBalance,
                cutoffText = cutoffText,
                onWalletClick = { currentNavTab = 3 },
                isLoggedIn = isLoggedIn,
                currentUser = currentUser,
                isAdminUser = isSuperAdmin,
                onSignInClick = { viewModel.openGoogleSignIn() },
                onProfileClick = { viewModel.openProfileSheet() },
                onAdminClick = {
                    if (isSuperAdmin) {
                        currentNavTab = 4
                    } else {
                        showAdminPasscodeDialog = true
                    }
                }
            )
        },
        bottomBar = {
            val isDark = isSystemInDarkTheme()
            val navSelectedColor = if (isDark) SaffronLight else SaffronPrimary
            val navIndicatorColor = if (isDark) Color(0xFF382315) else MaterialTheme.colorScheme.primaryContainer
            val navAdminSelectedColor = if (isDark) Color(0xFF90CAF9) else Color(0xFF0B2046)
            val navAdminIndicatorColor = if (isDark) Color(0xFF1E293B) else Color(0xFFE2E8F0)

            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier.testTag("main_bottom_nav")
            ) {
                NavigationBarItem(
                    selected = (currentNavTab == 0),
                    onClick = { currentNavTab = 0 },
                    icon = { Icon(Icons.Default.CalendarMonth, contentDescription = "Daily Planner") },
                    label = { Text("Daily Plan", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = navSelectedColor,
                        selectedTextColor = navSelectedColor,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        indicatorColor = navIndicatorColor
                    ),
                    modifier = Modifier.testTag("nav_tab_planner")
                )

                NavigationBarItem(
                    selected = (currentNavTab == 1),
                    onClick = { currentNavTab = 1 },
                    icon = { Icon(Icons.Default.RestaurantMenu, contentDescription = "Kitchen Menu") },
                    label = { Text("Menu", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = navSelectedColor,
                        selectedTextColor = navSelectedColor,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        indicatorColor = navIndicatorColor
                    ),
                    modifier = Modifier.testTag("nav_tab_menu")
                )

                NavigationBarItem(
                    selected = (currentNavTab == 2),
                    onClick = { currentNavTab = 2 },
                    icon = {
                        if (orders.isNotEmpty()) {
                            BadgedBox(badge = {
                                Badge(containerColor = SaffronPrimary) { Text("${orders.size}") }
                            }) {
                                Icon(Icons.Default.DeliveryDining, contentDescription = "My Orders")
                            }
                        } else {
                            Icon(Icons.Default.DeliveryDining, contentDescription = "My Orders")
                        }
                    },
                    label = { Text("Orders", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = navSelectedColor,
                        selectedTextColor = navSelectedColor,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        indicatorColor = navIndicatorColor
                    ),
                    modifier = Modifier.testTag("nav_tab_orders")
                )

                NavigationBarItem(
                    selected = (currentNavTab == 3),
                    onClick = { currentNavTab = 3 },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                    label = { Text("Settings", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = navSelectedColor,
                        selectedTextColor = navSelectedColor,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        indicatorColor = navIndicatorColor
                    ),
                    modifier = Modifier.testTag("nav_tab_wallet")
                )

                // Admin Dashboard Tab: Strictly restricted to authorized administrator
                if (isSuperAdmin) {
                    NavigationBarItem(
                        selected = (currentNavTab == 4),
                        onClick = { currentNavTab = 4 },
                        icon = { Icon(Icons.Default.AdminPanelSettings, contentDescription = "Admin Dashboard") },
                        label = { Text("Admin", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = navAdminSelectedColor,
                            selectedTextColor = navAdminSelectedColor,
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            indicatorColor = navAdminIndicatorColor
                        ),
                        modifier = Modifier.testTag("nav_tab_admin")
                    )
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Crossfade(targetState = currentNavTab, label = "tab_transition") { tab ->
                when (tab) {
                    0 -> WeeklyPlannerScreen(
                        days = days,
                        selectedDayIndex = selectedDayIndex,
                        dayCarts = dayCarts,
                        cutoffCountdown = cutoffText,
                        enabledDays = enabledDays,
                        deliverySlot = deliverySlot,
                        deliveryAddress = deliveryAddress,
                        dishes = menuDishes,
                        isAdmin = isSuperAdmin,
                        onToggleDishAvailability = { id, avail -> viewModel.toggleDishAvailability(id, avail) },
                        onAddDish = { name, subName, cat, desc, price, veg, avail ->
                            viewModel.addMenuDish(name, subName, cat, desc, price, veg, avail)
                        },
                        onRemoveDish = { id, name ->
                            viewModel.removeMenuDish(id, name)
                        },
                        onSelectDay = { viewModel.selectDay(it) },
                        onToggleDay = { dayIdx, enabled -> viewModel.toggleDayEnabled(dayIdx, enabled) },
                        onApplyPreset = { preset -> viewModel.setPresetSchedule(preset) },
                        onQuickAdd = { dish, option ->
                            viewModel.addItemToDay(
                                dayIndex = selectedDayIndex,
                                dish = dish,
                                option = option,
                                quantity = 1,
                                addOns = emptyList(),
                                spiceLevel = "Medium"
                            )
                        },
                        onCustomizeDish = { viewModel.startCustomizing(it) },
                        onRemoveItem = { dayIdx, itemIdx -> viewModel.removeItemFromDay(dayIdx, itemIdx) },
                        onCheckoutDay = { viewModel.onOrderLockClicked(it) },
                        chefsWeeklyMenu = chefsWeeklyMenu,
                        chefsRegularPrice = chefsRegularPrice,
                        chefsJumboPrice = chefsJumboPrice,
                        onSubscribeChefsWeeklyChoice = { isJumbo -> viewModel.openChefsWeeklyChoiceSubscription(isJumbo) }
                    )
                    1 -> KitchenMenuCatalogScreen(
                        dishes = menuDishes,
                        isAdmin = isSuperAdmin,
                        onToggleDishAvailability = { id, avail -> viewModel.toggleDishAvailability(id, avail) },
                        onAddDish = { name, subName, cat, desc, price, veg, avail ->
                            viewModel.addMenuDish(name, subName, cat, desc, price, veg, avail)
                        },
                        onRemoveDish = { id, name ->
                            viewModel.removeMenuDish(id, name)
                        },
                        onCustomizeDish = {
                            viewModel.startCustomizing(it)
                            currentNavTab = 0
                        }
                    )
                    2 -> OrdersTrackingScreen(
                        orders = orders,
                        onLockOrder = { viewModel.lockOrder(it) },
                        onViewReceipt = { /* handled by receipt dialog */ }
                    )
                    3 -> WalletSubscriptionScreen(
                        walletBalance = walletBalance,
                        deliveryAddress = deliveryAddress,
                        deliverySlot = deliverySlot,
                        autoLockEnabled = autoLockEnabled,
                        onTopUp = { viewModel.topUpWallet(it) },
                        onUpdateAddress = { viewModel.updateDeliveryAddress(it, context) },
                        onUpdatePinnedLocation = { lat, lng, detail -> viewModel.updatePinnedLocation(lat, lng, detail, context) },
                        onUpdateSlot = { viewModel.updateDeliverySlot(it) },
                        onToggleAutoLock = { viewModel.toggleAutoLock(it) },
                        isLoggedIn = isLoggedIn,
                        currentUser = currentUser,
                        onSignInClick = { viewModel.openGoogleSignIn() },
                        onSignOutClick = { viewModel.signOut() },
                        onProfileClick = { viewModel.openProfileSheet() },
                        firebaseSyncStatus = firebaseSyncStatus,
                        onCloudSyncClick = { viewModel.triggerCloudSync() },
                        databaseStatus = databaseStatus,
                        ordersCount = orders.size,
                        scheduledItemsCount = scheduledItemsCount,
                        locationInfo = deliveryLocationInfo,
                        isDetectingLocation = isDetectingLocation,
                        onDetectLocation = {
                            if (DeliveryLocationService.hasLocationPermission(context)) {
                                viewModel.detectCurrentLocation(context)
                            } else {
                                locationPermissionLauncher.launch(
                                    arrayOf(
                                        Manifest.permission.ACCESS_FINE_LOCATION,
                                        Manifest.permission.ACCESS_COARSE_LOCATION
                                    )
                                )
                            }
                        },
                        userPhoneNumber = currentUser?.phoneNumber ?: "+91 98765 43210",
                        onUpdatePhoneNumber = { viewModel.updatePhoneNumber(it) }
                    )
                    4 -> {
                        if (isSuperAdmin) {
                            AdminDashboardScreen(
                                orders = orders,
                                onUpdateOrderStatus = { id, status -> viewModel.updateOrderStatus(id, status) },
                                onLockOrder = { id -> viewModel.lockOrder(id) },
                                onBackToApp = { currentNavTab = 0 },
                                firebaseSyncStatus = firebaseSyncStatus,
                                dishes = menuDishes,
                                onToggleDishAvailability = { id, avail -> viewModel.toggleDishAvailability(id, avail) },
                                onAddDish = { name, subName, cat, desc, price, veg, avail ->
                                    viewModel.addMenuDish(name, subName, cat, desc, price, veg, avail)
                                },
                                onRemoveDish = { id, name ->
                                    viewModel.removeMenuDish(id, name)
                                },
                                onUpdateDishPrice = { id, options ->
                                    val dishName = menuDishes.find { it.id == id }?.name ?: ""
                                    viewModel.updateDishPrice(id, options, dishName)
                                },
                                onVerifyPayment = { id, orderNum ->
                                    viewModel.verifyManualPayment(id, orderNum)
                                },
                                onRotateChefsDish = { id, current ->
                                    viewModel.rotateChefsChoiceOrderDish(id, current)
                                },
                                chefsWeeklyMenu = chefsWeeklyMenu,
                                chefsRegularPrice = chefsRegularPrice,
                                chefsJumboPrice = chefsJumboPrice,
                                onUpdateChefsWeeklyDish = { dayIdx, dishName ->
                                    viewModel.updateChefsWeeklyDayDish(dayIdx, dishName)
                                },
                                onResetChefsWeeklyMenu = {
                                    viewModel.resetChefsWeeklyMenu()
                                },
                                onUpdateChefsPrices = { reg, jumbo ->
                                    viewModel.updateChefsWeeklyPrices(reg, jumbo)
                                }
                            )
                        } else {
                            currentNavTab = 0
                            showAdminPasscodeDialog = true
                        }
                    }
                }
            }

            // Customization Modal
            customizingDish?.let { dish ->
                val dayInfo = days.getOrNull(selectedDayIndex)
                ItemCustomizeSheet(
                    dish = dish,
                    targetDayName = dayInfo?.shortDay ?: "Day",
                    onDismiss = { viewModel.closeCustomizing() },
                    onConfirm = { option, quantity, addOns, spiceLevel ->
                        viewModel.addItemToDay(
                            dayIndex = selectedDayIndex,
                            dish = dish,
                            option = option,
                            quantity = quantity,
                            addOns = addOns,
                            spiceLevel = spiceLevel
                        )
                    }
                )
            }

            // Payment Gateway Modal
            activePaymentRequest?.let { req ->
                PaymentGatewayDialog(
                    request = req,
                    walletBalance = walletBalance,
                    deliveryAddress = deliveryAddress,
                    locationInfo = deliveryLocationInfo,
                    customerPhoneNumber = currentUser?.phoneNumber ?: "+91 98765 43210",
                    savedAddresses = savedAddresses,
                    onDismiss = { viewModel.closePaymentGateway() },
                    onPaymentSuccess = { method, details, shouldLock, isVerified, txnId, chosenAddress, lat, lng, dist ->
                        viewModel.completePayment(method, details, shouldLock, isVerified, txnId, chosenAddress, lat, lng, dist)
                    }
                )
            }

            // Choose Saved Address Modal (when locking order and user has multiple saved addresses)
            showAddressChooserForOrder?.let { dayIdx ->
                ChooseSavedAddressModal(
                    savedAddresses = savedAddresses,
                    onSelectAddress = { chosenAddr ->
                        viewModel.selectAddressForOrderAndProceed(chosenAddr, dayIdx)
                    },
                    onAddNewAddress = {
                        viewModel.closeAddressChooser()
                        showAddressModalInMain = true
                    },
                    onDismiss = { viewModel.closeAddressChooser() }
                )
            }

            // Address Setup Prompt (when user signs in/up with 0 addresses or adds address)
            if (showAddressSetupPrompt || showAddressModalInMain) {
                AddressSelectionModal(
                    initialMode = AddressEntryMode.DETECT_GPS,
                    editingAddress = null,
                    currentAddress = deliveryAddress,
                    currentLocationInfo = deliveryLocationInfo,
                    onSavePinnedLocation = { id, label, lat, lng, detail, isDefault ->
                        viewModel.savePinnedLocation(id, label, lat, lng, detail, isDefault)
                        viewModel.closeAddressSetupPrompt()
                        showAddressModalInMain = false
                    },
                    onSaveManualAddress = { id, label, flat, bld, street, area, landmark, pin, isDefault ->
                        viewModel.saveManualAddress(
                            id = id,
                            label = label,
                            flatDoor = flat,
                            buildingSociety = bld,
                            street = street,
                            area = area,
                            landmark = landmark,
                            pincode = pin,
                            isDefault = isDefault
                        )
                        viewModel.closeAddressSetupPrompt()
                        showAddressModalInMain = false
                    },
                    onDismiss = {
                        viewModel.closeAddressSetupPrompt()
                        showAddressModalInMain = false
                    }
                )
            }

            // Order Receipt Dialog
            completedReceipt?.let { receipt ->
                OrderReceiptDialog(
                    order = receipt,
                    onDismiss = { viewModel.dismissReceipt() },
                    onTrackOrder = {
                        viewModel.dismissReceipt()
                        currentNavTab = 2 // Switch to Orders tab
                    }
                )
            }

            // Google Sign-In & Registration Dialog
            if (showGoogleSignInDialog) {
                GoogleSignInDialog(
                    isLoading = isGoogleSigningIn,
                    errorMessage = googleAuthError,
                    cloudSyncStatus = firebaseSyncStatus,
                    onSignIn = { email, pass, name -> viewModel.signInWithGoogle(email, pass, name) },
                    onRegister = { name, email, pass, phone, address, slot ->
                        viewModel.registerNewUser(name, email, pass, phone, address, slot)
                    },
                    onSwitchToPhoneOtp = { viewModel.openPhoneOtp() },
                    onDismiss = { viewModel.closeGoogleSignIn() }
                )
            }

            // Phone OTP Auth Dialog
            if (showPhoneOtpDialog) {
                PhoneOtpAuthDialog(
                    authStep = authStep,
                    phoneInput = phoneInput,
                    nameInput = authNameInput,
                    otpInput = otpInput,
                    activeOtpCode = activeOtpCode,
                    otpTimerSeconds = otpTimerSeconds,
                    isSendingOtp = isSendingOtp,
                    errorMessage = phoneAuthError,
                    onPhoneChange = { viewModel.setPhoneInput(it) },
                    onNameChange = { viewModel.setAuthNameInput(it) },
                    onOtpChange = { viewModel.setOtpInput(it) },
                    onSendOtp = { viewModel.sendPhoneOtp() },
                    onResendOtp = { viewModel.sendPhoneOtp() },
                    onAutoFillOtp = { viewModel.setOtpInput(activeOtpCode ?: "7412") },
                    onVerifyOtp = { viewModel.verifyPhoneOtp() },
                    onSwitchToGoogleSignIn = { viewModel.openGoogleSignIn() },
                    onDismiss = { viewModel.closePhoneOtp() }
                )
            }

            // User Profile Sheet
            if (showProfileSheet && currentUser != null) {
                UserProfileSheet(
                    user = currentUser!!,
                    walletBalance = walletBalance,
                    savedAddress = deliveryAddress,
                    deliverySlot = deliverySlot,
                    savedAddresses = savedAddresses,
                    isAdminUser = isSuperAdmin,
                    locationInfo = deliveryLocationInfo,
                    isDetectingLocation = isDetectingLocation,
                    onDetectLocation = {
                        if (DeliveryLocationService.hasLocationPermission(context)) {
                            viewModel.detectCurrentLocation(context)
                        } else {
                            locationPermissionLauncher.launch(
                                arrayOf(
                                    Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION
                                )
                            )
                        }
                    },
                    onOpenAdminPortal = {
                        viewModel.closeProfileSheet()
                        if (isSuperAdmin) {
                            currentNavTab = 4
                        } else {
                            showAdminPasscodeDialog = true
                        }
                    },
                    onDismiss = { viewModel.closeProfileSheet() },
                    onUpdateProfile = { name, email -> viewModel.updateProfile(name, email) },
                    onUpdatePhoneNumber = { viewModel.updatePhoneNumber(it) },
                    onUpdateAddress = { viewModel.updateDeliveryAddress(it, context) },
                    onUpdatePinnedLocation = { lat, lng, detail -> viewModel.updatePinnedLocation(lat, lng, detail, context) },
                    onSaveManualAddress = { id, label, flat, bld, street, area, landmark, pin, isDefault ->
                        viewModel.saveManualAddress(
                            id = id,
                            label = label,
                            flatDoor = flat,
                            buildingSociety = bld,
                            street = street,
                            area = area,
                            landmark = landmark,
                            pincode = pin,
                            isDefault = isDefault
                        )
                    },
                    onSavePinnedLocation = { id, label, lat, lng, detail, isDefault ->
                        viewModel.savePinnedLocation(
                            id = id,
                            label = label,
                            lat = lat,
                            lng = lng,
                            buildingDetail = detail,
                            isDefault = isDefault
                        )
                    },
                    onDeleteAddress = { viewModel.deleteAddress(it) },
                    onSetDefaultAddress = { viewModel.setDefaultAddress(it) },
                    onSignOut = { viewModel.signOut() },
                    onDeleteAccount = { viewModel.deleteUserAccount() }
                )
            }

            // Admin Passcode Security Gate
            if (showAdminPasscodeDialog) {
                AdminPasscodeDialog(
                    userEmail = currentUser?.email,
                    onUnlocked = {
                        adminUnlockedSession = true
                        showAdminPasscodeDialog = false
                        currentNavTab = 4
                    },
                    onDismiss = { showAdminPasscodeDialog = false }
                )
            }
        }
    }
}
