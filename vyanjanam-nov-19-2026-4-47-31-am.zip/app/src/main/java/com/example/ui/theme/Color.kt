package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Warm culinary cloud kitchen palette - Saffron, Butter Gold, Herb Green, Rich Charcoal
val SaffronPrimary = Color(0xFFE65100)
val SaffronLight = Color(0xFFFF833A)
val SaffronDark = Color(0xFFAC1900)

val ButterAmber = Color(0xFFFFB300)
val ButterAmberLight = Color(0xFFFFE082)

val HerbGreen = Color(0xFF2E7D32)
val HerbGreenLight = Color(0xFFA5D6A7)
val HerbGreenContainer = Color(0xFFE8F5E9)

val WarmCreamBackground = Color(0xFFFAF7F2)
val WarmCardSurface = Color(0xFFFFFFFF)
val WarmCardElevated = Color(0xFFFFF8F0)

val CharcoalText = Color(0xFF212121)
val CharcoalSubtext = Color(0xFF616161)
val WarmOutline = Color(0xFFE0D7CD)

val LockWarningRed = Color(0xFFD32F2F)
val LockWarningContainer = Color(0xFFFFEBEE)
val LockAmber = Color(0xFFEF6C00)
val LockAmberContainer = Color(0xFFFFF3E0)

val GoldenYellow = Color(0xFFFBC02D)
val DeliveryBlue = Color(0xFF1976D2)
