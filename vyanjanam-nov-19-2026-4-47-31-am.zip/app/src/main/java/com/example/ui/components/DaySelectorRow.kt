package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DayScheduleInfo
import com.example.model.SelectedMealItem
import com.example.ui.theme.HerbGreen
import com.example.ui.theme.HerbGreenLight
import com.example.ui.theme.SaffronPrimary
import com.example.ui.theme.SaffronLight
import androidx.compose.foundation.isSystemInDarkTheme

@Composable
fun DaySelectorRow(
    days: List<DayScheduleInfo>,
    selectedDayIndex: Int,
    dayCarts: Map<Int, List<SelectedMealItem>>,
    enabledDays: Set<Int> = emptySet(),
    onDaySelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val isDark = isSystemInDarkTheme()
    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Select your own daily Breakfast",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("day_selector_row"),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            itemsIndexed(days) { index, day ->
                val isSelected = (index == selectedDayIndex)
                val isEnabled = enabledDays.isEmpty() || enabledDays.contains(index)
                val itemsForDay = dayCarts[index] ?: emptyList()
                val itemCount = itemsForDay.sumOf { it.quantity }

                val backgroundColor = when {
                    isSelected -> if (isDark) SaffronLight else SaffronPrimary
                    day.isPastCutoff -> if (isDark) Color(0xFF2A231C) else Color(0xFFF0EBE5)
                    !isEnabled -> if (isDark) Color(0xFF201B17) else Color(0xFFF5F5F5)
                    else -> MaterialTheme.colorScheme.surface
                }

                val contentColor = when {
                    isSelected -> if (isDark) Color.Black else Color.White
                    day.isPastCutoff -> if (isDark) Color(0xFF8D8379) else Color(0xFF9E9E9E)
                    !isEnabled -> if (isDark) Color(0xFF8D8379) else Color(0xFF9E9E9E)
                    else -> MaterialTheme.colorScheme.onSurface
                }

                Card(
                    modifier = Modifier
                        .width(72.dp)
                        .testTag("day_pill_$index")
                        .clickable { onDaySelected(index) },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = backgroundColor),
                    elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 4.dp else 1.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 10.dp, horizontal = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = if (day.isToday) "Today" else if (day.isTomorrow) "Tmrw" else day.shortDay,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium
                            ),
                            color = contentColor
                        )

                        Spacer(modifier = Modifier.height(2.dp))

                        Text(
                            text = day.dateDisplay.replace("Oct ", ""),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            ),
                            color = contentColor
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        // Status dot or badge
                        when {
                            day.isPastCutoff -> {
                                Text(
                                    text = "Closed",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                    color = if (isDark) Color(0xFFFF8A80) else Color(0xFFD32F2F)
                                )
                            }
                            !isEnabled -> {
                                Text(
                                    text = "Paused",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                    color = if (isDark) Color(0xFFFFB74D) else Color(0xFFF57C00)
                                )
                            }
                            itemCount > 0 -> {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            if (isSelected) {
                                                if (isDark) Color.Black.copy(alpha = 0.2f) else Color.White.copy(alpha = 0.3f)
                                            } else {
                                                (if (isDark) HerbGreenLight else HerbGreen).copy(alpha = 0.2f)
                                            }
                                        )
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "$itemCount items",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        color = if (isSelected) {
                                            if (isDark) Color.Black else Color.White
                                        } else {
                                            if (isDark) HerbGreenLight else HerbGreen
                                        }
                                    )
                                }
                            }
                            else -> {
                                Text(
                                    text = "Open",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                    color = if (isSelected) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
