package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.LockClock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.filled.AdminPanelSettings
import com.example.model.UserProfile
import com.example.ui.theme.HerbGreen
import com.example.ui.theme.HerbGreenLight
import com.example.ui.theme.SaffronPrimary
import com.example.ui.theme.SaffronLight
import com.example.ui.theme.SatisfyScriptFont

@Composable
fun TopKitchenBar(
    walletBalance: Double,
    cutoffText: String,
    onWalletClick: () -> Unit,
    isLoggedIn: Boolean = false,
    currentUser: UserProfile? = null,
    isAdminUser: Boolean = false,
    onSignInClick: () -> Unit = {},
    onProfileClick: () -> Unit = {},
    onAdminClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val isDark = isSystemInDarkTheme()
    val barBg = if (isDark) MaterialTheme.colorScheme.surface else Color(0xFFF7F2EA)
    val barBorder = if (isDark) MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f) else Color(0xFFE8DFD0)
    val brandTextColor = if (isDark) Color(0xFFFFD180) else Color(0xFF0F2552)
    val taglineColor = if (isDark) Color(0xFFEDE0D4).copy(alpha = 0.85f) else Color(0xFF0F2552).copy(alpha = 0.9f)
    val vmBadgeBg = if (isDark) MaterialTheme.colorScheme.surfaceVariant else Color.White
    val vmBadgeBorder = if (isDark) MaterialTheme.colorScheme.outlineVariant else Color(0xFFE2DCD2)
    val vmLetterV = if (isDark) Color(0xFF90CAF9) else Color(0xFF0F2653)
    val vmLetterM = if (isDark) SaffronLight else Color(0xFFEA580C)

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = barBg,
        tonalElevation = 2.dp,
        shadowElevation = 3.dp,
        border = BorderStroke(1.dp, barBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Simple two-letter "VM" brand icon badge
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(vmBadgeBg)
                            .border(BorderStroke(1.5.dp, vmBadgeBorder), RoundedCornerShape(12.dp))
                            .testTag("app_brand_vm_badge"),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "V",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Black,
                                    fontSize = 20.sp
                                ),
                                color = vmLetterV
                            )
                            Text(
                                text = "M",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Black,
                                    fontSize = 20.sp
                                ),
                                color = vmLetterM
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Name in scripted font (high-contrast in both day and night mode)
                            Text(
                                text = "Vyanjanam",
                                fontFamily = SatisfyScriptFont,
                                fontSize = 28.sp,
                                fontWeight = FontWeight.Bold,
                                color = brandTextColor,
                                modifier = Modifier.testTag("brand_name_scripted")
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            // Veg green badge indicator
                            Box(
                                modifier = Modifier
                                    .size(16.dp)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(HerbGreen.copy(alpha = if (isDark) 0.3f else 0.15f))
                                    .border(BorderStroke(1.dp, if (isDark) HerbGreenLight else HerbGreen), RoundedCornerShape(3.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(if (isDark) HerbGreenLight else HerbGreen)
                                )
                            }
                        }

                        // Tagline: "Bringing Family Closer in Every Meal"
                        Text(
                            text = "Bringing Family Closer in Every Meal",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 11.5.sp
                            ),
                            color = taglineColor,
                            modifier = Modifier.testTag("brand_tagline_text")
                        )

                        // Curved slanting line beneath the tagline
                        Canvas(
                            modifier = Modifier
                                .width(200.dp)
                                .height(6.dp)
                                .padding(top = 1.dp)
                                .testTag("tagline_curved_slanting_line")
                        ) {
                            val w = size.width
                            val h = size.height
                            val path = Path().apply {
                                // Starts on left baseline, slopes with a gentle downward curve, then slants upward to the right
                                moveTo(0f, h * 0.7f)
                                quadraticTo(
                                    w * 0.55f, h * 1.05f,
                                    w * 0.98f, h * 0.15f
                                )
                            }
                            drawPath(
                                path = path,
                                brush = Brush.horizontalGradient(
                                    colors = listOf(
                                        Color(0xFFEA580C),
                                        Color(0xFFF97316),
                                        Color(0xFFFB923C)
                                    )
                                ),
                                style = Stroke(
                                    width = 2.4.dp.toPx(),
                                    cap = StrokeCap.Round
                                )
                            )
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Profile / Sign-in Pill
                    if (isLoggedIn) {
                        Card(
                            modifier = Modifier
                                .testTag("top_bar_profile_btn")
                                .clickable { onProfileClick() },
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = HerbGreen.copy(alpha = 0.12f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(20.dp)
                                        .clip(CircleShape)
                                        .background(HerbGreen),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = currentUser?.name?.firstOrNull()?.uppercase() ?: "U",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = Color.White
                                    )
                                }
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = currentUser?.name?.split(" ")?.firstOrNull() ?: "Profile",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = HerbGreen
                                )
                            }
                        }
                    } else {
                        Card(
                            modifier = Modifier
                                .testTag("top_bar_signin_btn")
                                .clickable { onSignInClick() },
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = SaffronPrimary)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PhoneAndroid,
                                    contentDescription = "Sign In",
                                    tint = Color.White,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Sign In",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = Color.White
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Wallet Chip button
                    Card(
                        modifier = Modifier
                            .testTag("wallet_balance_pill")
                            .clickable { onWalletClick() },
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isDark) SaffronPrimary.copy(alpha = 0.25f) else MaterialTheme.colorScheme.primaryContainer
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountBalanceWallet,
                                contentDescription = "Wallet",
                                tint = if (isDark) SaffronLight else SaffronPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = "₹${walletBalance.toInt()}",
                                style = MaterialTheme.typography.labelLarge.copy(
                                    fontWeight = FontWeight.Bold
                                ),
                                color = if (isDark) SaffronLight else SaffronPrimary
                            )
                        }
                    }

                    // Admin Portal Button (Visible only to authorized Kitchen Admin)
                    if (isAdminUser) {
                        Spacer(modifier = Modifier.width(6.dp))

                        Card(
                            modifier = Modifier
                                .testTag("top_bar_admin_portal_btn")
                                .clickable { onAdminClick() },
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isDark) Color(0xFF1E293B) else Color(0xFF0B2046)
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AdminPanelSettings,
                                    contentDescription = "Admin Portal",
                                    tint = Color(0xFFFBBF24),
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Admin",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = Color.White
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Cutoff Reminder Strip (Theme aware)
            val cutoffStripBg = if (isDark) Color(0xFF382315) else Color(0xFFFFF3E0)
            val cutoffTextColor = if (isDark) Color(0xFFFFCC80) else Color(0xFFBF360C)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(cutoffStripBg)
                    .padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.LockClock,
                    contentDescription = "Lock Cutoff",
                    tint = if (isDark) SaffronLight else SaffronPrimary,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Cutoff 10:30 PM prior day • $cutoffText",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                    color = cutoffTextColor
                )
            }
        }
    }
}
