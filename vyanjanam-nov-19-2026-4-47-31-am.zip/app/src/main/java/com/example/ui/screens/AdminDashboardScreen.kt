package com.example.ui.screens

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.ui.platform.LocalContext
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.DeliveryDining
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockClock
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.OutdoorGrill
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Web
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.ui.text.style.TextOverflow
import com.example.ui.components.AddMenuDishDialog
import com.example.ui.components.EditDishPriceDialog
import com.example.model.PortionOption
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.TextButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.PlainTooltip
import androidx.compose.material3.TooltipBox
import androidx.compose.material3.TooltipDefaults
import androidx.compose.material3.rememberTooltipState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.pointerInput
import com.example.model.MenuDish
import com.example.data.entity.OrderEntity
import com.example.ui.theme.HerbGreen
import com.example.ui.theme.HerbGreenLight
import com.example.ui.theme.SaffronPrimary
import com.example.ui.theme.SaffronLight

enum class AdminViewMode {
    NATIVE_KDS,
    MENU_AVAILABILITY,
    CHEFS_CHOICE,
    WEB_DASHBOARD
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    orders: List<OrderEntity>,
    onUpdateOrderStatus: (Long, String) -> Unit,
    onLockOrder: (Long) -> Unit,
    onBackToApp: () -> Unit,
    firebaseSyncStatus: String = "Connected to Firebase Cloud Firestore",
    dishes: List<MenuDish> = emptyList(),
    onToggleDishAvailability: ((String, Boolean) -> Unit)? = null,
    onAddDish: ((String, String, String, String, Double, Boolean, Boolean) -> Unit)? = null,
    onRemoveDish: ((String, String) -> Unit)? = null,
    onUpdateDishPrice: ((String, List<PortionOption>) -> Unit)? = null,
    onVerifyPayment: ((Long, String) -> Unit)? = null,
    onRotateChefsDish: ((Long, String) -> Unit)? = null,
    chefsWeeklyMenu: List<String> = emptyList(),
    chefsRegularPrice: Double = 599.0,
    chefsJumboPrice: Double = 950.0,
    onUpdateChefsWeeklyDish: ((Int, String) -> Unit)? = null,
    onResetChefsWeeklyMenu: (() -> Unit)? = null,
    onUpdateChefsPrices: ((Double, Double) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    BackHandler {
        onBackToApp()
    }

    var viewMode by remember { mutableStateOf(AdminViewMode.NATIVE_KDS) }
    val context = LocalContext.current
    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    val webAdminUrl = "https://ais-dev-r7gjw3nl453pxqyx5dng3i-405640621688.asia-east1.run.app"

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(if (isSystemInDarkTheme()) MaterialTheme.colorScheme.background else Color(0xFFF8FAFC))
            .testTag("admin_dashboard_screen")
    ) {
        // 1. Top Header Command Bar
        Surface(
            color = Color(0xFF0B2046),
            tonalElevation = 6.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFF16366E),
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onBackToApp() }
                                .testTag("admin_back_btn")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back to Client Menu",
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Menu",
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "VYANJANAM",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        letterSpacing = 1.sp
                                    ),
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = SaffronPrimary,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "ADMIN",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 9.sp
                                        ),
                                        color = Color(0xFF0B2046),
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = "Authorized Kitchen & Admin Operations",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.5.sp),
                                color = Color(0xFF94A3B8)
                            )
                        }
                    }

                    // Direct shortcut to launch Web Portal in external browser
                    OutlinedButton(
                        onClick = {
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(webAdminUrl))
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "Could not open browser", Toast.LENGTH_SHORT).show()
                            }
                        },
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, Color(0xFFC69F54)),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFC69F54)),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("admin_open_browser_btn")
                    ) {
                        Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(13.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Browser", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 2. High-Visibility Full-Width Segmented Tab Bar (Kitchen KDS | Menu Items | Chef's Choice | Web Hub)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF16366E), RoundedCornerShape(10.dp))
                        .padding(3.dp),
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    // TAB 1: KITCHEN KDS
                    val isKds = viewMode == AdminViewMode.NATIVE_KDS
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isKds) SaffronPrimary else Color.Transparent,
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { viewMode = AdminViewMode.NATIVE_KDS }
                            .testTag("admin_tab_kds_btn")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxSize(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.OutdoorGrill,
                                contentDescription = null,
                                tint = if (isKds) Color(0xFF0B2046) else Color(0xFFCBD5E1),
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "KDS",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                fontSize = 11.5.sp,
                                color = if (isKds) Color(0xFF0B2046) else Color(0xFFCBD5E1)
                            )
                        }
                    }

                    // TAB 2: MENU ITEMS
                    val isMenu = viewMode == AdminViewMode.MENU_AVAILABILITY
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isMenu) SaffronPrimary else Color.Transparent,
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { viewMode = AdminViewMode.MENU_AVAILABILITY }
                            .testTag("admin_tab_menu_btn")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxSize(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.RestaurantMenu,
                                contentDescription = null,
                                tint = if (isMenu) Color(0xFF0B2046) else Color(0xFFCBD5E1),
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Menu",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                fontSize = 11.5.sp,
                                color = if (isMenu) Color(0xFF0B2046) else Color(0xFFCBD5E1)
                            )
                        }
                    }

                    // TAB 3: CHEF'S CHOICE (Customizable 7-Day Lineup & Packages)
                    val isChefs = viewMode == AdminViewMode.CHEFS_CHOICE
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isChefs) SaffronPrimary else Color.Transparent,
                        modifier = Modifier
                            .weight(1.15f)
                            .height(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { viewMode = AdminViewMode.CHEFS_CHOICE }
                            .testTag("admin_tab_chefs_choice_btn")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxSize(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = if (isChefs) Color(0xFF0B2046) else Color(0xFFCBD5E1),
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Chef's Plan",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                fontSize = 11.sp,
                                color = if (isChefs) Color(0xFF0B2046) else Color(0xFFCBD5E1)
                            )
                        }
                    }

                    // TAB 4: WEB HUB
                    val isWeb = viewMode == AdminViewMode.WEB_DASHBOARD
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isWeb) SaffronPrimary else Color.Transparent,
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { viewMode = AdminViewMode.WEB_DASHBOARD }
                            .testTag("admin_tab_web_hub_btn")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxSize(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Web,
                                contentDescription = null,
                                tint = if (isWeb) Color(0xFF0B2046) else Color(0xFFCBD5E1),
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Web Hub",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                fontSize = 11.5.sp,
                                color = if (isWeb) Color(0xFF0B2046) else Color(0xFFCBD5E1)
                            )
                        }
                    }
                }
            }
        }

        // View Mode Conditional Display
        when (viewMode) {
            AdminViewMode.NATIVE_KDS -> {
                // Native Kitchen Display System (KDS) & Advance Order Pipeline
                KitchenDisplaySystemView(
                    orders = orders,
                    onUpdateOrderStatus = onUpdateOrderStatus,
                    onLockOrder = onLockOrder,
                    onVerifyPayment = onVerifyPayment,
                    onRotateChefsDish = onRotateChefsDish,
                    modifier = Modifier.fillMaxSize()
                )
            }

            AdminViewMode.WEB_DASHBOARD -> {
                // Dedicated Web Hub View with Toolbar & Embedded Web Portal
                Column(modifier = Modifier.fillMaxSize()) {
                    // Web Portal Toolbar
                    Surface(
                        color = if (isSystemInDarkTheme()) Color(0xFF1E293B) else Color.White,
                        border = BorderStroke(1.dp, if (isSystemInDarkTheme()) Color(0xFF334155) else Color(0xFFE2E8F0)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "🌐 Vyanjanam Web Admin Portal",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = if (isSystemInDarkTheme()) Color.White else Color(0xFF0B2046)
                                )
                                Text(
                                    text = webAdminUrl,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                OutlinedButton(
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                        val clip = ClipData.newPlainText("Admin Portal URL", webAdminUrl)
                                        clipboard?.setPrimaryClip(clip)
                                        Toast.makeText(context, "Copied Admin Portal URL!", Toast.LENGTH_SHORT).show()
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    modifier = Modifier.testTag("admin_copy_web_url_btn")
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Copy URL", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                Button(
                                    onClick = {
                                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(webAdminUrl))
                                        context.startActivity(intent)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    modifier = Modifier.testTag("admin_launch_browser_btn")
                                ) {
                                    Icon(Icons.Default.OpenInNew, contentDescription = null, tint = Color.White, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Open in Chrome", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                }

                                IconButton(
                                    onClick = { webViewRef?.reload() },
                                    modifier = Modifier.size(34.dp)
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = "Reload", modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }

                    // Embedded Full-Featured Interactive Web Admin Dashboard
                    AndroidView(
                        factory = { ctx ->
                            WebView(ctx).apply {
                                @SuppressLint("SetJavaScriptEnabled")
                                settings.javaScriptEnabled = true
                                settings.domStorageEnabled = true
                                settings.allowFileAccess = true
                                webViewClient = WebViewClient()
                                loadUrl("file:///android_asset/admin_dashboard.html")
                                webViewRef = this
                            }
                        },
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("admin_webview_container")
                    )
                }
            }

            AdminViewMode.MENU_AVAILABILITY -> {
                AdminMenuAvailabilityView(
                    dishes = dishes,
                    onToggleAvailability = { dishId, current ->
                        onToggleDishAvailability?.invoke(dishId, current)
                    },
                    onAddDish = onAddDish,
                    onRemoveDish = onRemoveDish,
                    onUpdateDishPrice = onUpdateDishPrice
                )
            }

            AdminViewMode.CHEFS_CHOICE -> {
                AdminChefsChoiceMenuView(
                    dishes = dishes,
                    weeklyDishes = chefsWeeklyMenu,
                    regularPrice = chefsRegularPrice,
                    jumboPrice = chefsJumboPrice,
                    onUpdateDish = { dayIdx, dishName ->
                        onUpdateChefsWeeklyDish?.invoke(dayIdx, dishName)
                    },
                    onResetMenu = {
                        onResetChefsWeeklyMenu?.invoke()
                    },
                    onUpdatePrices = { reg, jumbo ->
                        onUpdateChefsPrices?.invoke(reg, jumbo)
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AdminChefsChoiceMenuView(
    dishes: List<MenuDish>,
    weeklyDishes: List<String>,
    regularPrice: Double,
    jumboPrice: Double,
    onUpdateDish: (Int, String) -> Unit,
    onResetMenu: () -> Unit,
    onUpdatePrices: (Double, Double) -> Unit
) {
    val isDark = isSystemInDarkTheme()
    val daysOfWeek = listOf("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday")

    var selectedDayForDishPicker by remember { mutableStateOf<Int?>(null) }
    var showEditPricesDialog by remember { mutableStateOf(false) }

    val safeWeeklyDishes = remember(weeklyDishes, dishes) {
        if (weeklyDishes.size >= 7) weeklyDishes
        else {
            val list = weeklyDishes.toMutableList()
            val available = dishes.filter { it.isAvailable }.ifEmpty { dishes }
            while (list.size < 7) {
                val nextName = if (available.isNotEmpty()) available[list.size % available.size].name else "Aloo Paratha"
                list.add(nextName)
            }
            list
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("admin_chefs_choice_menu_view"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Header Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isDark) Color(0xFF1E1B2E) else Color(0xFFFAF5FF)
                ),
                border = BorderStroke(1.dp, Color(0xFFDDD6FE)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF7C3AED)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("👨‍🍳", fontSize = 22.sp)
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Chef's Weekly Choice Master Menu",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = if (isDark) Color(0xFFEDE9FE) else Color(0xFF4C1D95)
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Modify the 7-day breakfast rotation and subscription packages for clients.",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isDark) Color(0xFFC4B5FD) else Color(0xFF6D28D9)
                        )
                    }
                }
            }
        }

        // 2. Pricing Packages Card (Regular @ 599, Jumbo @ 950)
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isDark) MaterialTheme.colorScheme.surface else Color.White
                ),
                border = BorderStroke(1.dp, if (isDark) MaterialTheme.colorScheme.outlineVariant else Color(0xFFE2E8F0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Subscription Plate Options",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Advance pricing paid by clients for 7 consecutive days",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Button(
                            onClick = { showEditPricesDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier
                                .height(32.dp)
                                .testTag("admin_edit_chefs_prices_btn")
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Edit Prices", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Regular Plate Card
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            color = if (isDark) Color(0xFF1E293B) else Color(0xFFF8FAFC),
                            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = Color(0xFFEDE9FE)
                                ) {
                                    Text(
                                        text = "REGULAR PLATE",
                                        fontSize = 8.5.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color(0xFF7C3AED),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "₹${regularPrice.toInt()}",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color(0xFF7C3AED)
                                    )
                                )
                                Text(
                                    text = "₹${(regularPrice / 7).toInt()}/day • 7 Days",
                                    fontSize = 10.5.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Single standard serving",
                                    fontSize = 10.sp,
                                    color = Color(0xFF64748B)
                                )
                            }
                        }

                        // Jumbo Plate Card
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp),
                            color = if (isDark) Color(0xFF1E293B) else Color(0xFFF8FAFC),
                            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = Color(0xFFFEF3C7)
                                ) {
                                    Text(
                                        text = "JUMBO PLATE",
                                        fontSize = 8.5.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color(0xFFB45309),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "₹${jumboPrice.toInt()}",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color(0xFF7C3AED)
                                    )
                                )
                                Text(
                                    text = "₹${(jumboPrice / 7).toInt()}/day • 7 Days",
                                    fontSize = 10.5.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Double hearty serving + sides",
                                    fontSize = 10.sp,
                                    color = Color(0xFF64748B)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. 7-Day Menu Schedule Board
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "7-Day Round-Robin Rotation",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Delivered consecutively Monday through Sunday",
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                OutlinedButton(
                    onClick = onResetMenu,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF7C3AED)),
                    border = BorderStroke(1.dp, Color(0xFFC4B5FD)),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(30.dp).testTag("admin_reset_chefs_menu_btn")
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Auto Sequence", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        items(7) { dayIndex ->
            val dayName = daysOfWeek.getOrElse(dayIndex) { "Day ${dayIndex + 1}" }
            val currentDishName = safeWeeklyDishes.getOrElse(dayIndex) { "Aloo Paratha" }
            val matchedDish = dishes.find { it.name.equals(currentDishName, ignoreCase = true) }

            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isDark) MaterialTheme.colorScheme.surface else Color.White
                ),
                border = BorderStroke(1.dp, if (isDark) MaterialTheme.colorScheme.outlineVariant else Color(0xFFE2E8F0)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_chefs_day_${dayIndex + 1}_card")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFF5F3FF),
                            border = BorderStroke(1.dp, Color(0xFFDDD6FE)),
                            modifier = Modifier.size(40.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "D${dayIndex + 1}",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 13.sp,
                                    color = Color(0xFF7C3AED)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = dayName,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF7C3AED)
                                    )
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = Color(0xFFDCFCE7)
                                ) {
                                    Text(
                                        text = "🟢 Pure Veg",
                                        fontSize = 8.5.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF15803D),
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = currentDishName,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            if (matchedDish != null) {
                                Text(
                                    text = matchedDish.subName.ifBlank { matchedDish.category },
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    Button(
                        onClick = { selectedDayForDishPicker = dayIndex },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(32.dp)
                            .testTag("admin_modify_dish_day_${dayIndex + 1}_btn")
                    ) {
                        Text("Modify Dish ▾", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // Dish Picker Dialog
    if (selectedDayForDishPicker != null) {
        val targetDayIdx = selectedDayForDishPicker!!
        val dayName = daysOfWeek.getOrElse(targetDayIdx) { "Day ${targetDayIdx + 1}" }
        val currentSelectedDish = safeWeeklyDishes.getOrElse(targetDayIdx) { "" }

        AlertDialog(
            onDismissRequest = { selectedDayForDishPicker = null },
            title = {
                Column {
                    Text(
                        text = "Modify Dish for Day ${targetDayIdx + 1} ($dayName)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Select any breakfast from the listed menu items",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            text = {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(320.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(dishes) { dish ->
                        val isSelected = dish.name.equals(currentSelectedDish, ignoreCase = true)
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .clickable {
                                    onUpdateDish(targetDayIdx, dish.name)
                                    selectedDayForDishPicker = null
                                },
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) Color(0xFFF5F3FF) else MaterialTheme.colorScheme.surface
                            ),
                            border = BorderStroke(
                                if (isSelected) 1.5.dp else 1.dp,
                                if (isSelected) Color(0xFF7C3AED) else Color(0xFFE2E8F0)
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = dish.name,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "${dish.category} • ${dish.subName}",
                                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1
                                    )
                                }
                                if (isSelected) {
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = Color(0xFF7C3AED)
                                    ) {
                                        Text(
                                            text = "SELECTED",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { selectedDayForDishPicker = null }) {
                    Text("Close")
                }
            }
        )
    }

    // Edit Prices Dialog
    if (showEditPricesDialog) {
        var regularText by remember { mutableStateOf(regularPrice.toInt().toString()) }
        var jumboText by remember { mutableStateOf(jumboPrice.toInt().toString()) }

        AlertDialog(
            onDismissRequest = { showEditPricesDialog = false },
            title = {
                Text(
                    text = "Edit Chef's Choice Subscription Prices",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Configure 7-Day advance subscription prices for clients:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = regularText,
                        onValueChange = { regularText = it },
                        label = { Text("Regular Plate Price (₹ for 7 Days)") },
                        leadingIcon = { Icon(Icons.Default.CurrencyRupee, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = jumboText,
                        onValueChange = { jumboText = it },
                        label = { Text("Jumbo Plate Price (₹ for 7 Days)") },
                        leadingIcon = { Icon(Icons.Default.CurrencyRupee, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val reg = regularText.toDoubleOrNull() ?: regularPrice
                        val jumbo = jumboText.toDoubleOrNull() ?: jumboPrice
                        onUpdatePrices(reg, jumbo)
                        showEditPricesDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED))
                ) {
                    Text("Save Prices", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditPricesDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AdminMenuAvailabilityView(
    dishes: List<MenuDish>,
    onToggleAvailability: (String, Boolean) -> Unit,
    onAddDish: ((String, String, String, String, Double, Boolean, Boolean) -> Unit)? = null,
    onRemoveDish: ((String, String) -> Unit)? = null,
    onUpdateDishPrice: ((String, List<PortionOption>) -> Unit)? = null
) {
    val isDark = isSystemInDarkTheme()
    var searchQuery by remember { mutableStateOf("") }
    var availabilityFilter by remember { mutableStateOf("ALL") }
    var showAddDialog by remember { mutableStateOf(false) }
    var editingPriceDish by remember { mutableStateOf<MenuDish?>(null) }

    val totalCount = dishes.size
    val availableCount = dishes.count { it.isAvailable }
    val unavailableCount = dishes.count { !it.isAvailable }

    val filteredDishes = dishes.filter { dish ->
        val matchesFilter = when (availabilityFilter) {
            "AVAILABLE" -> dish.isAvailable
            "UNAVAILABLE" -> !dish.isAvailable
            else -> true
        }
        val matchesSearch = if (searchQuery.isBlank()) true else {
            dish.name.contains(searchQuery, ignoreCase = true) ||
                    dish.subName.contains(searchQuery, ignoreCase = true) ||
                    dish.category.contains(searchQuery, ignoreCase = true)
        }
        matchesFilter && matchesSearch
    }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .testTag("admin_menu_availability_view"),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Live Menu Management Header & Add Item
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Live Menu Management",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = Color(0xFF0F172A)
                        )
                        Text(
                            text = "Add new items, toggle availability, or remove dishes",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFF64748B)
                        )
                    }

                    if (onAddDish != null) {
                        Button(
                            onClick = { showAddDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.testTag("admin_add_menu_dish_btn")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Add Dish", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // KPI Metrics Row
            item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AdminKpiCard(
                    title = "Total Dishes",
                    value = "$totalCount",
                    icon = Icons.Default.RestaurantMenu,
                    color = Color(0xFF2563EB),
                    modifier = Modifier.weight(1f)
                )
                AdminKpiCard(
                    title = "Available",
                    value = "$availableCount",
                    icon = Icons.Default.CheckCircle,
                    color = Color(0xFF059669),
                    modifier = Modifier.weight(1f)
                )
                AdminKpiCard(
                    title = "Unavailable",
                    value = "$unavailableCount",
                    icon = Icons.Default.Block,
                    color = Color(0xFFDC2626),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_menu_search_field"),
                placeholder = { Text("Search dishes by name or category...", fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF94A3B8)) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    focusedBorderColor = SaffronPrimary,
                    unfocusedBorderColor = Color(0xFFE2E8F0)
                )
            )
        }

        // Availability Filter Tabs
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(
                    "ALL" to "All ($totalCount)",
                    "AVAILABLE" to "Available ($availableCount)",
                    "UNAVAILABLE" to "Unavailable ($unavailableCount)"
                ).forEach { (key, label) ->
                    val isSelected = (availabilityFilter == key)
                    FilterChip(
                        selected = isSelected,
                        onClick = { availabilityFilter = key },
                        label = { Text(label, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SaffronPrimary,
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("admin_filter_$key")
                    )
                }
            }
        }

        // Dishes List
        if (filteredDishes.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 20.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.RestaurantMenu,
                            contentDescription = null,
                            tint = Color(0xFF94A3B8),
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No menu items match your search",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = Color(0xFF0F172A)
                        )
                    }
                }
            }
        } else {
            items(filteredDishes, key = { it.id }) { dish ->
                AdminDishItemCard(
                    dish = dish,
                    onToggle = { onToggleAvailability(dish.id, dish.isAvailable) },
                    onRemove = { onRemoveDish?.invoke(dish.id, dish.name) },
                    onEditPrice = { editingPriceDish = dish }
                )
            }
        }
    }

    if (showAddDialog && onAddDish != null) {
        AddMenuDishDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { name, subName, category, desc, price, isVeg, isAvail ->
                showAddDialog = false
                onAddDish(name, subName, category, desc, price, isVeg, isAvail)
            }
        )
    }

    editingPriceDish?.let { dishToEdit ->
        EditDishPriceDialog(
            dish = dishToEdit,
            onDismiss = { editingPriceDish = null },
            onConfirm = { updatedOptions ->
                editingPriceDish = null
                onUpdateDishPrice?.invoke(dishToEdit.id, updatedOptions)
            }
        )
    }
}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AdminDishItemCard(
    dish: MenuDish,
    onToggle: () -> Unit,
    onRemove: (() -> Unit)? = null,
    onEditPrice: (() -> Unit)? = null
) {
    val isDark = isSystemInDarkTheme()
    var isHovered by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }
    val tooltipState = rememberTooltipState()

    val cardBorder = if (!dish.isAvailable) {
        BorderStroke(1.dp, if (isDark) Color(0xFF424242) else Color(0xFFD6D6D6))
    } else BorderStroke(1.dp, Color(0xFFE2E8F0))

    val cardBg = if (!dish.isAvailable) {
        if (isDark) Color(0xFF1E1E1E) else Color(0xFFF3F3F3)
    } else Color.White

    TooltipBox(
        positionProvider = TooltipDefaults.rememberPlainTooltipPositionProvider(),
        tooltip = {
            if (!dish.isAvailable) {
                PlainTooltip(
                    containerColor = Color(0xFF1E293B),
                    contentColor = Color.White,
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "Item unavailable",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }
        },
        state = tooltipState
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .pointerInput(dish.id, dish.isAvailable) {
                    awaitPointerEventScope {
                        while (true) {
                            val event = awaitPointerEvent()
                            when (event.type) {
                                PointerEventType.Enter -> isHovered = true
                                PointerEventType.Exit -> isHovered = false
                                PointerEventType.Move -> isHovered = true
                            }
                        }
                    }
                }
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_dish_row_${dish.id}"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = cardBg),
                border = cardBorder
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .graphicsLayer { alpha = if (!dish.isAvailable) 0.55f else 1f },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = dish.name,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = Color(0xFF0F172A)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (dish.isAvailable) Color(0xFFD1FAE5) else Color(0xFFFEE2E2)
                                ) {
                                    Text(
                                        text = if (dish.isAvailable) "AVAILABLE" else "UNAVAILABLE",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (dish.isAvailable) Color(0xFF059669) else Color(0xFFDC2626)
                                        ),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${dish.category} • ${dish.subName}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFF64748B)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                dish.options.forEach { opt ->
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (isDark) Color(0xFF27272A) else Color(0xFFF1F5F9),
                                        border = BorderStroke(1.dp, if (isDark) Color(0xFF3F3F46) else Color(0xFFE2E8F0))
                                    ) {
                                        Text(
                                            text = "${opt.label}: ₹${opt.price.toInt()}",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 11.sp
                                            ),
                                            color = if (isDark) Color(0xFFE4E4E7) else Color(0xFF334155),
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // Right Controls: Switch
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Switch(
                                checked = dish.isAvailable,
                                onCheckedChange = { onToggle() },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = Color(0xFF059669),
                                    uncheckedThumbColor = Color.White,
                                    uncheckedTrackColor = Color(0xFF94A3B8)
                                ),
                                modifier = Modifier.testTag("admin_item_switch_${dish.id}")
                            )
                        }
                    }

                    // Crisp Divider between dish info and operational actions
                    HorizontalDivider(
                        modifier = Modifier.padding(top = 14.dp, bottom = 12.dp),
                        color = if (isDark) Color(0xFF334155) else Color(0xFFF1F5F9),
                        thickness = 1.dp
                    )

                    // The Three Options: 'Edit price' , 'Mark Unavailable' / 'Make Available' , and 'Remove'
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // 1. Edit Price
                        if (onEditPrice != null) {
                            val editBg = if (isDark) Color(0xFF2E2007) else Color(0xFFFFFBEB)
                            val editBorder = if (isDark) Color(0xFFB45309) else Color(0xFFF59E0B)
                            val editContent = if (isDark) Color(0xFFFDE68A) else Color(0xFFB45309)

                            Button(
                                onClick = onEditPrice,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(38.dp)
                                    .testTag("admin_edit_price_btn_${dish.id}"),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = editBg,
                                    contentColor = editContent
                                ),
                                border = BorderStroke(1.dp, editBorder),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                                elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp, pressedElevation = 1.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CurrencyRupee,
                                    contentDescription = "Edit Price",
                                    tint = editContent,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Edit Price",
                                    color = editContent,
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.5.sp
                                    ),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        // 2. Mark Unavailable / Make Available
                        if (dish.isAvailable) {
                            val unavailBg = if (isDark) Color(0xFF3B1212) else Color(0xFFFEF2F2)
                            val unavailBorder = if (isDark) Color(0xFFB91C1C) else Color(0xFFF87171)
                            val unavailContent = if (isDark) Color(0xFFFCA5A5) else Color(0xFFDC2626)

                            Button(
                                onClick = onToggle,
                                modifier = Modifier
                                    .weight(1.35f)
                                    .height(38.dp)
                                    .testTag("admin_mark_unavailable_${dish.id}"),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = unavailBg,
                                    contentColor = unavailContent
                                ),
                                border = BorderStroke(1.dp, unavailBorder),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                                elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp, pressedElevation = 1.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Block,
                                    contentDescription = "Mark Unavailable",
                                    tint = unavailContent,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Mark Unavailable",
                                    color = unavailContent,
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.5.sp
                                    ),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        } else {
                            val availBg = if (isDark) Color(0xFF063321) else Color(0xFFECFDF5)
                            val availBorder = if (isDark) Color(0xFF059669) else Color(0xFF34D399)
                            val availContent = if (isDark) Color(0xFF6EE7B7) else Color(0xFF047857)

                            Button(
                                onClick = onToggle,
                                modifier = Modifier
                                    .weight(1.35f)
                                    .height(38.dp)
                                    .testTag("admin_mark_available_${dish.id}"),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = availBg,
                                    contentColor = availContent
                                ),
                                border = BorderStroke(1.dp, availBorder),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                                elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp, pressedElevation = 1.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Make Available",
                                    tint = availContent,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Make Available",
                                    color = availContent,
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.5.sp
                                    ),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        // 3. Remove
                        if (onRemove != null) {
                            val removeBg = if (isDark) Color(0xFF1E293B) else Color(0xFFF8FAFC)
                            val removeBorder = if (isDark) Color(0xFF475569) else Color(0xFFCBD5E1)
                            val removeContent = if (isDark) Color(0xFFE2E8F0) else Color(0xFF475569)
                            val removeIconTint = if (isDark) Color(0xFFF87171) else Color(0xFFDC2626)

                            Button(
                                onClick = { showDeleteConfirm = true },
                                modifier = Modifier
                                    .weight(0.85f)
                                    .height(38.dp)
                                    .testTag("admin_remove_dish_btn_${dish.id}"),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = removeBg,
                                    contentColor = removeContent
                                ),
                                border = BorderStroke(1.dp, removeBorder),
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp),
                                elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp, pressedElevation = 1.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = "Remove Item",
                                    tint = removeIconTint,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "Remove",
                                    color = removeContent,
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.5.sp
                                    ),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    if (showDeleteConfirm && onRemove != null) {
                        AlertDialog(
                            onDismissRequest = { showDeleteConfirm = false },
                            title = {
                                Text(
                                    text = "Remove from Menu?",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            },
                            text = {
                                Text(
                                    text = "Are you sure you want to remove \"${dish.name}\"? It will be deleted from the live kitchen menu.",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            },
                            confirmButton = {
                                Button(
                                    onClick = {
                                        showDeleteConfirm = false
                                        onRemove()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                                    modifier = Modifier.testTag("admin_confirm_delete_${dish.id}")
                                ) {
                                    Text("Remove Item", color = Color.White)
                                }
                            },
                            dismissButton = {
                                OutlinedButton(
                                    onClick = { showDeleteConfirm = false }
                                ) {
                                    Text("Cancel")
                                }
                            }
                        )
                    }
                }
            }

            // Interactive Hover Pill Overlay: Appears when hovering over an unavailable item
            if (isHovered && !dish.isAvailable) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xEE0F172A),
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .testTag("admin_hover_item_unavailable_${dish.id}")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Block,
                            contentDescription = null,
                            tint = Color(0xFFFF8A80),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Item unavailable",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminKpiCard(
    title: String,
    value: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    val isDark = isSystemInDarkTheme()
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isDark) MaterialTheme.colorScheme.surfaceVariant else Color.White
        ),
        border = BorderStroke(1.dp, if (isDark) MaterialTheme.colorScheme.outlineVariant else Color(0xFFE2E8F0))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else Color(0xFF64748B)
                )
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .background(color.copy(alpha = 0.12f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = color,
                        modifier = Modifier.size(13.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 18.sp
                ),
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun AdminOrderCard(
    order: OrderEntity,
    onAdvanceStatus: (String) -> Unit,
    onLockOrder: () -> Unit,
    onVerifyPayment: ((Long, String) -> Unit)? = null,
    onRotateChefsDish: ((Long, String) -> Unit)? = null
) {
    val isDark = isSystemInDarkTheme()
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isDark) MaterialTheme.colorScheme.surface else Color.White
        ),
        border = BorderStroke(1.dp, if (isDark) MaterialTheme.colorScheme.outlineVariant else Color(0xFFE2E8F0)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("admin_order_${order.orderNumber}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Top Row: Order ID, Date, Status Badges
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "#${order.orderNumber}",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                        ),
                        color = if (isDark) SaffronLight else Color(0xFF0B2046)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        color = if (isDark) MaterialTheme.colorScheme.surfaceVariant else Color(0xFFF1F5F9),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "${order.targetDate} (${order.dayOfWeek})",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            ),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }

                // Lock & Kitchen Status Pills
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (order.isLocked) {
                        Surface(
                            color = Color(0xFFF5F3FF),
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, Color(0xFFDDD6FE))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = Color(0xFF7C3AED),
                                    modifier = Modifier.size(11.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = "LOCKED",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    color = Color(0xFF7C3AED)
                                )
                            }
                        }
                    }

                    val upperStatus = order.kitchenStatus.uppercase()
                    val (statusBg, statusFg) = when {
                        upperStatus == "PAYMENT_PENDING" -> Color(0xFFFEF3C7) to Color(0xFFB45309)
                        upperStatus.contains("PREPAR") -> Color(0xFFFFFBEB) to Color(0xFFD97706)
                        upperStatus.contains("READY") || upperStatus.contains("PACK") -> Color(0xFFF5F3FF) to Color(0xFF7C3AED)
                        upperStatus.contains("DELIVER") -> Color(0xFFECFDF5) to Color(0xFF059669)
                        else -> Color(0xFFEFF6FF) to Color(0xFF2563EB)
                    }

                    Surface(
                        color = statusBg,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = order.kitchenStatus,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            ),
                            color = statusFg,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Delivery Slot & Address
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "⏰ Slot: ${order.deliverySlot}",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (isDark) SaffronLight else Color(0xFF0B2046)
                    )
                )
                Spacer(modifier = Modifier.width(12.dp))
                val isPaid = order.paymentStatus.equals("PAID", ignoreCase = true)
                Text(
                    text = "₹${order.totalAmount.toInt()} • ${if (isPaid) "PAID ✓" else "PAYMENT PENDING ⏳"}",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (isPaid) Color(0xFF059669) else Color(0xFFD97706)
                    )
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "📍 ${order.deliveryAddress}",
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.5.sp),
                color = if (isDark) MaterialTheme.colorScheme.onSurfaceVariant else Color(0xFF64748B)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Precise GPS Location & Google Maps Navigation for Admin/Riders
            Surface(
                color = Color(0xFFF0FDF4),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Navigation,
                                contentDescription = null,
                                tint = Color(0xFF047857),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "GPS: ${order.deliveryLatitude}, ${order.deliveryLongitude}",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = Color(0xFF065F46)
                            )
                        }
                        Surface(
                            color = Color(0xFFDCFCE7),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "${order.deliveryDistanceKm} km from kitchen",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF15803D),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val context = androidx.compose.ui.platform.LocalContext.current
                    OutlinedButton(
                        onClick = {
                            val navUrl = "https://www.google.com/maps/dir/?api=1&origin=15.4989,73.8278&destination=${order.deliveryLatitude},${order.deliveryLongitude}&travelmode=driving"
                            val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(navUrl))
                            context.startActivity(intent)
                        },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF047857)),
                        border = BorderStroke(1.dp, Color(0xFF86EFAC)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Directions,
                            contentDescription = "Navigate to customer",
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("🗺️ Open Route in Google Maps", fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Client Contact & Rider Communication Card
            Surface(
                color = Color(0xFFF0F9FF),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, Color(0xFFBAE6FD)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "👤 ${order.customerName}",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                            color = Color(0xFF0369A1)
                        )
                        Surface(
                            color = Color(0xFFE0F2FE),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "📞 ${order.customerPhoneNumber}",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = Color(0xFF0284C7),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    val context = androidx.compose.ui.platform.LocalContext.current
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                val dialIntent = android.content.Intent(
                                    android.content.Intent.ACTION_DIAL,
                                    android.net.Uri.parse("tel:${order.customerPhoneNumber}")
                                )
                                context.startActivity(dialIntent)
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF0369A1)),
                            border = BorderStroke(1.dp, Color(0xFF7DD3FC)),
                            modifier = Modifier
                                .weight(1f)
                                .height(36.dp)
                        ) {
                            Text("📞 Call Client", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                val cleanPhone = order.customerPhoneNumber.replace(Regex("[^0-9]"), "")
                                val formattedPhone = if (cleanPhone.length == 10) "91$cleanPhone" else cleanPhone
                                val encodedName = try {
                                    java.net.URLEncoder.encode(order.customerName, "UTF-8")
                                } catch (_: Exception) {
                                    "Customer"
                                }
                                val waUrl = "https://wa.me/$formattedPhone?text=Hello%20$encodedName,%20this%20is%20Vyanjanam%20Kitchen%20regarding%20your%20breakfast%20order%20%23${order.orderNumber}."
                                val waIntent = android.content.Intent(
                                    android.content.Intent.ACTION_VIEW,
                                    android.net.Uri.parse(waUrl)
                                )
                                context.startActivity(waIntent)
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF16A34A),
                                contentColor = Color.White
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(36.dp)
                        ) {
                            Text("💬 WhatsApp", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Items Summary
            val isChefsChoice = order.itemsSummary.contains("Chef's Weekly Choice", ignoreCase = true) ||
                    order.paymentMethod.contains("Chef's Weekly Choice", ignoreCase = true)

            if (isChefsChoice) {
                Surface(
                    color = Color(0xFFF5F3FF),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, Color(0xFFDDD6FE)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("👨‍🍳", fontSize = 14.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Chef's Weekly Choice (Round Robin)",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.ExtraBold),
                                color = Color(0xFF7C3AED)
                            )
                        }

                        if (onRotateChefsDish != null) {
                            Button(
                                onClick = { onRotateChefsDish(order.id, order.itemsSummary) },
                                shape = RoundedCornerShape(6.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF7C3AED),
                                    contentColor = Color.White
                                ),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.height(28.dp)
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Rotate Dish", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            Surface(
                color = if (isDark) MaterialTheme.colorScheme.surfaceVariant else Color(0xFFF8FAFC),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, if (isDark) MaterialTheme.colorScheme.outlineVariant else Color(0xFFE2E8F0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "🍽️ ${order.itemsSummary}",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.5.sp
                    ),
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(10.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            val isPaymentPending = order.paymentStatus.contains("PENDING", ignoreCase = true) ||
                    order.kitchenStatus.contains("PENDING", ignoreCase = true)

            if (isPaymentPending) {
                Surface(
                    color = Color(0xFFFEF3C7),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, Color(0xFFFDE68A)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "⏳ WhatsApp UPI Bank Credit Pending",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF92400E)
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Customer placed Order #${order.orderNumber} for ₹${order.totalAmount.toInt()} via WhatsApp Desk (+91 7579890049). Verify actual bank credit before kitchen starts cooking.",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.5.sp),
                            color = Color(0xFFB45309)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val context = androidx.compose.ui.platform.LocalContext.current
                            OutlinedButton(
                                onClick = {
                                    val cleanPhone = order.customerPhoneNumber.replace(Regex("[^0-9]"), "")
                                    val formattedPhone = if (cleanPhone.length == 10) "91$cleanPhone" else cleanPhone
                                    val waUrl = "https://wa.me/$formattedPhone?text=Hello%20${java.net.URLEncoder.encode(order.customerName, "UTF-8")},%20this%20is%20Vyanjanam%20Admin%20regarding%20your%20UPI%20payment%20of%20%E2%82%B9${order.totalAmount.toInt()}%20for%20Order%20%23${order.orderNumber}."
                                    val waIntent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(waUrl))
                                    context.startActivity(waIntent)
                                },
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, Color(0xFF16A34A)),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF16A34A)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("💬 Chat on WA", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = { onVerifyPayment?.invoke(order.id, order.orderNumber) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1.3f)
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("✓ Mark Paid", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Kitchen Pipeline Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!order.isLocked && !isPaymentPending) {
                    OutlinedButton(
                        onClick = onLockOrder,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LockClock,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Lock Cutoff", style = MaterialTheme.typography.labelSmall)
                    }
                }

                val upperStatus = order.kitchenStatus.uppercase()
                when {
                    upperStatus == "PAYMENT_PENDING" -> {
                        Button(
                            onClick = { onVerifyPayment?.invoke(order.id, order.orderNumber) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Verify Bank Credit & Mark Paid ✓", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    upperStatus.contains("DELIVER") -> {
                        Surface(
                            color = Color(0xFFECFDF5),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, Color(0xFFA7F3D0)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Row(
                                modifier = Modifier.padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = Color(0xFF059669),
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Order Delivered ✓",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color(0xFF047857)
                                )
                            }
                        }
                    }
                    upperStatus.contains("READY") || upperStatus.contains("PACK") -> {
                        Button(
                            onClick = { onAdvanceStatus("Order Delivered") },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Mark Delivered ✓", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    upperStatus.contains("PREPAR") -> {
                        Button(
                            onClick = { onAdvanceStatus("Ready and Packed") },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Ready & Packed ➔", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    else -> { // Scheduled / Confirmed
                        Button(
                            onClick = { onAdvanceStatus("Preparing") },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.OutdoorGrill,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Start Preparing ➔", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }
}
