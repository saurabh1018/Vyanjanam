package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.widthIn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.R
import kotlinx.coroutines.delay

// Mild bright warm ivory tone matching the updated splash canvas
val SplashBackgroundIvory = Color(0xFFFCF9F0)

@Composable
fun SplashScreen(
    modifier: Modifier = Modifier,
    onTimeout: () -> Unit
) {
    val alpha = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        // Smooth fade-in
        alpha.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 500, easing = FastOutSlowInEasing)
        )
        // Hold for 2.2s before continuing to main screen
        delay(2200)
        onTimeout()
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(SplashBackgroundIvory)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onTimeout
            )
            .testTag("splash_screen_container"),
        contentAlignment = Alignment.Center
    ) {
        val isTablet = maxWidth > 600.dp
        // Full vertical portrait splash artwork matching spash.png ditto
        Image(
            painter = painterResource(id = R.drawable.splash_screen_bg),
            contentDescription = "Vyanjanam Cloud Kitchen Splash",
            contentScale = if (isTablet) ContentScale.Fit else ContentScale.Crop,
            modifier = Modifier
                .then(
                    if (isTablet) {
                        Modifier
                            .fillMaxHeight()
                            .widthIn(max = 720.dp)
                    } else {
                        Modifier.fillMaxSize()
                    }
                )
                .alpha(alpha.value)
                .testTag("splash_logo_image")
        )
    }
}
