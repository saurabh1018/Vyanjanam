package com.example.ui.screens

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockClock
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.DayScheduleInfo
import com.example.model.KitchenMenuData
import com.example.model.MenuDish
import com.example.model.PortionOption
import com.example.model.SchedulePreset
import com.example.model.SelectedMealItem
import com.example.ui.components.AddMenuDishDialog
import com.example.ui.components.DaySelectorRow
import com.example.ui.components.MenuItemCard
import com.example.ui.theme.HerbGreen
import com.example.ui.theme.HerbGreenLight
import com.example.ui.theme.SaffronPrimary
import com.example.ui.theme.SaffronLight
import com.example.ui.theme.SatisfyScriptFont
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.isSystemInDarkTheme
import com.example.ui.components.ChefsWeeklyChoiceDialog

@Composable
fun WeeklyPlannerScreen(
    days: List<DayScheduleInfo>,
    selectedDayIndex: Int,
    dayCarts: Map<Int, List<SelectedMealItem>>,
    cutoffCountdown: String,
    enabledDays: Set<Int>,
    deliverySlot: String,
    deliveryAddress: String = "",
    onSelectDay: (Int) -> Unit,
    onToggleDay: (dayIndex: Int, isEnabled: Boolean) -> Unit,
    onApplyPreset: (SchedulePreset) -> Unit,
    onQuickAdd: (dish: MenuDish, option: PortionOption) -> Unit,
    onCustomizeDish: (dish: MenuDish) -> Unit,
    onRemoveItem: (dayIndex: Int, itemIndex: Int) -> Unit,
    onCheckoutDay: (dayIndex: Int) -> Unit,
    onSubscribeChefsWeeklyChoice: (isJumbo: Boolean) -> Unit = {},
    chefsWeeklyMenu: List<String> = emptyList(),
    chefsRegularPrice: Double = 599.0,
    chefsJumboPrice: Double = 950.0,
    dishes: List<MenuDish> = KitchenMenuData.menuDishes,
    isAdmin: Boolean = false,
    onToggleDishAvailability: ((String, Boolean) -> Unit)? = null,
    onAddDish: ((String, String, String, String, Double, Boolean, Boolean) -> Unit)? = null,
    onRemoveDish: ((String, String) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val currentDayInfo = days.getOrNull(selectedDayIndex)
    val dayItems = dayCarts[selectedDayIndex] ?: emptyList()
    val dayTotal = dayItems.sumOf { it.totalPrice }
    val allDaysTotal = dayCarts.values.flatten().sumOf { it.totalPrice }
    var showAddDishDialog by remember { mutableStateOf(false) }
    var showChefsChoiceDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("weekly_planner_screen")
    ) {
        // Day Menu Tray view (with Day schedule day selector)
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(top = 8.dp, bottom = 90.dp)
        ) {
            // Chef's Weekly Choice Option Card (Round-robin daily breakfast with advance payment)
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .clickable { showChefsChoiceDialog = true }
                        .testTag("chefs_weekly_choice_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.5.dp, Color(0xFF7C3AED).copy(alpha = 0.5f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = Color(0xFFF5F3FF),
                                modifier = Modifier.size(46.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text("👨‍🍳", fontSize = 22.sp)
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = Color(0xFFEDE9FE)
                                ) {
                                    Text(
                                        text = "ADVANCE 7-DAY PLAN",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 9.5.sp
                                        ),
                                        color = Color(0xFF7C3AED),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(3.dp))
                                Text(
                                    text = "Chef\'s Weekly Choice",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Regular Plate @ ₹${chefsRegularPrice.toInt()} • Jumbo Plate @ ₹${chefsJumboPrice.toInt()}",
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold),
                                    color = Color(0xFF7C3AED)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "From ₹${chefsRegularPrice.toInt()}",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFF7C3AED)
                                )
                            )
                            Text(
                                text = "7 Days",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Button(
                                onClick = { showChefsChoiceDialog = true },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                modifier = Modifier
                                    .height(32.dp)
                                    .testTag("select_chefs_choice_btn")
                            ) {
                                Text("Select", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // 7-Day Day Selector Bar
            item {
                DaySelectorRow(
                    days = days,
                    selectedDayIndex = selectedDayIndex,
                    dayCarts = dayCarts,
                    enabledDays = enabledDays,
                    onDaySelected = onSelectDay,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }

                    // Active Day Tray Card (if has items)
                    if (dayItems.isNotEmpty()) {
                        item {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 6.dp)
                                    .testTag("day_cart_summary_card"),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.ShoppingCart,
                                                contentDescription = null,
                                                tint = SaffronPrimary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "${currentDayInfo?.dayOfWeek}'s Breakfast Tray",
                                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                            )
                                        }

                                        Text(
                                            text = "₹${dayTotal.toInt()}",
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.ExtraBold,
                                                color = SaffronPrimary
                                            )
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(10.dp))

                                    dayItems.forEachIndexed { itemIdx, item ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 4.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = "${item.quantity}x ${item.dishName} (${item.optionLabel})",
                                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                                                )
                                                if (item.selectedAddOns.isNotEmpty()) {
                                                    Text(
                                                        text = "+ " + item.selectedAddOns.joinToString(", ") { it.name },
                                                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                    )
                                                }
                                            }

                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = "₹${item.totalPrice.toInt()}",
                                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                                )
                                                IconButton(
                                                    onClick = { onRemoveItem(selectedDayIndex, itemIdx) },
                                                    modifier = Modifier.size(32.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.DeleteOutline,
                                                        contentDescription = "Remove",
                                                        tint = Color(0xFFD32F2F),
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                                    Button(
                                        onClick = { onCheckoutDay(selectedDayIndex) },
                                        enabled = currentDayInfo?.isPastCutoff != true,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(44.dp)
                                            .testTag("lock_order_button"),
                                        colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                                        shape = RoundedCornerShape(12.dp)
                                    ) {
                                        Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Lock & Schedule for ${currentDayInfo?.shortDay} (₹${dayTotal.toInt()})")
                                    }
                                }
                            }
                        }
                    }

                    // Menu Section Header
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Breakfast Specialties",
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "For ${currentDayInfo?.dayOfWeek ?: "Today"}",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        color = SaffronPrimary
                                    )
                                )
                            }

                            if (isAdmin && onAddDish != null) {
                                Button(
                                    onClick = { showAddDishDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.testTag("planner_add_dish_btn")
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Add Item", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Specific Menu Items
                    items(dishes) { dish ->
                        MenuItemCard(
                            dish = dish,
                            targetDayName = currentDayInfo?.shortDay ?: "Day",
                            onQuickAdd = { option -> onQuickAdd(dish, option) },
                            onCustomizeClick = { onCustomizeDish(dish) },
                            isPastCutoff = currentDayInfo?.isPastCutoff == true,
                            isAdmin = isAdmin,
                            onToggleAvailability = { onToggleDishAvailability?.invoke(dish.id, dish.isAvailable) },
                            onRemoveDish = { onRemoveDish?.invoke(dish.id, dish.name) },
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                        )
                    }
                }

        if (showChefsChoiceDialog) {
            ChefsWeeklyChoiceDialog(
                dishes = dishes,
                deliverySlot = deliverySlot,
                deliveryAddress = deliveryAddress,
                weeklyDishes = chefsWeeklyMenu,
                regularPrice = chefsRegularPrice,
                jumboPrice = chefsJumboPrice,
                onDismiss = { showChefsChoiceDialog = false },
                onConfirmAdvancePayment = { isJumbo ->
                    showChefsChoiceDialog = false
                    onSubscribeChefsWeeklyChoice(isJumbo)
                }
            )
        }

        if (showAddDishDialog && onAddDish != null) {
            AddMenuDishDialog(
                onDismiss = { showAddDishDialog = false },
                onConfirm = { name, subName, category, desc, price, isVeg, isAvail ->
                    showAddDishDialog = false
                    onAddDish(name, subName, category, desc, price, isVeg, isAvail)
                }
            )
        }
    }
}
