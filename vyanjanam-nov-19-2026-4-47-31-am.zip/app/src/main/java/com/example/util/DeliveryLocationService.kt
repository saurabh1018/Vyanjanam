package com.example.util

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.roundToInt

data class DeliveryLocationInfo(
    val latitude: Double,
    val longitude: Double,
    val accuracyMeters: Float,
    val addressFormatted: String,
    val locality: String,
    val distanceKm: Double,
    val isDeliverable: Boolean,
    val deliveryZone: String,
    val estimatedMinutes: Int,
    val postalCode: String = ""
)

object DeliveryLocationService {
    // Vyanjanam Kitchen Base Coordinates (Margao, Goa, India)
    const val KITCHEN_LAT = 15.2832
    const val KITCHEN_LNG = 73.9862
    const val KITCHEN_NAME = "Vyanjanam Pure Veg Cloud Kitchen (Margao, Goa)"
    const val MAX_DELIVERY_RADIUS_KM = 14.0
    const val NOT_SERVICEABLE_MESSAGE = "We are not serviceable to this location. The order can be placed only within 14 km range. Until you enter an address within this range, orders cannot be placed."

    private const val FRESH_LOCATION_MAX_AGE_MS = 15_000L
    private const val FRESH_LOCATION_MAX_ACCURACY_METERS = 65f
    private const val GPS_FETCH_TIMEOUT_MS = 8_000L
    private const val NETWORK_WAIT_FOR_GPS_MS = 1_500L

    private val geocodeExecutor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())

    fun hasLocationPermission(context: Context): Boolean {
        val fine = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    fun hasPreciseLocationPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    }

    @SuppressLint("MissingPermission")
    fun detectPreciseLocation(
        context: Context,
        onSuccess: (DeliveryLocationInfo) -> Unit,
        onError: (String) -> Unit
    ) {
        if (!hasLocationPermission(context)) {
            mainHandler.post { onError("Location permission not granted") }
            return
        }

        try {
            val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            if (locationManager == null) {
                mainHandler.post { onError("Location service is unavailable on this device") }
                return
            }

            if (!LocationManagerCompat.isLocationEnabled(locationManager)) {
                mainHandler.post {
                    onError("Device GPS / Location is turned off. Please enable Location in Settings and try again.")
                }
                return
            }

            val candidateProviders = buildList {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    add(LocationManager.FUSED_PROVIDER)
                }
                if (hasPreciseLocationPermission(context)) {
                    add(LocationManager.GPS_PROVIDER)
                }
                add(LocationManager.NETWORK_PROVIDER)
                add(LocationManager.PASSIVE_PROVIDER)
            }

            val now = System.currentTimeMillis()
            var bestFreshLocation: Location? = null
            var bestCachedLocation: Location? = null

            for (provider in candidateProviders) {
                val enabled = try {
                    locationManager.isProviderEnabled(provider)
                } catch (_: Exception) {
                    false
                }
                if (!enabled) continue

                val loc = try {
                    locationManager.getLastKnownLocation(provider)
                } catch (_: Exception) {
                    null
                } ?: continue

                if (bestCachedLocation == null || loc.accuracy < bestCachedLocation.accuracy) {
                    bestCachedLocation = loc
                }
                val ageMs = now - loc.time
                if (ageMs in 0..FRESH_LOCATION_MAX_AGE_MS && loc.accuracy <= FRESH_LOCATION_MAX_ACCURACY_METERS) {
                    if (bestFreshLocation == null || loc.accuracy < bestFreshLocation.accuracy) {
                        bestFreshLocation = loc
                    }
                }
            }

            // Return immediately only if we already have a very fresh, accurate fix
            if (bestFreshLocation != null) {
                processLocation(
                    context = context,
                    lat = bestFreshLocation.latitude,
                    lng = bestFreshLocation.longitude,
                    accuracy = bestFreshLocation.accuracy,
                    onSuccess = onSuccess
                )
                return
            }

            val activeProviders = buildList {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    try {
                        if (locationManager.hasProvider(LocationManager.FUSED_PROVIDER) &&
                            locationManager.isProviderEnabled(LocationManager.FUSED_PROVIDER)
                        ) {
                            add(LocationManager.FUSED_PROVIDER)
                        }
                    } catch (_: Exception) {}
                }
                if (hasPreciseLocationPermission(context)) {
                    try {
                        if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                            add(LocationManager.GPS_PROVIDER)
                        }
                    } catch (_: Exception) {}
                }
                try {
                    if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                        add(LocationManager.NETWORK_PROVIDER)
                    }
                } catch (_: Exception) {}
            }.distinct()

            if (activeProviders.isEmpty()) {
                if (bestCachedLocation != null) {
                    processLocation(
                        context = context,
                        lat = bestCachedLocation.latitude,
                        lng = bestCachedLocation.longitude,
                        accuracy = bestCachedLocation.accuracy,
                        onSuccess = onSuccess
                    )
                } else {
                    mainHandler.post {
                        onError("No active GPS or Network location provider enabled. Please enable Location services.")
                    }
                }
                return
            }

            val completed = AtomicBoolean(false)
            val signals = mutableListOf<CancellationSignal>()
            var networkFallbackLocation: Location? = null

            fun finishWithLocation(loc: Location) {
                if (completed.compareAndSet(false, true)) {
                    signals.forEach { runCatching { it.cancel() } }
                    processLocation(
                        context = context,
                        lat = loc.latitude,
                        lng = loc.longitude,
                        accuracy = loc.accuracy,
                        onSuccess = onSuccess
                    )
                }
            }

            val networkAcceptRunnable = Runnable {
                val netLoc = networkFallbackLocation ?: bestCachedLocation
                if (netLoc != null) {
                    finishWithLocation(netLoc)
                }
            }

            val timeoutRunnable = Runnable {
                if (completed.compareAndSet(false, true)) {
                    signals.forEach { runCatching { it.cancel() } }
                    mainHandler.removeCallbacks(networkAcceptRunnable)
                    val fallback = networkFallbackLocation ?: bestCachedLocation
                    if (fallback != null) {
                        processLocation(
                            context = context,
                            lat = fallback.latitude,
                            lng = fallback.longitude,
                            accuracy = fallback.accuracy,
                            onSuccess = onSuccess
                        )
                    } else {
                        onError("Could not get a GPS fix in time. Check that GPS is enabled or retry in a clear area.")
                    }
                }
            }

            mainHandler.postDelayed(timeoutRunnable, GPS_FETCH_TIMEOUT_MS)
            val mainExecutor = ContextCompat.getMainExecutor(context)

            for (provider in activeProviders) {
                val signal = CancellationSignal()
                signals.add(signal)
                try {
                    LocationManagerCompat.getCurrentLocation(
                        locationManager,
                        provider,
                        signal,
                        mainExecutor
                    ) { loc ->
                        if (loc == null || completed.get()) return@getCurrentLocation
                        val gpsIsRunning = activeProviders.contains(LocationManager.GPS_PROVIDER)
                        if (provider == LocationManager.GPS_PROVIDER ||
                            (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && provider == LocationManager.FUSED_PROVIDER) ||
                            !gpsIsRunning
                        ) {
                            mainHandler.removeCallbacks(timeoutRunnable)
                            mainHandler.removeCallbacks(networkAcceptRunnable)
                            finishWithLocation(loc)
                        } else {
                            // Network fix received while GPS is still locking; give GPS a brief window
                            networkFallbackLocation = loc
                            mainHandler.removeCallbacks(networkAcceptRunnable)
                            mainHandler.postDelayed(networkAcceptRunnable, NETWORK_WAIT_FOR_GPS_MS)
                        }
                    }
                } catch (_: Exception) {
                    // Ignore individual provider error; other providers or timeout will handle completion
                }
            }
        } catch (e: Exception) {
            mainHandler.post {
                onError(e.message ?: "Failed to detect GPS location")
            }
        }
    }

    private fun buildZoneAndEta(distanceKm: Double): Triple<Boolean, String, Int> {
        val isDeliverable = distanceKm <= MAX_DELIVERY_RADIUS_KM
        val zone = when {
            distanceKm <= 5.0 -> "Zone A • Express Margao & Fatorda (15-20m)"
            distanceKm <= 14.0 -> "Zone B • South Goa Suburbs (25-35m)"
            else -> "Not Serviceable (> 14 km from Margao Kitchen)"
        }
        val estimatedMins = (15 + (distanceKm * 2.5)).roundToInt()
        return Triple(isDeliverable, zone, estimatedMins)
    }

    private fun extractAddressParts(addr: Address, lat: Double, lng: Double): Triple<String, String, String> {
        val line0 = addr.getAddressLine(0)?.trim().orEmpty()
        val locality = addr.subLocality?.takeIf { it.isNotBlank() }
            ?: addr.locality?.takeIf { it.isNotBlank() }
            ?: addr.subAdminArea?.takeIf { it.isNotBlank() }
            ?: "Pinned Location"
        val postalCode = addr.postalCode?.trim().orEmpty()
        val fallbackJoined = listOfNotNull(
            addr.thoroughfare?.takeIf { it.isNotBlank() },
            addr.subLocality?.takeIf { it.isNotBlank() },
            addr.locality?.takeIf { it.isNotBlank() },
            postalCode.takeIf { it.isNotBlank() }
        ).distinct().joinToString(", ")

        val formatted = line0.ifBlank { fallbackJoined }.ifBlank {
            val roundLat = (lat * 10000.0).roundToInt() / 10000.0
            val roundLng = (lng * 10000.0).roundToInt() / 10000.0
            "Pinned Location ($roundLat, $roundLng)"
        }
        return Triple(formatted, locality, postalCode)
    }

    /**
     * Asynchronously reverse-geocodes (lat, lng) off the main thread and works safely on Android 13+ (API 33+)
     * as well as older API levels. Callback is always invoked on the main thread.
     */
    fun reverseGeocodeCoordinates(
        context: Context,
        lat: Double,
        lng: Double,
        onResult: (formattedAddress: String, locality: String, postalCode: String) -> Unit
    ) {
        val roundLat = (lat * 10000.0).roundToInt() / 10000.0
        val roundLng = (lng * 10000.0).roundToInt() / 10000.0
        val coordFallback = "Pinned Location ($roundLat, $roundLng)"

        if (!Geocoder.isPresent()) {
            mainHandler.post { onResult(coordFallback, "Pinned Location", "") }
            return
        }

        val delivered = AtomicBoolean(false)
        fun deliver(formatted: String, locality: String, postalCode: String) {
            if (delivered.compareAndSet(false, true)) {
                mainHandler.post { onResult(formatted, locality, postalCode) }
            }
        }

        try {
            val geocoder = Geocoder(context, Locale.getDefault())
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                geocoder.getFromLocation(lat, lng, 1, object : Geocoder.GeocodeListener {
                    override fun onGeocode(addresses: MutableList<Address>) {
                        val addr = addresses.firstOrNull()
                        if (addr != null) {
                            val (fmt, loc, pin) = extractAddressParts(addr, lat, lng)
                            deliver(fmt, loc, pin)
                        } else {
                            deliver(coordFallback, "Pinned Location", "")
                        }
                    }

                    override fun onError(errorMessage: String?) {
                        deliver(coordFallback, "Pinned Location", "")
                    }
                })
            } else {
                geocodeExecutor.execute {
                    try {
                        @Suppress("DEPRECATION")
                        val addresses = geocoder.getFromLocation(lat, lng, 1)
                        val addr = addresses?.firstOrNull()
                        if (addr != null) {
                            val (fmt, loc, pin) = extractAddressParts(addr, lat, lng)
                            deliver(fmt, loc, pin)
                        } else {
                            deliver(coordFallback, "Pinned Location", "")
                        }
                    } catch (_: Exception) {
                        deliver(coordFallback, "Pinned Location", "")
                    }
                }
            }
        } catch (_: Exception) {
            deliver(coordFallback, "Pinned Location", "")
        }
    }

    private fun processLocation(
        context: Context,
        lat: Double,
        lng: Double,
        accuracy: Float,
        onSuccess: (DeliveryLocationInfo) -> Unit
    ) {
        val distance = calculateDistanceKm(KITCHEN_LAT, KITCHEN_LNG, lat, lng)
        val (isDeliverable, zone, estimatedMins) = buildZoneAndEta(distance)

        reverseGeocodeCoordinates(context, lat, lng) { formattedAddress, locality, postalCode ->
            onSuccess(
                DeliveryLocationInfo(
                    latitude = (lat * 10000.0).roundToInt() / 10000.0,
                    longitude = (lng * 10000.0).roundToInt() / 10000.0,
                    accuracyMeters = accuracy,
                    addressFormatted = formattedAddress,
                    locality = locality,
                    distanceKm = (distance * 10).roundToInt() / 10.0,
                    isDeliverable = isDeliverable,
                    deliveryZone = zone,
                    estimatedMinutes = estimatedMins,
                    postalCode = postalCode
                )
            )
        }
    }

    fun calculateDistanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val results = FloatArray(1)
        Location.distanceBetween(lat1, lon1, lat2, lon2, results)
        return (results[0] / 1000.0)
    }

    fun getGoogleMapsNavigationUrl(lat: Double, lng: Double): String {
        return "https://www.google.com/maps/dir/?api=1&origin=$KITCHEN_LAT,$KITCHEN_LNG&destination=$lat,$lng&travelmode=driving"
    }

    fun getGoogleMapsSearchUrl(lat: Double, lng: Double): String {
        return "https://www.google.com/maps/search/?api=1&query=$lat,$lng"
    }

    fun openGoogleMaps(context: Context, lat: Double, lng: Double, label: String = "Delivery Address") {
        try {
            val encodedLabel = Uri.encode(label)
            val gmmIntentUri = Uri.parse("geo:$lat,$lng?q=$lat,$lng($encodedLabel)")
            val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri).apply {
                setPackage("com.google.android.apps.maps")
            }
            if (mapIntent.resolveActivity(context.packageManager) != null) {
                context.startActivity(mapIntent)
            } else {
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(getGoogleMapsSearchUrl(lat, lng)))
                context.startActivity(webIntent)
            }
        } catch (_: Exception) {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(getGoogleMapsSearchUrl(lat, lng)))
            try {
                context.startActivity(webIntent)
            } catch (_: Exception) {}
        }
    }

    /**
     * Opens Google Maps specifically for finding, dropping, or inspecting a delivery pin in Goa.
     */
    fun openGoogleMapsForPinning(context: Context, lat: Double = KITCHEN_LAT, lng: Double = KITCHEN_LNG) {
        try {
            val gmmIntentUri = Uri.parse("geo:$lat,$lng?q=$lat,$lng(Drop+or+Pin+Delivery+Location)&z=16")
            val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri).apply {
                setPackage("com.google.android.apps.maps")
            }
            if (mapIntent.resolveActivity(context.packageManager) != null) {
                context.startActivity(mapIntent)
            } else {
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=$lat,$lng"))
                context.startActivity(webIntent)
            }
        } catch (_: Exception) {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=$lat,$lng"))
            try {
                context.startActivity(webIntent)
            } catch (_: Exception) {}
        }
    }

    /**
     * Extracts latitude and longitude from:
     * 1. Direct coordinates: "15.4989, 73.8278" or "15.4989,73.8278"
     * 2. Google Maps URLs: e.g. maps.google.com/?q=15.4989,73.8278, @15.4989,73.8278
     * 3. Google Maps place URLs containing @lat,lng
     */
    fun parseCoordinatesOrMapLink(input: String): Pair<Double, Double>? {
        val clean = input.trim()
        if (clean.isBlank()) return null

        // Pattern 1: @15.4989,73.8278
        val atMatch = Regex("""@(-?\d{1,2}\.\d+),(-?\d{1,3}\.\d+)""").find(clean)
        if (atMatch != null) {
            val lat = atMatch.groupValues[1].toDoubleOrNull()
            val lng = atMatch.groupValues[2].toDoubleOrNull()
            if (lat != null && lng != null && lat in -90.0..90.0 && lng in -180.0..180.0) {
                return Pair((lat * 10000.0).roundToInt() / 10000.0, (lng * 10000.0).roundToInt() / 10000.0)
            }
        }

        // Pattern 2: ?q=lat,lng or &query=lat,lng
        val qMatch = Regex("""[?&](?:q|query)=(-?\d{1,2}\.\d+),(-?\d{1,3}\.\d+)""").find(clean)
        if (qMatch != null) {
            val lat = qMatch.groupValues[1].toDoubleOrNull()
            val lng = qMatch.groupValues[2].toDoubleOrNull()
            if (lat != null && lng != null && lat in -90.0..90.0 && lng in -180.0..180.0) {
                return Pair((lat * 10000.0).roundToInt() / 10000.0, (lng * 10000.0).roundToInt() / 10000.0)
            }
        }

        // Pattern 3: Direct lat, lng string like "15.4989, 73.8278" or "15.4989 73.8278"
        val directMatch = Regex("""(-?\d{1,2}\.\d+)[,\s]+(-?\d{1,3}\.\d+)""").find(clean)
        if (directMatch != null) {
            val lat = directMatch.groupValues[1].toDoubleOrNull()
            val lng = directMatch.groupValues[2].toDoubleOrNull()
            if (lat != null && lng != null && lat in -90.0..90.0 && lng in -180.0..180.0) {
                return Pair((lat * 10000.0).roundToInt() / 10000.0, (lng * 10000.0).roundToInt() / 10000.0)
            }
        }

        return null
    }

    /**
     * Resolves human-entered address into precise latitude & longitude.
     * Uses Android Geocoder with fallback based on address hash.
     */
    fun geocodeAddress(context: Context, addressText: String): Pair<Double, Double> {
        val cleanAddr = addressText.trim()
        if (cleanAddr.isBlank()) {
            return Pair(KITCHEN_LAT, KITCHEN_LNG)
        }

        try {
            if (Geocoder.isPresent()) {
                val geocoder = Geocoder(context, Locale.getDefault())
                @Suppress("DEPRECATION")
                val matches = geocoder.getFromLocationName(cleanAddr, 1)
                val first = matches?.firstOrNull()
                if (first != null && first.hasLatitude() && first.hasLongitude()) {
                    return Pair(first.latitude, first.longitude)
                }
            }
        } catch (_: Exception) {
            // Geocoder service may not be running in emulator / offline
        }

        val hash = kotlin.math.abs(cleanAddr.hashCode())
        val latDelta = ((hash % 40) - 20) * 0.001
        val lngDelta = (((hash / 40) % 40) - 20) * 0.001
        return Pair(
            (KITCHEN_LAT + latDelta).let { (it * 10000.0).roundToInt() / 10000.0 },
            (KITCHEN_LNG + lngDelta).let { (it * 10000.0).roundToInt() / 10000.0 }
        )
    }

    /**
     * Converts a customer address string into a complete DeliveryLocationInfo
     * calculating exact distance, delivery zone, and estimated transit minutes.
     */
    fun createLocationInfoForAddress(context: Context, addressText: String): DeliveryLocationInfo {
        val (lat, lng) = geocodeAddress(context, addressText)
        val distance = calculateDistanceKm(KITCHEN_LAT, KITCHEN_LNG, lat, lng)
        val (isDeliverable, zone, estimatedMins) = buildZoneAndEta(distance)

        // Derive locality dynamically from structured address parts
        val parts = addressText.split(",").map { it.trim() }.filter { it.isNotBlank() }
        val locality = when {
            parts.size >= 2 -> parts[parts.size - 2]
            parts.isNotEmpty() -> parts.first()
            else -> "Delivery Address"
        }

        return DeliveryLocationInfo(
            latitude = (lat * 10000.0).roundToInt() / 10000.0,
            longitude = (lng * 10000.0).roundToInt() / 10000.0,
            accuracyMeters = 5.0f,
            addressFormatted = addressText,
            locality = locality,
            distanceKm = (distance * 10).roundToInt() / 10.0,
            isDeliverable = isDeliverable,
            deliveryZone = zone,
            estimatedMinutes = estimatedMins
        )
    }

    /**
     * Creates DeliveryLocationInfo directly from pinned map coordinates (lat, lng)
     * and optional door/flat/landmark details entered by customer.
     */
    fun createLocationInfoForCoordinates(
        context: Context,
        lat: Double,
        lng: Double,
        buildingDetail: String = "",
        preResolvedAddress: String = "",
        preResolvedLocality: String = "",
        preResolvedPostalCode: String = ""
    ): DeliveryLocationInfo {
        val distance = calculateDistanceKm(KITCHEN_LAT, KITCHEN_LNG, lat, lng)
        val (isDeliverable, zone, estimatedMins) = buildZoneAndEta(distance)

        var reverseAddress = preResolvedAddress.trim()
        var locality = preResolvedLocality.trim().ifBlank { "Pinned Location" }
        var postalCode = preResolvedPostalCode.trim()

        if (reverseAddress.isBlank()) {
            try {
                if (Geocoder.isPresent()) {
                    val geocoder = Geocoder(context, Locale.getDefault())
                    @Suppress("DEPRECATION")
                    val matches = geocoder.getFromLocation(lat, lng, 1)
                    val match = matches?.firstOrNull()
                    if (match != null) {
                        val (fmt, loc, pin) = extractAddressParts(match, lat, lng)
                        reverseAddress = fmt
                        locality = loc
                        if (postalCode.isBlank()) postalCode = pin
                    }
                }
            } catch (_: Exception) {
                // Geocoder service may not be running in emulator or offline - gracefully fallback
            }
        }

        val roundLat = (lat * 10000.0).roundToInt() / 10000.0
        val roundLng = (lng * 10000.0).roundToInt() / 10000.0

        val isCoordPlaceholder = reverseAddress.startsWith("Pinned Location (")
        val formatted = when {
            buildingDetail.isNotBlank() && reverseAddress.isNotBlank() && !isCoordPlaceholder ->
                "$buildingDetail, $reverseAddress"
            buildingDetail.isNotBlank() ->
                "$buildingDetail [Pinned Location: $roundLat, $roundLng]"
            reverseAddress.isNotBlank() ->
                reverseAddress
            else ->
                "Pinned Location ($roundLat, $roundLng)"
        }

        return DeliveryLocationInfo(
            latitude = roundLat,
            longitude = roundLng,
            accuracyMeters = 3.0f,
            addressFormatted = formatted,
            locality = locality,
            distanceKm = (distance * 10).roundToInt() / 10.0,
            isDeliverable = isDeliverable,
            deliveryZone = zone,
            estimatedMinutes = estimatedMins,
            postalCode = postalCode
        )
    }
}
