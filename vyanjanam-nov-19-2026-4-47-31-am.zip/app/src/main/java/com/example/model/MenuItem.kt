package com.example.model

import androidx.annotation.DrawableRes
import com.example.R

data class PortionOption(
    val id: String,
    val label: String,
    val pieceCount: Int,
    val price: Double,
    val description: String = ""
)

data class AddOnItem(
    val id: String,
    val name: String,
    val price: Double
)

data class MenuDish(
    val id: String,
    val name: String,
    val subName: String,
    val category: String,
    val description: String,
    val isVegetarian: Boolean = true,
    val isAvailable: Boolean = true,
    val options: List<PortionOption>,
    val addOns: List<AddOnItem>,
    val prepTimeMinutes: Int = 20,
    val sortOrder: Int = 0,
    @DrawableRes val imageRes: Int = R.drawable.hero_breakfast
)

object KitchenMenuData {
    val commonAddOns = listOf(
        AddOnItem("addon_curd", "Fresh Thick Dahi", 30.0),
        AddOnItem("addon_chai", "Chai", 12.0)
    )

    val menuDishes = listOf(
        MenuDish(
            id = "aloo_paratha",
            name = "Aloo Paratha",
            subName = "Golden Spiced Potato Stuffed Flatbread (Pure Ghee)",
            category = "Parathas",
            description = "Whole wheat parathas made in pure ghee, generously stuffed with mashed spiced potatoes, roasted cumin, fresh coriander & green chilies. Cooked with No palm oil.",
            options = listOf(
                PortionOption("aloo_2", "2 Pieces", 2, 130.0, "Made in pure ghee • Served with homemade curd & pickle"),
                PortionOption("aloo_4", "4 Pieces", 4, 230.0, "Made in pure ghee • Super Value! Served with curd & pickle")
            ),
            addOns = commonAddOns,
            sortOrder = 1
        ),
        MenuDish(
            id = "gobhi_paratha",
            name = "Gobhi Paratha",
            subName = "Cauliflower Stuffed Flatbread (Pure Ghee)",
            category = "Parathas",
            description = "Fragrant whole wheat parathas made in pure ghee, stuffed with finely grated fresh cauliflower, ginger, carom seeds (ajwain), and Punjabi spices.",
            options = listOf(
                PortionOption("gobhi_2", "2 Pieces", 2, 130.0, "Made in pure ghee • Served with homemade curd & pickle"),
                PortionOption("gobhi_4", "4 Pieces", 4, 230.0, "Made in pure ghee • Super Value! Served with curd & pickle")
            ),
            addOns = commonAddOns,
            sortOrder = 2
        ),
        MenuDish(
            id = "mooli_paratha",
            name = "Mooli Paratha",
            subName = "Radish & Herb Stuffed Flatbread (Pure Ghee)",
            category = "Parathas",
            description = "Crispy whole wheat parathas made in pure ghee with freshly grated radish, roasted coriander seeds, ajwain, and chopped green herbs.",
            options = listOf(
                PortionOption("mooli_2", "2 Pieces", 2, 130.0, "Made in pure ghee • Served with homemade curd & pickle"),
                PortionOption("mooli_4", "4 Pieces", 4, 230.0, "Made in pure ghee • Super Value! Served with curd & pickle")
            ),
            addOns = commonAddOns,
            sortOrder = 3
        ),
        MenuDish(
            id = "paneer_paratha",
            name = "Paneer Paratha",
            subName = "Protein-rich Cottage Cheese Flatbread (Pure Ghee)",
            category = "Parathas",
            description = "Golden whole-wheat parathas made in pure ghee, packed with seasoned fresh paneer, roasted cumin, chopped mint, and mild green chillies. Served piping hot.",
            options = listOf(
                PortionOption("paneer_2", "2 Pieces", 2, 170.0, "Made in pure ghee • Served with thick curd & pickle"),
                PortionOption("paneer_4", "4 Pieces", 4, 320.0, "Made in pure ghee • Super Value! Served with curd & pickle")
            ),
            addOns = commonAddOns,
            sortOrder = 4
        ),
        MenuDish(
            id = "plain_paratha",
            name = "Plain Paratha with Sabji",
            subName = "Pure Ghee Triangle Parathas & Homestyle Sabji",
            category = "Parathas",
            description = "Flaky whole-wheat parathas cooked in pure desi ghee, served with comforting homestyle spiced vegetable sabji and tangy pickle. No palm oil.",
            options = listOf(
                PortionOption("plain_2", "2 Pieces", 2, 119.0, "2 Pure Ghee Parathas served with hot sabji"),
                PortionOption("plain_4", "4 Pieces", 4, 199.0, "4 Pure Ghee Parathas served with double sabji portion")
            ),
            addOns = commonAddOns,
            sortOrder = 5
        ),
        MenuDish(
            id = "idli_chutney",
            name = "Idli with Chutney",
            subName = "Steamed Rice Cakes & Fresh Chutneys",
            category = "Other Breakfast",
            description = "Pillowy, feather-soft steamed fermented rice & urad dal cakes. Served with authentic wet-ground coconut chutney.",
            options = listOf(
                PortionOption("idli_4", "4 Pieces", 4, 99.0, "Served with fresh ground coconut chutney")
            ),
            addOns = commonAddOns,
            sortOrder = 6
        ),
        MenuDish(
            id = "pav_bhaji",
            name = "Goan Bhaji Pav",
            subName = "Goan Style Spiced Bhaji & 2 Fresh Pavs",
            category = "Other Breakfast",
            description = "Authentic Goan style flavourful mixed vegetable & potato bhaji cooked cleanly without palm oil, served piping hot with 2 fresh locally baked soft pavs.",
            options = listOf(
                PortionOption("pb_1", "1 Plate (2 Fresh Pavs)", 1, 99.0, "Hot Goan bhaji + 2 fresh soft pavs")
            ),
            addOns = commonAddOns,
            sortOrder = 7
        ),
        MenuDish(
            id = "indori_poha",
            name = "Indori Poha & Sev",
            subName = "Light & Fluffy Flattened Rice with Crispy Ratlami Sev",
            category = "Other Breakfast",
            description = "Steamed flattened rice tempered with mustard seeds, fennel, roasted peanuts, curry leaves, and a dash of lemon juice. Garnished with fresh coriander and authentic crunchy Ratlami sev.",
            options = listOf(
                PortionOption("poha_1", "Regular Plate", 1, 79.0, "Indori Poha & Sev with roasted peanuts & lemon"),
                PortionOption("poha_2", "Jumbo Combo with Chai (x2)", 2, 120.0, "Indori Poha & Sev x2 + fresh masala chai")
            ),
            addOns = commonAddOns,
            sortOrder = 8
        )
    )
}
