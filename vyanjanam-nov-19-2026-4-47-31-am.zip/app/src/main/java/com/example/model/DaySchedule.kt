package com.example.model

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class SelectedMealItem(
    val dishId: String,
    val dishName: String,
    val optionId: String,
    val optionLabel: String,
    val unitPrice: Double,
    val quantity: Int = 1,
    val selectedAddOns: List<AddOnItem> = emptyList(),
    val spiceLevel: String = "Medium"
) {
    val totalPrice: Double
        get() = (unitPrice + selectedAddOns.sumOf { it.price }) * quantity
}

enum class OrderLockState {
    OPEN,               // Order can be modified and locked manually
    LOCKED_BY_USER,     // Manually locked by user before 10:30 PM cutoff
    AUTO_LOCKED,        // Automatically locked because 10:30 PM cutoff passed
    PREPARING,          // Morning kitchen cooking underway
    OUT_FOR_DELIVERY,   // Delivery partner on the way
    DELIVERED           // Successfully delivered
}

enum class SchedulePreset {
    ALL_7_DAYS,
    WEEKDAYS_ONLY,
    WEEKENDS_ONLY,
    PAUSE_ALL
}

data class DayScheduleInfo(
    val dayIndex: Int,            // 0..6
    val dayOfWeek: String,         // "Friday"
    val shortDay: String,          // "Fri"
    val dateDisplay: String,       // "Oct 2"
    val fullDateString: String,    // "2026-10-02"
    val cutoffDeadlineMillis: Long,// 10:30 PM of previous day
    val isPastCutoff: Boolean,     // True if system time > cutoff deadline
    val isToday: Boolean,
    val isTomorrow: Boolean,
    val isWeekend: Boolean = false,
    val suggestedDish: MenuDish? = null,
    val defaultDeliverySlot: String = "7:45 AM - 8:30 AM"
) {
    val cutoffDisplay: String
        get() = "Locks at 10:30 PM prior day"
}

object ScheduleHelper {
    /**
     * Generates a 7-day rolling calendar starting from today or tomorrow.
     * Cutoff for breakfast on date D is date (D - 1 day) at 22:30 (10:30 PM).
     */
    fun generate7Days(currentEpochMillis: Long = System.currentTimeMillis()): List<DayScheduleInfo> {
        val list = mutableListOf<DayScheduleInfo>()
        val cal = Calendar.getInstance()
        cal.timeInMillis = currentEpochMillis

        // Round to start of today
        val dayFormat = SimpleDateFormat("EEEE", Locale.ENGLISH)
        val shortDayFormat = SimpleDateFormat("EEE", Locale.ENGLISH)
        val dateFormat = SimpleDateFormat("MMM d", Locale.ENGLISH)
        val fullDateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)

        val dishes = KitchenMenuData.menuDishes

        for (i in 0 until 7) {
            val targetCal = Calendar.getInstance().apply {
                timeInMillis = currentEpochMillis
                add(Calendar.DAY_OF_YEAR, i)
            }

            val dayOfWeekConst = targetCal.get(Calendar.DAY_OF_WEEK)
            val isWeekend = (dayOfWeekConst == Calendar.SATURDAY || dayOfWeekConst == Calendar.SUNDAY)

            // Cutoff is the previous calendar day at 22:30 (10:30 PM)
            val cutoffCal = Calendar.getInstance().apply {
                timeInMillis = targetCal.timeInMillis
                add(Calendar.DAY_OF_YEAR, -1)
                set(Calendar.HOUR_OF_DAY, 22)
                set(Calendar.MINUTE, 30)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }

            val isPast = currentEpochMillis >= cutoffCal.timeInMillis
            val assignedDish = if (dishes.isNotEmpty()) dishes[i % dishes.size] else null

            list.add(
                DayScheduleInfo(
                    dayIndex = i,
                    dayOfWeek = dayFormat.format(targetCal.time),
                    shortDay = shortDayFormat.format(targetCal.time),
                    dateDisplay = dateFormat.format(targetCal.time),
                    fullDateString = fullDateFormat.format(targetCal.time),
                    cutoffDeadlineMillis = cutoffCal.timeInMillis,
                    isPastCutoff = isPast,
                    isToday = (i == 0),
                    isTomorrow = (i == 1),
                    isWeekend = isWeekend,
                    suggestedDish = assignedDish
                )
            )
        }
        return list
    }

    fun formatRemainingTime(millisLeft: Long): String {
        if (millisLeft <= 0) return "Cutoff passed (10:30 PM)"
        val hours = millisLeft / (1000 * 60 * 60)
        val minutes = (millisLeft % (1000 * 60 * 60)) / (1000 * 60)
        val seconds = (millisLeft % (1000 * 60)) / 1000
        return when {
            hours > 0 -> "${hours}h ${minutes}m left to lock"
            minutes > 0 -> "${minutes}m ${seconds}s left to lock"
            else -> "${seconds}s left to lock"
        }
    }
}
