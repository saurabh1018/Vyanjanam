package com.example.model

data class UserProfile(
    val phoneNumber: String,
    val name: String = "Breakfast Gourmet",
    val email: String = "",
    val isVerified: Boolean = true,
    val memberTier: String = "Gold Foodie",
    val joinedDate: String = "October 2026"
)
