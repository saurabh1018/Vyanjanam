package com.example.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.KitchenDatabase
import com.example.data.entity.DayCartItemEntity
import com.example.data.entity.OrderEntity
import com.example.data.repository.KitchenRepository
import com.example.model.AddOnItem
import com.example.model.DayScheduleInfo
import com.example.model.KitchenMenuData
import com.example.model.MenuDish
import com.example.model.PortionOption
import com.example.model.ScheduleHelper
import com.example.model.SchedulePreset
import com.example.model.SelectedMealItem
import com.example.model.UserProfile
import com.example.payment.PaymentMethodType
import com.example.payment.PaymentRequest
import com.example.payment.PaymentResult
import com.example.payment.PaymentSecurityHelper
import com.example.util.DeliveryLocationInfo
import com.example.util.DeliveryLocationService
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

import com.example.data.entity.SavedAddressEntity
import java.util.UUID
import kotlin.coroutines.resume
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.math.roundToInt

class KitchenViewModel(application: Application) : AndroidViewModel(application) {

    enum class AuthStep {
        PHONE_INPUT,
        OTP_VERIFICATION,
        VERIFIED_SUCCESS
    }

    private val database = KitchenDatabase.getDatabase(application)
    val repository = KitchenRepository(
        orderDao = database.orderDao(),
        dayCartDao = database.dayCartDao(),
        userSubscriptionDao = database.userSubscriptionDao(),
        menuDishDao = database.menuDishDao(),
        savedAddressDao = database.savedAddressDao(),
        context = application
    )

    val savedAddresses: StateFlow<List<SavedAddressEntity>> = repository.allSavedAddresses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val firebaseSyncStatus = repository.firebaseSyncStatus
    val firebaseConnected = repository.firebaseConnected
    val databaseStatus = MutableStateFlow("Room SQLite Database Active (v2)").asStateFlow()

    // Dynamic Food Menu StateFlow from Room Database (synced in background with Firestore)
    val menuDishes: StateFlow<List<MenuDish>> = repository.menuDishes
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), KitchenMenuData.menuDishes)

    val isLoggedIn = repository.isLoggedIn
    val currentUser = repository.currentUser

    // Google Sign-In Dialog State
    private val _showGoogleSignInDialog = MutableStateFlow(false)
    val showGoogleSignInDialog: StateFlow<Boolean> = _showGoogleSignInDialog.asStateFlow()

    private val _isGoogleSigningIn = MutableStateFlow(false)
    val isGoogleSigningIn: StateFlow<Boolean> = _isGoogleSigningIn.asStateFlow()

    private val _googleAuthError = MutableStateFlow<String?>(null)
    val googleAuthError: StateFlow<String?> = _googleAuthError.asStateFlow()

    // Profile Details Sheet State
    private val _showProfileSheet = MutableStateFlow(false)
    val showProfileSheet: StateFlow<Boolean> = _showProfileSheet.asStateFlow()

    // Phone OTP Auth Dialog State
    private val _showPhoneOtpDialog = MutableStateFlow(false)
    val showPhoneOtpDialog: StateFlow<Boolean> = _showPhoneOtpDialog.asStateFlow()

    private val _authStep = MutableStateFlow(AuthStep.PHONE_INPUT)
    val authStep: StateFlow<AuthStep> = _authStep.asStateFlow()

    private val _phoneInput = MutableStateFlow("")
    val phoneInput: StateFlow<String> = _phoneInput.asStateFlow()

    private val _authNameInput = MutableStateFlow("")
    val authNameInput: StateFlow<String> = _authNameInput.asStateFlow()

    private val _otpInput = MutableStateFlow("")
    val otpInput: StateFlow<String> = _otpInput.asStateFlow()

    private val _activeOtpCode = MutableStateFlow<String?>("7412")
    val activeOtpCode: StateFlow<String?> = _activeOtpCode.asStateFlow()

    private val _otpTimerSeconds = MutableStateFlow(30)
    val otpTimerSeconds: StateFlow<Int> = _otpTimerSeconds.asStateFlow()

    private val _isSendingOtp = MutableStateFlow(false)
    val isSendingOtp: StateFlow<Boolean> = _isSendingOtp.asStateFlow()

    private val _phoneAuthError = MutableStateFlow<String?>(null)
    val phoneAuthError: StateFlow<String?> = _phoneAuthError.asStateFlow()

    val orders: StateFlow<List<OrderEntity>> = repository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val walletBalance = repository.walletBalance
    val deliveryAddress = repository.savedAddress
    val deliverySlot = repository.selectedDeliverySlot
    val autoLockEnabled = repository.autoLockEnabled

    // Precise Delivery Location Tracking
    private val _deliveryLocationInfo = MutableStateFlow<DeliveryLocationInfo?>(null)
    val deliveryLocationInfo: StateFlow<DeliveryLocationInfo?> = _deliveryLocationInfo.asStateFlow()

    private val _isDetectingLocation = MutableStateFlow(false)
    val isDetectingLocation: StateFlow<Boolean> = _isDetectingLocation.asStateFlow()

    // 7 Days Schedule
    private val _daysSchedule = MutableStateFlow<List<DayScheduleInfo>>(emptyList())
    val daysSchedule: StateFlow<List<DayScheduleInfo>> = _daysSchedule.asStateFlow()

    // Enabled subscription days (indices 0..6)
    private val _enabledDays = MutableStateFlow<Set<Int>>(setOf(1, 2, 3, 4, 5, 6))
    val enabledDays: StateFlow<Set<Int>> = _enabledDays.asStateFlow()

    private val _selectedDayIndex = MutableStateFlow(0)
    val selectedDayIndex: StateFlow<Int> = _selectedDayIndex.asStateFlow()

    // Map of Day Index -> List of Selected Meal Items for that day
    private val _dayCarts = MutableStateFlow<Map<Int, List<SelectedMealItem>>>(emptyMap())
    val dayCarts: StateFlow<Map<Int, List<SelectedMealItem>>> = _dayCarts.asStateFlow()

    // Countdown string for current selected day's cutoff
    private val _cutoffCountdownText = MutableStateFlow("")
    val cutoffCountdownText: StateFlow<String> = _cutoffCountdownText.asStateFlow()

    // Active Payment Gateway Sheet State
    private val _activePaymentRequest = MutableStateFlow<PaymentRequest?>(null)
    val activePaymentRequest: StateFlow<PaymentRequest?> = _activePaymentRequest.asStateFlow()

    // Last completed order for receipt modal
    private val _completedOrderReceipt = MutableStateFlow<OrderEntity?>(null)
    val completedOrderReceipt: StateFlow<OrderEntity?> = _completedOrderReceipt.asStateFlow()

    // Active Item for Customization Modal
    private val _customizingDish = MutableStateFlow<MenuDish?>(null)
    val customizingDish: StateFlow<MenuDish?> = _customizingDish.asStateFlow()

    // UI Feedback Banner message
    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    // Address chooser for order lock (when user has multiple saved addresses)
    private val _showAddressChooserForOrder = MutableStateFlow<Int?>(null)
    val showAddressChooserForOrder: StateFlow<Int?> = _showAddressChooserForOrder.asStateFlow()

    // Prompt address setup modal (when user has 0 saved addresses)
    private val _showAddressSetupPrompt = MutableStateFlow<Boolean>(false)
    val showAddressSetupPrompt: StateFlow<Boolean> = _showAddressSetupPrompt.asStateFlow()

    // Chef's Weekly Choice Configuration (Admin configurable & Client subscribed)
    private val _chefsRegularPrice = MutableStateFlow(599.0)
    val chefsRegularPrice: StateFlow<Double> = _chefsRegularPrice.asStateFlow()

    private val _chefsJumboPrice = MutableStateFlow(950.0)
    val chefsJumboPrice: StateFlow<Double> = _chefsJumboPrice.asStateFlow()

    private val _chefsWeeklyMenu = MutableStateFlow<List<String>>(
        listOf(
            "Aloo Paratha",
            "Gobhi Paratha",
            "Mooli Paratha",
            "Idli with Chutney",
            "Aloo Paratha",
            "Gobhi Paratha",
            "Mooli Paratha"
        )
    )
    val chefsWeeklyMenu: StateFlow<List<String>> = _chefsWeeklyMenu.asStateFlow()

    init {
        refreshSchedule()
        startCountdownTicker()
        checkAndSeedInitialData()
        observeRoomDayCarts()
        // Initialize delivery location info from saved address or Room GPS coordinates if available
        val currentAddr = repository.savedAddress.value
        if (currentAddr.isNotBlank()) {
            _deliveryLocationInfo.value = DeliveryLocationService.createLocationInfoForAddress(application, currentAddr)
        }
        viewModelScope.launch {
            val allSaved = repository.allSavedAddresses.firstOrNull().orEmpty()
            val defaultSaved = allSaved.firstOrNull { it.isDefault } ?: allSaved.firstOrNull()
            if (defaultSaved != null) {
                _deliveryLocationInfo.value = DeliveryLocationInfo(
                    latitude = defaultSaved.latitude,
                    longitude = defaultSaved.longitude,
                    accuracyMeters = 5f,
                    addressFormatted = defaultSaved.formattedAddress,
                    locality = defaultSaved.area.ifBlank { "Delivery Zone" },
                    distanceKm = defaultSaved.distanceKm,
                    isDeliverable = defaultSaved.distanceKm <= DeliveryLocationService.MAX_DELIVERY_RADIUS_KM,
                    deliveryZone = defaultSaved.deliveryZone,
                    estimatedMinutes = (15 + (defaultSaved.distanceKm * 2.5)).roundToInt(),
                    postalCode = defaultSaved.pincode
                )
                if (repository.savedAddress.value != defaultSaved.formattedAddress) {
                    repository.updateAddress(defaultSaved.formattedAddress)
                }
            }
        }
    }

    private fun observeRoomDayCarts() {
        viewModelScope.launch {
            repository.allDayCartItems?.collect { entities ->
                if (entities.isNotEmpty()) {
                    val map = mutableMapOf<Int, MutableList<SelectedMealItem>>()
                    for (e in entities) {
                        val addOns = parseAddOns(e.addOnIds, e.addOnNames, e.addOnPrices)
                        val item = SelectedMealItem(
                            dishId = e.dishId,
                            dishName = e.dishName,
                            optionId = e.optionId,
                            optionLabel = e.optionLabel,
                            unitPrice = e.unitPrice,
                            quantity = e.quantity,
                            selectedAddOns = addOns,
                            spiceLevel = e.spiceLevel
                        )
                        map.getOrPut(e.dayIndex) { mutableListOf() }.add(item)
                    }
                    _dayCarts.value = map
                }
            }
        }
    }

    private fun saveDayCartToDatabase(dayIndex: Int) {
        viewModelScope.launch {
            val items = _dayCarts.value[dayIndex] ?: emptyList()
            val entities = items.map { item ->
                val (ids, names, prices) = formatAddOns(item.selectedAddOns)
                DayCartItemEntity(
                    dayIndex = dayIndex,
                    dishId = item.dishId,
                    dishName = item.dishName,
                    optionId = item.optionId,
                    optionLabel = item.optionLabel,
                    unitPrice = item.unitPrice,
                    quantity = item.quantity,
                    addOnIds = ids,
                    addOnNames = names,
                    addOnPrices = prices,
                    spiceLevel = item.spiceLevel
                )
            }
            repository.syncDayCartItems(dayIndex, entities)
        }
    }

    private fun formatAddOns(addOns: List<AddOnItem>): Triple<String, String, String> {
        val ids = addOns.joinToString(",") { it.id }
        val names = addOns.joinToString(",") { it.name }
        val prices = addOns.joinToString(",") { it.price.toString() }
        return Triple(ids, names, prices)
    }

    private fun parseAddOns(ids: String, names: String, prices: String): List<AddOnItem> {
        if (ids.isBlank()) return emptyList()
        val idList = ids.split(",")
        val nameList = names.split(",")
        val priceList = prices.split(",")
        return idList.indices.mapNotNull { i ->
            val id = idList.getOrNull(i) ?: return@mapNotNull null
            val name = nameList.getOrNull(i) ?: id
            val price = priceList.getOrNull(i)?.toDoubleOrNull() ?: 0.0
            AddOnItem(id, name, price)
        }
    }

    private fun refreshSchedule() {
        val list = ScheduleHelper.generate7Days()
        _daysSchedule.value = list
        // Initialize day 1 (tomorrow) with a default delicious breakfast if cart is empty
        if (_dayCarts.value.isEmpty()) {
            val tomorrowIndex = 1
            val alooDish = KitchenMenuData.menuDishes[0]
            val defaultItem = SelectedMealItem(
                dishId = alooDish.id,
                dishName = alooDish.name,
                optionId = alooDish.options[0].id,
                optionLabel = alooDish.options[0].label,
                unitPrice = alooDish.options[0].price,
                quantity = 1,
                selectedAddOns = listOf(KitchenMenuData.commonAddOns[0]), // Curd
                spiceLevel = "Medium"
            )
            _dayCarts.value = mapOf(tomorrowIndex to listOf(defaultItem))
            _selectedDayIndex.value = tomorrowIndex
            saveDayCartToDatabase(tomorrowIndex)
        }
    }

    private fun startCountdownTicker() {
        viewModelScope.launch {
            while (isActive) {
                val currentSchedule = _daysSchedule.value
                val selectedIdx = _selectedDayIndex.value
                if (selectedIdx in currentSchedule.indices) {
                    val dayInfo = currentSchedule[selectedIdx]
                    val now = System.currentTimeMillis()
                    val diff = dayInfo.cutoffDeadlineMillis - now
                    _cutoffCountdownText.value = ScheduleHelper.formatRemainingTime(diff)
                }
                delay(1000)
            }
        }
    }

    private fun checkAndSeedInitialData() {
        viewModelScope.launch {
            // Check if any order exists, else seed a sample today/tomorrow order
            delay(500)
            if (orders.value.isEmpty()) {
                val schedule = ScheduleHelper.generate7Days()
                if (schedule.isNotEmpty()) {
                    val sampleOrder = OrderEntity(
                        orderNumber = "RK-3921",
                        targetDate = schedule[0].fullDateString,
                        dayOfWeek = schedule[0].dayOfWeek,
                        itemsSummary = "2x Aloo Paratha (2 Pcs) + Dahi, 1x Pav Bhaji",
                        totalAmount = 240.0,
                        deliverySlot = "7:45 AM - 8:30 AM",
                        deliveryAddress = repository.savedAddress.value,
                        isLocked = true,
                        lockState = "LOCKED_BY_USER",
                        lockedAt = System.currentTimeMillis() - 3600000 * 4,
                        paymentMethod = "UPI - Google Pay",
                        paymentStatus = "PAID",
                        transactionId = PaymentSecurityHelper.generateTransactionId("UPI"),
                        kitchenStatus = "PREPARING",
                        customerPhoneNumber = "+91 98765 43210",
                        customerName = "Ananya Sharma"
                    )
                    repository.insertOrder(sampleOrder)
                }
            }
        }
    }

    fun selectDay(index: Int) {
        _selectedDayIndex.value = index
    }

    fun startCustomizing(dish: MenuDish) {
        _customizingDish.value = dish
    }

    fun closeCustomizing() {
        _customizingDish.value = null
    }

    fun addItemToDay(
        dayIndex: Int,
        dish: MenuDish,
        option: PortionOption,
        quantity: Int,
        addOns: List<AddOnItem>,
        spiceLevel: String
    ) {
        val currentSchedule = _daysSchedule.value
        if (dayIndex in currentSchedule.indices) {
            val dayInfo = currentSchedule[dayIndex]
            if (dayInfo.isPastCutoff) {
                _toastMessage.value = "Cutoff passed (10:30 PM prior day) for ${dayInfo.shortDay}!"
                return
            }
        }

        val newItem = SelectedMealItem(
            dishId = dish.id,
            dishName = dish.name,
            optionId = option.id,
            optionLabel = option.label,
            unitPrice = option.price,
            quantity = quantity,
            selectedAddOns = addOns,
            spiceLevel = spiceLevel
        )

        val updatedMap = _dayCarts.value.toMutableMap()
        val currentList = updatedMap[dayIndex]?.toMutableList() ?: mutableListOf()
        currentList.add(newItem)
        updatedMap[dayIndex] = currentList
        _dayCarts.value = updatedMap
        saveDayCartToDatabase(dayIndex)

        _toastMessage.value = "Added ${dish.name} (${option.label}) to ${currentSchedule.getOrNull(dayIndex)?.shortDay ?: "Day"}!"
        closeCustomizing()
    }

    fun removeItemFromDay(dayIndex: Int, itemIndex: Int) {
        val updatedMap = _dayCarts.value.toMutableMap()
        val currentList = updatedMap[dayIndex]?.toMutableList() ?: return
        if (itemIndex in currentList.indices) {
            currentList.removeAt(itemIndex)
            if (currentList.isEmpty()) {
                updatedMap.remove(dayIndex)
            } else {
                updatedMap[dayIndex] = currentList
            }
            _dayCarts.value = updatedMap
            saveDayCartToDatabase(dayIndex)
        }
    }

    fun clearDayCart(dayIndex: Int) {
        val updatedMap = _dayCarts.value.toMutableMap()
        updatedMap.remove(dayIndex)
        _dayCarts.value = updatedMap
        saveDayCartToDatabase(dayIndex)
    }

    fun getDayTotal(dayIndex: Int): Double {
        val items = _dayCarts.value[dayIndex] ?: return 0.0
        return items.sumOf { it.totalPrice }
    }

    fun getAllDaysTotal(): Double {
        return _dayCarts.value.values.flatten().sumOf { it.totalPrice }
    }

    fun onOrderLockClicked(dayIndex: Int) {
        val currentSchedule = _daysSchedule.value
        val dayInfo = currentSchedule.getOrNull(dayIndex) ?: return
        val items = _dayCarts.value[dayIndex] ?: emptyList()
        if (items.isEmpty()) {
            _toastMessage.value = "Your breakfast tray is empty for ${dayInfo.dayOfWeek}!"
            return
        }

        val addrs = savedAddresses.value
        val singleAddr = repository.savedAddress.value
        when {
            addrs.isEmpty() && singleAddr.isBlank() -> {
                // User has NO saved address! Prompt them to save one first so order can be delivered
                _toastMessage.value = "Please save a delivery address so your breakfast can be delivered!"
                _showAddressSetupPrompt.value = true
            }
            addrs.size > 1 -> {
                // User has multiple saved addresses -> direct them to choose from saved addresses
                _showAddressChooserForOrder.value = dayIndex
            }
            else -> {
                // User has only ONE saved address -> direct to payment section only, and do not show address on this page
                val targetAddr = addrs.firstOrNull()
                openPaymentGatewayForDay(
                    dayIndex = dayIndex,
                    preSelectedAddressId = targetAddr?.id,
                    hideAddressSection = true
                )
            }
        }
    }

    fun selectAddressForOrderAndProceed(address: SavedAddressEntity, dayIndex: Int) {
        _showAddressChooserForOrder.value = null
        openPaymentGatewayForDay(
            dayIndex = dayIndex,
            preSelectedAddressId = address.id,
            hideAddressSection = true
        )
    }

    fun closeAddressChooser() {
        _showAddressChooserForOrder.value = null
    }

    fun closeAddressSetupPrompt() {
        _showAddressSetupPrompt.value = false
    }

    fun openPaymentGatewayForDay(
        dayIndex: Int,
        preSelectedAddressId: String? = null,
        hideAddressSection: Boolean = false
    ) {
        val currentSchedule = _daysSchedule.value
        val dayInfo = currentSchedule.getOrNull(dayIndex) ?: return
        val items = _dayCarts.value[dayIndex] ?: emptyList()
        if (items.isEmpty()) {
            _toastMessage.value = "Your breakfast tray is empty for ${dayInfo.dayOfWeek}!"
            return
        }

        val total = items.sumOf { it.totalPrice }
        val summary = items.joinToString(", ") { "${it.quantity}x ${it.dishName} (${it.optionLabel})" }

        // Restrict order placement strictly to addresses within 14 km
        val currentLoc = _deliveryLocationInfo.value
        val targetAddr = if (preSelectedAddressId != null) {
            savedAddresses.value.find { it.id == preSelectedAddressId }
        } else {
            savedAddresses.value.find { it.isDefault } ?: savedAddresses.value.firstOrNull()
        }
        val dist = targetAddr?.distanceKm ?: currentLoc?.distanceKm ?: 0.0
        val isServiceable = dist <= 14.0 && (targetAddr != null || currentLoc != null)
        if (dist > 14.0 || (targetAddr == null && currentLoc != null && !currentLoc.isDeliverable)) {
            _toastMessage.value = "⚠️ We are not serviceable to this location (${dist} km away). Orders can only be placed within 14 km of our Margao kitchen. Please enter an address within 14 km."
            return
        }

        _activePaymentRequest.value = PaymentRequest(
            amount = total,
            orderTitle = "Breakfast Order for ${dayInfo.dayOfWeek}",
            targetDateDisplay = dayInfo.dateDisplay,
            dayOfWeek = dayInfo.dayOfWeek,
            deliverySlot = deliverySlot.value,
            itemsSummary = summary,
            preSelectedAddressId = preSelectedAddressId ?: targetAddr?.id,
            hideAddressSection = hideAddressSection
        )
    }

    fun updateChefsWeeklyDayDish(dayIndex: Int, dishName: String) {
        val current = _chefsWeeklyMenu.value.toMutableList()
        while (current.size < 7) {
            current.add("Aloo Paratha")
        }
        if (dayIndex in 0..6) {
            current[dayIndex] = dishName
            _chefsWeeklyMenu.value = current
            _toastMessage.value = "Updated Day ${dayIndex + 1} Chef's Choice to $dishName"
        }
    }

    fun resetChefsWeeklyMenu() {
        val availableDishes = menuDishes.value.filter { it.isAvailable }.ifEmpty { menuDishes.value }
        if (availableDishes.isNotEmpty()) {
            val defaultList = (0..6).map { idx ->
                availableDishes[idx % availableDishes.size].name
            }
            _chefsWeeklyMenu.value = defaultList
            _toastMessage.value = "Chef's Weekly Choice menu reset to sequential round-robin catalog!"
        }
    }

    fun updateChefsWeeklyPrices(regularPrice: Double, jumboPrice: Double) {
        _chefsRegularPrice.value = regularPrice
        _chefsJumboPrice.value = jumboPrice
        _toastMessage.value = "Chef's Weekly Choice prices updated: Regular ₹${regularPrice.toInt()}, Jumbo ₹${jumboPrice.toInt()}"
    }

    fun openChefsWeeklyChoiceSubscription(isJumbo: Boolean = false) {
        val schedule = _daysSchedule.value
        val firstDate = schedule.firstOrNull()?.dateDisplay ?: "Monday"
        val lastDate = schedule.lastOrNull()?.dateDisplay ?: "Sunday"
        val addrs = savedAddresses.value
        val singleAddr = repository.savedAddress.value

        if (addrs.isEmpty() && singleAddr.isBlank()) {
            _toastMessage.value = "Please save a delivery destination for your weekly breakfast deliveries!"
            _showAddressSetupPrompt.value = true
            return
        }

        val targetAddr = addrs.firstOrNull { it.isDefault } ?: addrs.firstOrNull()
        val currentLoc = _deliveryLocationInfo.value
        val dist = targetAddr?.distanceKm ?: currentLoc?.distanceKm ?: 0.0
        if (dist > 14.0) {
            _toastMessage.value = "⚠️ Delivery destination is $dist km away. Deliveries can only be scheduled within 14 km of our kitchen."
            return
        }

        val plateName = if (isJumbo) "Jumbo Plate" else "Regular Plate"
        val weeklyAmount = if (isJumbo) _chefsJumboPrice.value else _chefsRegularPrice.value

        _activePaymentRequest.value = PaymentRequest(
            amount = weeklyAmount,
            orderTitle = "Chef's Weekly Choice ($plateName)",
            targetDateDisplay = "$firstDate – $lastDate",
            dayOfWeek = "7-Day Round Robin",
            deliverySlot = deliverySlot.value,
            itemsSummary = "Chef's Weekly Choice ($plateName): 7-Day Morning Breakfast (Delivered in Round Robin Sequence from Listed Menu)",
            preSelectedAddressId = targetAddr?.id,
            hideAddressSection = true,
            isChefsWeeklyChoice = true
        )
    }

    fun toggleDayEnabled(dayIndex: Int, isEnabled: Boolean) {
        val schedule = _daysSchedule.value
        val dayInfo = schedule.getOrNull(dayIndex) ?: return
        if (dayInfo.isPastCutoff) {
            _toastMessage.value = "Cutoff passed (10:30 PM prior day) for ${dayInfo.shortDay}! Modifications locked."
            return
        }

        val current = _enabledDays.value.toMutableSet()
        if (isEnabled) {
            current.add(dayIndex)
            _toastMessage.value = "Breakfast scheduled for ${dayInfo.dayOfWeek}!"
        } else {
            current.remove(dayIndex)
            _toastMessage.value = "Delivery paused for ${dayInfo.dayOfWeek}."
        }
        _enabledDays.value = current
    }

    fun setPresetSchedule(preset: SchedulePreset) {
        val schedule = _daysSchedule.value
        val validDays = schedule.filter { !it.isPastCutoff }
        val updated = when (preset) {
            SchedulePreset.ALL_7_DAYS -> validDays.map { it.dayIndex }.toSet()
            SchedulePreset.WEEKDAYS_ONLY -> validDays.filter { !it.isWeekend }.map { it.dayIndex }.toSet()
            SchedulePreset.WEEKENDS_ONLY -> validDays.filter { it.isWeekend }.map { it.dayIndex }.toSet()
            SchedulePreset.PAUSE_ALL -> emptySet()
        }
        _enabledDays.value = updated
        _toastMessage.value = when (preset) {
            SchedulePreset.ALL_7_DAYS -> "All 7 days activated for delivery!"
            SchedulePreset.WEEKDAYS_ONLY -> "Schedule set to Weekdays only (Mon-Fri)."
            SchedulePreset.WEEKENDS_ONLY -> "Schedule set to Weekends only."
            SchedulePreset.PAUSE_ALL -> "All upcoming deliveries paused."
        }
    }

    fun getActiveSubscriptionTotal(): Double {
        val activeIndices = _enabledDays.value
        val schedule = _daysSchedule.value
        var sum = 0.0
        for (idx in activeIndices) {
            val cartItems = _dayCarts.value[idx]
            if (!cartItems.isNullOrEmpty()) {
                sum += cartItems.sumOf { it.totalPrice }
            } else {
                val day = schedule.getOrNull(idx)
                val price = day?.suggestedDish?.options?.firstOrNull()?.price ?: 60.0
                sum += price
            }
        }
        return sum
    }

    fun closePaymentGateway() {
        _activePaymentRequest.value = null
    }

    fun completePayment(
        methodType: PaymentMethodType,
        paymentDetails: String,
        shouldLockImmediately: Boolean = true,
        isVerified: Boolean = false,
        verifiedTxnId: String? = null,
        chosenAddress: String? = null,
        chosenLatitude: Double? = null,
        chosenLongitude: Double? = null,
        chosenDistanceKm: Double? = null
    ) {
        val req = _activePaymentRequest.value ?: return
        val schedule = _daysSchedule.value
        val dayIndex = _selectedDayIndex.value
        val dayInfo = schedule.getOrNull(dayIndex)

        viewModelScope.launch {
            // Only mark as PAID if verified by the server/cashfree
            val isOrderPaid = isVerified
            val paymentStatus = if (isOrderPaid) "PAID" else "PAYMENT_PENDING"
            val kitchenStatus = if (isOrderPaid) {
                if (shouldLockImmediately) "LOCKED & CONFIRMED" else "CONFIRMED"
            } else {
                "PAYMENT_PENDING"
            }

            val targetDate = dayInfo?.fullDateString ?: "2026-10-02"
            val dayOfWeek = dayInfo?.dayOfWeek ?: req.dayOfWeek
            val txnId = verifiedTxnId ?: PaymentSecurityHelper.generateTransactionId(
                when (methodType) {
                    PaymentMethodType.INSTANT_UPI -> "UPI"
                    PaymentMethodType.WHATSAPP_UPI -> "WA_UPI"
                    PaymentMethodType.CASHFREE_SANDBOX -> "CF_SANDBOX"
                }
            )

            val orderNumber = "RK-${(1000..9999).random()}"
            val currentLoc = _deliveryLocationInfo.value
            val activeAddr = savedAddresses.value.find { it.formattedAddress == chosenAddress }
                ?: savedAddresses.value.find { it.isDefault }
                ?: savedAddresses.value.firstOrNull()
            val lat = chosenLatitude ?: activeAddr?.latitude ?: currentLoc?.latitude ?: DeliveryLocationService.KITCHEN_LAT
            val lng = chosenLongitude ?: activeAddr?.longitude ?: currentLoc?.longitude ?: DeliveryLocationService.KITCHEN_LNG
            val dist = chosenDistanceKm ?: activeAddr?.distanceKm ?: currentLoc?.distanceKm ?: 0.0
            val acc = currentLoc?.accuracyMeters ?: 8.5f
            if (dist > DeliveryLocationService.MAX_DELIVERY_RADIUS_KM) {
                _toastMessage.value = "⚠️ We are not serviceable to this location ($dist km). Orders can only be placed within 14 km of our Margao kitchen."
                return@launch
            }

        val formattedAddr = chosenAddress ?: currentLoc?.addressFormatted ?: repository.savedAddress.value

            val currentProfile = currentUser.value ?: repository.currentUser.value
            val customerPhone = currentProfile?.phoneNumber?.ifBlank { "+91 98765 43210" } ?: "+91 98765 43210"
            val customerName = currentProfile?.name?.ifBlank { "Gourmet Foodie" } ?: "Gourmet Foodie"

            if (req.isChefsWeeklyChoice) {
                val schedule = _daysSchedule.value
                val availableDishes = menuDishes.value.filter { it.isAvailable }.ifEmpty { menuDishes.value }
                val baseCode = (1000..9999).random()
                var firstCreatedOrder: OrderEntity? = null
                val dailyAmount = Math.round(req.amount / schedule.size.toDouble()).toDouble()
                val isJumbo = req.orderTitle.contains("Jumbo", ignoreCase = true) || req.itemsSummary.contains("Jumbo", ignoreCase = true)
                val plateLabel = if (isJumbo) "Jumbo Plate" else "Regular Plate"

                schedule.forEachIndexed { idx, day ->
                    val chosenDishName = _chefsWeeklyMenu.value.getOrNull(idx) ?: availableDishes[idx % availableDishes.size].name
                    val dailyOrderNum = "CW-$baseCode-${day.shortDay.uppercase()}"
                    val dailySummary = "Chef's Weekly Choice ($plateLabel): 1x $chosenDishName (Round Robin)"
                    val dailyOrder = OrderEntity(
                        orderNumber = dailyOrderNum,
                        targetDate = day.dateDisplay,
                        dayOfWeek = day.dayOfWeek,
                        itemsSummary = dailySummary,
                        totalAmount = dailyAmount,
                        deliverySlot = req.deliverySlot,
                        deliveryAddress = formattedAddr,
                        isLocked = isOrderPaid,
                        lockState = if (isOrderPaid) "LOCKED_BY_USER" else "OPEN",
                        lockedAt = if (isOrderPaid) System.currentTimeMillis() else 0L,
                        paymentMethod = "Advance Payment (Chef's Weekly Choice - $plateLabel)",
                        paymentStatus = paymentStatus,
                        transactionId = "$txnId-D${idx + 1}",
                        kitchenStatus = if (isOrderPaid) "SCHEDULED" else "PAYMENT_PENDING",
                        deliveryLatitude = lat,
                        deliveryLongitude = lng,
                        deliveryDistanceKm = dist,
                        locationAccuracyMeters = acc,
                        locationAddressFormatted = formattedAddr,
                        customerPhoneNumber = customerPhone,
                        customerName = customerName
                    )
                    val insertedId = repository.insertOrder(dailyOrder)
                    if (firstCreatedOrder == null) {
                        firstCreatedOrder = dailyOrder.copy(id = insertedId)
                    }
                }

                _activePaymentRequest.value = null
                _completedOrderReceipt.value = firstCreatedOrder
                _toastMessage.value = "⭐ Chef's Weekly Choice ($plateLabel) Subscribed! 7 days scheduled in round-robin sequence."
                return@launch
            }

            val newOrder = OrderEntity(
                orderNumber = orderNumber,
                targetDate = targetDate,
                dayOfWeek = dayOfWeek,
                itemsSummary = req.itemsSummary,
                totalAmount = req.amount,
                deliverySlot = req.deliverySlot,
                deliveryAddress = formattedAddr,
                isLocked = if (isOrderPaid) shouldLockImmediately else false,
                lockState = if (isOrderPaid && shouldLockImmediately) "LOCKED_BY_USER" else "OPEN",
                lockedAt = if (isOrderPaid && shouldLockImmediately) System.currentTimeMillis() else 0L,
                paymentMethod = "${methodType.displayName} ($paymentDetails)",
                paymentStatus = paymentStatus,
                transactionId = txnId,
                kitchenStatus = kitchenStatus,
                deliveryLatitude = lat,
                deliveryLongitude = lng,
                deliveryDistanceKm = dist,
                locationAccuracyMeters = acc,
                locationAddressFormatted = formattedAddr,
                customerPhoneNumber = customerPhone,
                customerName = customerName
            )

            val orderId = repository.insertOrder(newOrder)
            val savedOrder = newOrder.copy(id = orderId)

            // Clear active payment request so bottom sheet closes cleanly
            clearDayCart(dayIndex)
            _activePaymentRequest.value = null
            _completedOrderReceipt.value = savedOrder

            if (isOrderPaid) {
                _toastMessage.value = if (shouldLockImmediately) {
                    "Order $orderNumber placed & locked! Kitchen notified."
                } else {
                    "Order $orderNumber confirmed! You can lock before 10:30 PM."
                }
            } else {
                _toastMessage.value = "Order $orderNumber placed (PENDING). Awaiting payment confirmation."
            }
        }
    }

    fun confirmVerifiedOrder(orderNumber: String, transactionId: String, shouldLockImmediately: Boolean = true) {
        viewModelScope.launch {
            val kitchenStatus = if (shouldLockImmediately) "LOCKED & CONFIRMED" else "CONFIRMED"
            repository.updateOrderPaymentStatus(orderNumber, "PAID", transactionId, kitchenStatus)
            val dayIndex = _selectedDayIndex.value
            clearDayCart(dayIndex)
            _activePaymentRequest.value = null
            _toastMessage.value = "Payment verified with Cashfree! Order $orderNumber confirmed."
        }
    }

    fun verifyManualPayment(orderId: Long, orderNumber: String) {
        viewModelScope.launch {
            val verifiedTxnId = "UPI_WA_CREDIT_${System.currentTimeMillis() % 1000000}"
            repository.updateOrderPaymentStatus(orderNumber, "PAID", verifiedTxnId, "CONFIRMED")
            _toastMessage.value = "Bank credit verified for Order #$orderNumber! Marked as PAID & Confirmed."
        }
    }


    fun lockOrder(orderId: Long) {
        viewModelScope.launch {
            repository.lockOrder(orderId, System.currentTimeMillis(), "LOCKED_BY_USER")
            _toastMessage.value = "Order locked for kitchen prep! Changes are now frozen."
        }
    }

    fun updateOrderStatus(orderId: Long, newStatus: String) {
        viewModelScope.launch {
            repository.updateKitchenStatus(orderId, newStatus)
            val upper = newStatus.uppercase().trim()
            _toastMessage.value = when {
                upper.contains("READY") && upper.contains("PACK") || newStatus.equals("Ready and Packed", ignoreCase = true) ->
                    "👨‍🍳 Chef Prep: Order is Ready and Packed! Customer notified."
                upper.contains("DELIVER") ->
                    "✅ Order marked as Delivered!"
                upper.contains("PREPAR") ->
                    "🍳 Chef Prep: Started preparing order."
                else -> "Status updated to $newStatus"
            }
        }
    }

    fun rotateChefsChoiceOrderDish(orderId: Long, currentSummary: String) {
        viewModelScope.launch {
            val availableDishes = menuDishes.value.filter { it.isAvailable }.ifEmpty { menuDishes.value }
            if (availableDishes.isEmpty()) return@launch

            val currentIndex = availableDishes.indexOfFirst { dish ->
                currentSummary.contains(dish.name, ignoreCase = true)
            }
            val nextIndex = if (currentIndex >= 0) (currentIndex + 1) % availableDishes.size else 0
            val nextDish = availableDishes[nextIndex]

            val newSummary = "Chef's Weekly Choice: 1x ${nextDish.name} (Round Robin)"
            repository.updateOrderItemsSummary(orderId, newSummary)
            _toastMessage.value = "🔄 Admin updated dish to ${nextDish.name} in round robin rotation"
        }
    }

    fun setChefsChoiceOrderDish(orderId: Long, dishName: String) {
        viewModelScope.launch {
            val newSummary = "Chef's Weekly Choice: 1x $dishName (Round Robin)"
            repository.updateOrderItemsSummary(orderId, newSummary)
            _toastMessage.value = "✓ Assigned $dishName for this delivery"
        }
    }

    fun dismissReceipt() {
        _completedOrderReceipt.value = null
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    fun updateDeliverySlot(slot: String) {
        repository.updateDeliverySlot(slot)
    }

    fun updateDeliveryAddress(address: String, context: Context? = null) {
        val trimmed = address.trim()
        if (trimmed.isNotBlank()) {
            repository.updateAddress(trimmed)
            val ctx = context ?: getApplication<Application>()
            val locInfo = DeliveryLocationService.createLocationInfoForAddress(ctx, trimmed)
            _deliveryLocationInfo.value = locInfo
            _toastMessage.value = "📍 Address & Google Maps pin updated (${locInfo.locality}, ${locInfo.distanceKm} km)"
        }
    }

    private suspend fun reverseGeocodeSuspend(
        ctx: Context,
        lat: Double,
        lng: Double
    ): Triple<String, String, String> = suspendCancellableCoroutine { cont ->
        DeliveryLocationService.reverseGeocodeCoordinates(ctx, lat, lng) { formatted, locality, postalCode ->
            if (cont.isActive) {
                cont.resume(Triple(formatted, locality, postalCode))
            }
        }
    }

    fun updatePinnedLocation(lat: Double, lng: Double, buildingDetail: String = "", context: Context? = null) {
        val ctx = context ?: getApplication<Application>()
        viewModelScope.launch {
            val (fmt, loc, pin) = reverseGeocodeSuspend(ctx, lat, lng)
            val locInfo = DeliveryLocationService.createLocationInfoForCoordinates(
                context = ctx,
                lat = lat,
                lng = lng,
                buildingDetail = buildingDetail,
                preResolvedAddress = fmt,
                preResolvedLocality = loc,
                preResolvedPostalCode = pin
            )
            _deliveryLocationInfo.value = locInfo
            repository.updateAddress(locInfo.addressFormatted)
            _toastMessage.value = "📍 Google Maps Pin Saved: ${locInfo.locality} (${locInfo.distanceKm} km from kitchen)"
        }
    }

    fun saveManualAddress(
        id: String? = null,
        label: String = "Home",
        flatDoor: String,
        buildingSociety: String,
        street: String,
        area: String,
        city: String = "",
        landmark: String = "",
        pincode: String,
        isDefault: Boolean = false
    ) {
        val parts = mutableListOf<String>()
        if (flatDoor.isNotBlank()) parts.add(flatDoor.trim())
        if (buildingSociety.isNotBlank()) parts.add(buildingSociety.trim())
        if (street.isNotBlank()) parts.add(street.trim())
        if (landmark.isNotBlank()) parts.add("Opp. ${landmark.trim()}")
        if (area.isNotBlank()) parts.add(area.trim())
        if (city.isNotBlank()) parts.add(city.trim())
        if (pincode.isNotBlank()) parts.add(pincode.trim())
        val formatted = parts.joinToString(", ")

        val ctx = getApplication<Application>()
        val locInfo = DeliveryLocationService.createLocationInfoForAddress(ctx, formatted)

        viewModelScope.launch {
            val entity = SavedAddressEntity(
                id = id ?: UUID.randomUUID().toString(),
                label = label.ifBlank { "Home" },
                formattedAddress = formatted,
                flatDoorNumber = flatDoor.trim(),
                buildingSociety = buildingSociety.trim(),
                street = street.trim(),
                area = if (city.isNotBlank()) "${area.trim()}, ${city.trim()}" else area.trim(),
                landmark = landmark.trim(),
                pincode = pincode.trim(),
                latitude = locInfo.latitude,
                longitude = locInfo.longitude,
                distanceKm = locInfo.distanceKm,
                deliveryZone = locInfo.deliveryZone,
                isDefault = isDefault
            )
            if (id != null) {
                repository.updateSavedAddress(entity)
            } else {
                repository.addSavedAddress(entity)
            }
            if (isDefault) {
                _deliveryLocationInfo.value = locInfo
            }
            _toastMessage.value = "Address saved: $label (${locInfo.distanceKm} km from kitchen)"
        }
    }

    fun savePinnedLocation(
        id: String? = null,
        label: String = "Home",
        lat: Double,
        lng: Double,
        buildingDetail: String = "",
        isDefault: Boolean = false,
        flatDoor: String = "",
        floor: String = "",
        building: String = "",
        pincode: String = ""
    ) {
        val ctx = getApplication<Application>()
        val effectiveDetail = if (flatDoor.isNotBlank() || building.isNotBlank() || pincode.isNotBlank()) {
            listOfNotNull(
                flatDoor.takeIf { it.isNotBlank() },
                floor.takeIf { it.isNotBlank() }?.let { "Floor: $it" },
                building.takeIf { it.isNotBlank() },
                pincode.takeIf { it.isNotBlank() }?.let { "PIN: $it" }
            ).joinToString(", ")
        } else {
            buildingDetail
        }
        viewModelScope.launch {
            val (resolvedFmt, resolvedLoc, resolvedPin) = reverseGeocodeSuspend(ctx, lat, lng)
            val locInfo = DeliveryLocationService.createLocationInfoForCoordinates(
                context = ctx,
                lat = lat,
                lng = lng,
                buildingDetail = effectiveDetail,
                preResolvedAddress = resolvedFmt,
                preResolvedLocality = resolvedLoc,
                preResolvedPostalCode = resolvedPin
            )

            val extractedPin = when {
                pincode.isNotBlank() -> pincode.trim()
                buildingDetail.contains("PIN:") -> buildingDetail.substringAfter("PIN:").trim().take(6)
                resolvedPin.isNotBlank() -> resolvedPin
                else -> ""
            }
            val extractedFlat = flatDoor.ifBlank {
                if (buildingDetail.contains(",")) buildingDetail.substringBefore(",").trim() else buildingDetail.trim()
            }
            val extractedBld = when {
                building.isNotBlank() && floor.isNotBlank() -> "Floor: $floor, $building"
                building.isNotBlank() -> building
                buildingDetail.contains(",") -> buildingDetail.substringAfter(",").substringBefore(", PIN:").trim()
                else -> ""
            }

            val entity = SavedAddressEntity(
                id = id ?: UUID.randomUUID().toString(),
                label = label.ifBlank { "Home" },
                formattedAddress = locInfo.addressFormatted,
                flatDoorNumber = extractedFlat,
                buildingSociety = extractedBld,
                area = locInfo.locality,
                pincode = extractedPin,
                latitude = locInfo.latitude,
                longitude = locInfo.longitude,
                distanceKm = locInfo.distanceKm,
                deliveryZone = locInfo.deliveryZone,
                isDefault = isDefault
            )
            val currentDefault = repository.allSavedAddresses.firstOrNull()?.find { it.isDefault }
            val wasEditingDefault = id != null && currentDefault?.id == id
            if (id != null) {
                repository.updateSavedAddress(entity)
            } else {
                repository.addSavedAddress(entity)
            }
            if (isDefault || wasEditingDefault || repository.savedAddress.value.isBlank()) {
                _deliveryLocationInfo.value = locInfo
                repository.updateAddress(locInfo.addressFormatted)
            }
            _toastMessage.value = if (id != null) "📍 Address updated: $label (${locInfo.distanceKm} km)" else "📍 Address saved: $label (${locInfo.distanceKm} km)"
        }
    }

    fun deleteAddress(id: String) {
        viewModelScope.launch {
            repository.deleteSavedAddress(id)
            _toastMessage.value = "Address deleted."
        }
    }

    fun setDefaultAddress(id: String) {
        viewModelScope.launch {
            repository.setDefaultSavedAddress(id)
            val list = repository.allSavedAddresses.firstOrNull() ?: emptyList()
            val chosen = list.find { it.id == id }
            if (chosen != null) {
                _deliveryLocationInfo.value = DeliveryLocationInfo(
                    latitude = chosen.latitude,
                    longitude = chosen.longitude,
                    accuracyMeters = 5f,
                    addressFormatted = chosen.formattedAddress,
                    locality = chosen.area.ifBlank { "Delivery Zone" },
                    distanceKm = chosen.distanceKm,
                    isDeliverable = chosen.distanceKm <= 14.0,
                    deliveryZone = chosen.deliveryZone,
                    estimatedMinutes = (15 + (chosen.distanceKm * 2.5)).roundToInt()
                )
            }
            _toastMessage.value = "Default delivery address updated."
        }
    }

    fun updatePhoneNumber(phone: String) {
        repository.updatePhoneNumber(phone)
        _toastMessage.value = "Updated delivery contact number: $phone"
    }

    fun toggleAutoLock(enabled: Boolean) {
        repository.setAutoLockEnabled(enabled)
    }

    fun detectCurrentLocation(context: Context) {
        _isDetectingLocation.value = true
        DeliveryLocationService.detectPreciseLocation(
            context = context,
            onSuccess = { locInfo ->
                _deliveryLocationInfo.value = locInfo
                _isDetectingLocation.value = false
                repository.updateAddress(locInfo.addressFormatted)
                _toastMessage.value = "📍 Location Verified: ${locInfo.locality} (${locInfo.distanceKm} km from kitchen)"
            },
            onError = { err ->
                _isDetectingLocation.value = false
                _toastMessage.value = "Location Note: $err"
            }
        )
    }

    fun setDeliveryLocationInfo(info: DeliveryLocationInfo) {
        _deliveryLocationInfo.value = info
        repository.updateAddress(info.addressFormatted)
    }

    fun topUpWallet(amount: Double) {
        repository.topUpWallet(amount)
        _toastMessage.value = "Added ₹${amount.toInt()} to Vyanjanam Wallet!"
    }

    fun triggerCloudSync() {
        viewModelScope.launch {
            val result = repository.manualSyncFirebase()
            _toastMessage.value = result
        }
    }

    // Google Sign-In Actions
    fun openGoogleSignIn() {
        _googleAuthError.value = null
        _showGoogleSignInDialog.value = true
        _showPhoneOtpDialog.value = false
    }

    fun closeGoogleSignIn() {
        _showGoogleSignInDialog.value = false
        _googleAuthError.value = null
    }

    fun signInWithGoogle(email: String, pass: String, name: String) {
        viewModelScope.launch {
            _isGoogleSigningIn.value = true
            _googleAuthError.value = null
            delay(500)
            try {
                repository.signInWithGoogle(email, pass, name)
                _isGoogleSigningIn.value = false
                _showGoogleSignInDialog.value = false
                _toastMessage.value = "Signed in successfully with Google ($email)!"
                checkHasSavedAddressAfterAuth()
            } catch (e: Exception) {
                _isGoogleSigningIn.value = false
                _googleAuthError.value = "Sign in failed: ${e.message}"
            }
        }
    }

    fun registerNewUser(
        name: String,
        email: String,
        pass: String,
        phone: String,
        address: String,
        preferredSlot: String
    ) {
        viewModelScope.launch {
            _isGoogleSigningIn.value = true
            _googleAuthError.value = null
            delay(500)
            try {
                repository.registerNewUser(
                    name = name,
                    email = email,
                    password = pass,
                    phone = phone,
                    address = address,
                    preferredSlot = preferredSlot
                )
                if (address.isNotBlank()) {
                    val loc = DeliveryLocationService.createLocationInfoForAddress(getApplication<Application>(), address)
                    repository.addSavedAddress(
                        SavedAddressEntity(
                            label = "Home",
                            formattedAddress = address,
                            latitude = loc.latitude,
                            longitude = loc.longitude,
                            distanceKm = loc.distanceKm,
                            deliveryZone = loc.deliveryZone,
                            isDefault = true
                        )
                    )
                }
                _isGoogleSigningIn.value = false
                _showGoogleSignInDialog.value = false
                _toastMessage.value = "Welcome, $name! Account created with ₹100 Welcome Bonus."
                checkHasSavedAddressAfterAuth()
            } catch (e: Exception) {
                _isGoogleSigningIn.value = false
                _googleAuthError.value = "Registration failed: ${e.message}"
            }
        }
    }

    private fun checkHasSavedAddressAfterAuth() {
        viewModelScope.launch {
            delay(500)
            val addrs = savedAddresses.value
            val singleAddr = repository.savedAddress.value
            if (addrs.isEmpty() && singleAddr.isBlank()) {
                _showAddressSetupPrompt.value = true
                _toastMessage.value = "Please save your delivery address so orders can be delivered!"
            }
        }
    }

    // Profile & Sign Out Actions
    fun openProfileSheet() {
        _showProfileSheet.value = true
    }

    fun closeProfileSheet() {
        _showProfileSheet.value = false
    }

    fun signOut() {
        repository.signOut()
        _showProfileSheet.value = false
        _toastMessage.value = "Signed out of Vyanjanam Kitchen"
    }

    fun deleteUserAccount() {
        viewModelScope.launch {
            repository.deleteUserAccountAndData()
            _showProfileSheet.value = false
            _toastMessage.value = "Your account and all personal data have been permanently deleted."
        }
    }

    fun updateProfile(name: String, email: String) {
        repository.updateProfile(name, email)
        _showProfileSheet.value = false
        _toastMessage.value = "Profile updated successfully!"
    }

    // Phone OTP Auth Actions
    fun openPhoneOtp() {
        _phoneAuthError.value = null
        _authStep.value = AuthStep.PHONE_INPUT
        _showPhoneOtpDialog.value = true
        _showGoogleSignInDialog.value = false
    }

    fun closePhoneOtp() {
        _showPhoneOtpDialog.value = false
        _phoneAuthError.value = null
    }

    fun setPhoneInput(phone: String) {
        _phoneInput.value = phone
    }

    fun setAuthNameInput(name: String) {
        _authNameInput.value = name
    }

    fun setOtpInput(otp: String) {
        _otpInput.value = otp
    }

    fun sendPhoneOtp() {
        if (_phoneInput.value.length < 10) {
            _phoneAuthError.value = "Please enter a valid 10-digit mobile number"
            return
        }
        _isSendingOtp.value = true
        _phoneAuthError.value = null
        viewModelScope.launch {
            delay(600)
            _isSendingOtp.value = false
            _activeOtpCode.value = "7412"
            _authStep.value = AuthStep.OTP_VERIFICATION
            _toastMessage.value = "Test OTP 7412 sent to ${_phoneInput.value}"
        }
    }

    fun verifyPhoneOtp() {
        if (_otpInput.value == (_activeOtpCode.value ?: "7412")) {
            val name = _authNameInput.value.ifBlank { "Gourmet Foodie" }
            repository.signIn(_phoneInput.value, name)
            _showPhoneOtpDialog.value = false
            _toastMessage.value = "Welcome back, $name!"
            checkHasSavedAddressAfterAuth()
        } else {
            _phoneAuthError.value = "Invalid OTP. Use test OTP: 7412"
        }
    }

    // Dynamic Food Menu Admin Actions
    fun toggleDishAvailability(dishId: String, currentAvailable: Boolean) {
        viewModelScope.launch {
            repository.updateDishAvailability(dishId, !currentAvailable)
            _toastMessage.value = if (!currentAvailable) "Item marked Available" else "Item marked Unavailable"
        }
    }

    fun updateDishDetails(dishId: String, name: String, subName: String) {
        viewModelScope.launch {
            repository.updateDishName(dishId, name, subName)
            _toastMessage.value = "Menu item details updated"
        }
    }

    fun updateDishPrice(dishId: String, newOptions: List<PortionOption>, dishName: String = "") {
        viewModelScope.launch {
            repository.updateDishPrices(dishId, newOptions)
            _toastMessage.value = if (dishName.isNotBlank()) "Updated price for \"$dishName\"" else "Item price updated"
        }
    }

    fun addMenuDish(
        name: String,
        subName: String,
        category: String,
        description: String,
        price: Double,
        isVegetarian: Boolean = true,
        isAvailable: Boolean = true
    ) {
        val cleanName = name.trim()
        if (cleanName.isBlank()) {
            _toastMessage.value = "Please enter an item name"
            return
        }
        val safePrice = if (price <= 0) 50.0 else price
        val id = "dish_" + cleanName.lowercase().replace("[^a-z0-9]+".toRegex(), "_").trim('_') + "_" + (System.currentTimeMillis() % 100000)
        val options = listOf(
            PortionOption(
                id = "${id}_portion_reg",
                label = "Regular Portion",
                pieceCount = 2,
                price = safePrice,
                description = "Freshly prepared gourmet meal"
            ),
            PortionOption(
                id = "${id}_portion_large",
                label = "Super Value Portion",
                pieceCount = 4,
                price = (safePrice * 1.6).coerceAtLeast(safePrice + 30.0),
                description = "Double portion value combo"
            )
        )
        val newDish = MenuDish(
            id = id,
            name = cleanName,
            subName = subName.ifBlank { "$category Specialty" },
            category = category.ifBlank { "Breakfast" },
            description = description.ifBlank { "Freshly prepared with finest ingredients and authentic flavor." },
            isVegetarian = isVegetarian,
            isAvailable = isAvailable,
            options = options,
            addOns = KitchenMenuData.commonAddOns,
            prepTimeMinutes = 20,
            sortOrder = 99
        )
        viewModelScope.launch {
            repository.addMenuDish(newDish)
            _toastMessage.value = "Added \"$cleanName\" to kitchen menu"
        }
    }

    fun removeMenuDish(dishId: String, dishName: String = "") {
        viewModelScope.launch {
            repository.removeMenuDish(dishId)
            _toastMessage.value = if (dishName.isNotBlank()) "Removed \"$dishName\" from menu" else "Item removed from menu"
        }
    }
}
