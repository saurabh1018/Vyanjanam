package com.example

import android.Manifest
import android.app.Application
import android.content.Context
import android.location.Location
import android.location.LocationManager
import android.os.Looper
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.database.KitchenDatabase
import com.example.data.entity.OrderEntity
import com.example.data.entity.SavedAddressEntity
import com.example.data.repository.KitchenRepository
import com.example.util.DeliveryLocationInfo
import com.example.util.DeliveryLocationService
import com.example.viewmodel.KitchenViewModel
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowLooper

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class AddressManagementTest {

    private lateinit var db: KitchenDatabase
    private lateinit var context: Context

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, KitchenDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `test initial state has zero dummy addresses and blank default address`() = runBlocking {
        val repository = KitchenRepository(
            orderDao = db.orderDao(),
            dayCartDao = db.dayCartDao(),
            userSubscriptionDao = db.userSubscriptionDao(),
            savedAddressDao = db.savedAddressDao(),
            context = context
        )

        val initialList = db.savedAddressDao().getAllSavedAddressesSync()
        assertTrue("Database must have no pre-seeded dummy addresses", initialList.isEmpty())

        val repoAddress = repository.savedAddress.value
        assertEquals("Initial saved address must be blank", "", repoAddress)
    }

    @Test
    fun `test Mode 1 - Pin and save location via Google Maps coordinates`() = runBlocking {
        val lat = 15.2925
        val lng = 73.9680
        val buildingDetail = "Tower 4, 8th Floor"
        val info = DeliveryLocationService.createLocationInfoForCoordinates(
            context = context,
            lat = lat,
            lng = lng,
            buildingDetail = buildingDetail
        )

        assertNotNull(info)
        assertEquals(lat, info.latitude, 0.0001)
        assertEquals(lng, info.longitude, 0.0001)
        assertTrue(info.isDeliverable)
        assertTrue(info.distanceKm > 0.0)
        assertTrue(info.addressFormatted.contains(buildingDetail))

        // Save to Room DB
        val addressEntity = SavedAddressEntity(
            id = "pin-addr-1",
            label = "Home",
            formattedAddress = info.addressFormatted,
            flatDoorNumber = buildingDetail,
            buildingSociety = "",
            street = "",
            area = info.locality,
            landmark = "",
            pincode = "",
            latitude = info.latitude,
            longitude = info.longitude,
            distanceKm = info.distanceKm,
            deliveryZone = info.deliveryZone,
            isDefault = true
        )
        db.savedAddressDao().insertAddress(addressEntity)

        val retrieved = db.savedAddressDao().getAddressById("pin-addr-1")
        assertNotNull(retrieved)
        assertEquals("Home", retrieved?.label)
        assertEquals(lat, retrieved?.latitude ?: 0.0, 0.0001)
        assertEquals(lng, retrieved?.longitude ?: 0.0, 0.0001)
        assertTrue(retrieved?.isDefault == true)
    }

    @Test
    fun `test Mode 2 - Manual address creation and 6-digit Indian pincode validation`() = runBlocking {
        val pinRegex = Regex("^[1-9][0-9]{5}$")

        // Valid pincodes
        assertTrue("110001 must be valid", "110001".matches(pinRegex))
        assertTrue("560034 must be valid", "560034".matches(pinRegex))
        assertTrue("400001 must be valid", "400001".matches(pinRegex))

        // Invalid pincodes (starting with 0, letters, wrong length)
        assertFalse("056034 starting with 0 must be invalid", "056034".matches(pinRegex))
        assertFalse("56010 too short must be invalid", "56010".matches(pinRegex))
        assertFalse("5601021 too long must be invalid", "5601021".matches(pinRegex))
        assertFalse("5600A1 alphanumeric must be invalid", "5600A1".matches(pinRegex))
        assertFalse("Blank pincode must be invalid", "".matches(pinRegex))

        // Save valid manual address
        val manualAddr = SavedAddressEntity(
            id = "manual-addr-1",
            label = "Work",
            formattedAddress = "Flat 502, Prestige Tower, 5th Cross, Sector 7, Tech City, Opp. Metro Station, 110001",
            flatDoorNumber = "Flat 502",
            buildingSociety = "Prestige Tower",
            street = "5th Cross, Sector 7",
            area = "Tech City",
            landmark = "Opp. Metro Station",
            pincode = "110001",
            latitude = 15.2925,
            longitude = 73.9680,
            distanceKm = 1.4,
            deliveryZone = "Zone A • Express Margao & Fatorda (15-20m)",
            isDefault = false
        )
        db.savedAddressDao().insertAddress(manualAddr)

        val retrieved = db.savedAddressDao().getAddressById("manual-addr-1")
        assertNotNull(retrieved)
        assertEquals("Work", retrieved?.label)
        assertEquals("110001", retrieved?.pincode)
        assertEquals("Flat 502", retrieved?.flatDoorNumber)
        assertEquals("Prestige Tower", retrieved?.buildingSociety)
    }

    @Test
    fun `test setting default address clears other default addresses`() = runBlocking {
        val addr1 = SavedAddressEntity(
            id = "addr-1",
            label = "Home",
            formattedAddress = "Address 1",
            isDefault = true
        )
        val addr2 = SavedAddressEntity(
            id = "addr-2",
            label = "Work",
            formattedAddress = "Address 2",
            isDefault = false
        )

        db.savedAddressDao().insertAddress(addr1)
        db.savedAddressDao().insertAddress(addr2)

        var defaultAddr = db.savedAddressDao().getDefaultAddress()
        assertEquals("addr-1", defaultAddr?.id)

        // Change default to addr-2
        db.savedAddressDao().setAsDefaultAddress("addr-2")

        val updatedAddr1 = db.savedAddressDao().getAddressById("addr-1")
        val updatedAddr2 = db.savedAddressDao().getAddressById("addr-2")

        assertFalse(updatedAddr1!!.isDefault)
        assertTrue(updatedAddr2!!.isDefault)

        defaultAddr = db.savedAddressDao().getDefaultAddress()
        assertEquals("addr-2", defaultAddr?.id)
    }

    @Test
    fun `test editing and deleting saved addresses`() = runBlocking {
        val addr = SavedAddressEntity(
            id = "addr-to-edit",
            label = "Home",
            formattedAddress = "Old Address, 110001",
            flatDoorNumber = "101",
            buildingSociety = "Old Tower",
            pincode = "110001"
        )
        db.savedAddressDao().insertAddress(addr)

        // Edit
        val updated = addr.copy(
            formattedAddress = "New Address, 110002",
            flatDoorNumber = "202",
            pincode = "110002"
        )
        db.savedAddressDao().updateAddress(updated)

        val retrieved = db.savedAddressDao().getAddressById("addr-to-edit")
        assertEquals("202", retrieved?.flatDoorNumber)
        assertEquals("110002", retrieved?.pincode)

        // Delete
        db.savedAddressDao().deleteAddressById("addr-to-edit")
        val deleted = db.savedAddressDao().getAddressById("addr-to-edit")
        assertNull(deleted)
    }

    @Test
    fun `test preserving selected address and coordinates with OrderEntity`() = runBlocking {
        val selectedAddress = "Penthouse 901, Royal Palms, Colva Road, Margao, 403601"
        val selectedLat = 15.2785
        val selectedLng = 73.9167
        val selectedDist = 5.2

        val order = OrderEntity(
            orderNumber = "ORD-TEST-ADDR-99",
            targetDate = "Tomorrow",
            dayOfWeek = "Friday",
            itemsSummary = "2x Aloo Paratha",
            totalAmount = 60.0,
            deliverySlot = "7:45 AM - 8:30 AM",
            deliveryAddress = selectedAddress,
            deliveryLatitude = selectedLat,
            deliveryLongitude = selectedLng,
            deliveryDistanceKm = selectedDist,
            isLocked = true,
            kitchenStatus = "LOCKED"
        )
        db.orderDao().insertOrder(order)

        val orders = db.orderDao().getAllOrdersSync()
        val savedOrder = orders.firstOrNull { it.orderNumber == "ORD-TEST-ADDR-99" }
        assertNotNull(savedOrder)
        assertEquals(selectedAddress, savedOrder?.deliveryAddress)
        assertEquals(selectedLat, savedOrder?.deliveryLatitude ?: 0.0, 0.0001)
        assertEquals(selectedLng, savedOrder?.deliveryLongitude ?: 0.0, 0.0001)
        assertEquals(selectedDist, savedOrder?.deliveryDistanceKm ?: 0.0, 0.01)
    }

    @Test
    fun `test 14 km delivery radius cutoff and non-serviceable validation`() = runBlocking {
        assertEquals(14.0, DeliveryLocationService.MAX_DELIVERY_RADIUS_KM, 0.001)

        // Location 1: Within 14 km (Fatorda / Colva ~5.2 km from Margao kitchen)
        val nearInfo = DeliveryLocationService.createLocationInfoForCoordinates(
            context = context,
            lat = 15.2785,
            lng = 73.9167,
            buildingDetail = "Villa 10"
        )
        assertNotNull(nearInfo)
        assertTrue("Address within 14 km must be deliverable", nearInfo.isDeliverable)
        assertTrue("Distance must be <= 14 km", nearInfo.distanceKm <= 14.0)

        // Location 2: Far beyond 14 km (Panaji / North Goa ~32 km from Margao kitchen)
        val farInfo = DeliveryLocationService.createLocationInfoForCoordinates(
            context = context,
            lat = 15.4989,
            lng = 73.8278,
            buildingDetail = "Office 402"
        )
        assertNotNull(farInfo)
        assertFalse("Address beyond 14 km must NOT be deliverable", farInfo.isDeliverable)
        assertTrue("Distance must be > 14 km", farInfo.distanceKm > 14.0)
        assertTrue("Delivery zone must indicate Not Serviceable", farInfo.deliveryZone.contains("Not Serviceable"))
    }

    @Test
    fun `test parsing google maps link or coordinates and saving or updating pinned address`() = runBlocking {
        // 1. Parse Google Maps URL with ?q=lat,lng
        val link1 = "https://maps.google.com/?q=15.2832,73.9862"
        val parsed1 = DeliveryLocationService.parseCoordinatesOrMapLink(link1)
        assertNotNull("Google Maps URL with ?q= must be parsed", parsed1)
        assertEquals(15.2832, parsed1!!.first, 0.0001)
        assertEquals(73.9862, parsed1.second, 0.0001)

        // 2. Parse Google Maps @lat,lng URL
        val link2 = "https://www.google.com/maps/@15.2785,73.9167,16z"
        val parsed2 = DeliveryLocationService.parseCoordinatesOrMapLink(link2)
        assertNotNull("Google Maps @lat,lng URL must be parsed", parsed2)
        assertEquals(15.2785, parsed2!!.first, 0.0001)
        assertEquals(73.9167, parsed2.second, 0.0001)

        // 3. Parse direct coordinates string "15.2925, 73.9680"
        val coordStr = "15.2925, 73.9680"
        val parsed3 = DeliveryLocationService.parseCoordinatesOrMapLink(coordStr)
        assertNotNull("Direct coordinates string must be parsed", parsed3)
        assertEquals(15.2925, parsed3!!.first, 0.0001)
        assertEquals(73.9680, parsed3.second, 0.0001)

        // 4. Save parsed location into Room database
        val locInfo = DeliveryLocationService.createLocationInfoForCoordinates(
            context = context,
            lat = parsed1.first,
            lng = parsed1.second,
            buildingDetail = "Flat 102, Ocean Vista"
        )
        val initialAddress = SavedAddressEntity(
            id = "pasted-addr-1",
            label = "Home",
            formattedAddress = locInfo.addressFormatted,
            flatDoorNumber = "Flat 102, Ocean Vista",
            latitude = locInfo.latitude,
            longitude = locInfo.longitude,
            distanceKm = locInfo.distanceKm,
            deliveryZone = locInfo.deliveryZone,
            isDefault = true
        )
        db.savedAddressDao().insertAddress(initialAddress)

        val retrieved = db.savedAddressDao().getAddressById("pasted-addr-1")
        assertNotNull(retrieved)
        assertEquals("Home", retrieved?.label)
        assertEquals(15.2832, retrieved?.latitude ?: 0.0, 0.0001)
        assertEquals(73.9862, retrieved?.longitude ?: 0.0, 0.0001)

        // 5. User pastes a new link/coordinates to UPDATE the address
        val updatedLocInfo = DeliveryLocationService.createLocationInfoForCoordinates(
            context = context,
            lat = parsed2.first,
            lng = parsed2.second,
            buildingDetail = "Villa 8, Colva Coast"
        )
        val updatedAddress = retrieved!!.copy(
            formattedAddress = updatedLocInfo.addressFormatted,
            flatDoorNumber = "Villa 8, Colva Coast",
            latitude = updatedLocInfo.latitude,
            longitude = updatedLocInfo.longitude,
            distanceKm = updatedLocInfo.distanceKm,
            deliveryZone = updatedLocInfo.deliveryZone
        )
        db.savedAddressDao().updateAddress(updatedAddress)

        val updatedRetrieved = db.savedAddressDao().getAddressById("pasted-addr-1")
        assertNotNull(updatedRetrieved)
        assertEquals(15.2785, updatedRetrieved?.latitude ?: 0.0, 0.0001)
        assertEquals(73.9167, updatedRetrieved?.longitude ?: 0.0, 0.0001)
        assertTrue(updatedRetrieved!!.formattedAddress.contains("Villa 8"))
        assertTrue("Updated address within 14 km is deliverable", updatedRetrieved.distanceKm <= 14.0)
    }

    @Test
    fun `test direct UPI intent generation with vyanjanamm@ybl`() {
        assertEquals("vyanjanamm@ybl", com.example.payment.UpiPaymentHelper.OFFICIAL_UPI_ID)
        // 1. Default P2P URI: clean, unblocked transfer URI without unsigned merchant parameters
        val p2pUri = com.example.payment.UpiPaymentHelper.buildUpiUri("RK-7788", 140.0, isMerchantMode = false)
        assertTrue(p2pUri.startsWith("upi://pay?"))
        assertTrue(p2pUri.contains("pa=vyanjanamm%40ybl") || p2pUri.contains("pa=vyanjanamm@ybl"))
        assertTrue(p2pUri.contains("am=140.00"))
        assertTrue(p2pUri.contains("cu=INR"))

        // 2. Merchant mode URI with mc=5812 and tr
        val merchantUri = com.example.payment.UpiPaymentHelper.buildUpiUri("RK-7788", 140.0, isMerchantMode = true)
        assertTrue(merchantUri.contains("mc=5812"))
        assertTrue(merchantUri.contains("tr=VYAN"))
        assertEquals("Direct UPI (GPay, PhonePe, Paytm)", com.example.payment.PaymentMethodType.INSTANT_UPI.displayName)
    }

    @Test
    fun `test KDS advance orders daily summary and preparation statuses`() {
        // 1. Verify 4 distinct kitchen preparation statuses and progression
        assertEquals("Scheduled", com.example.ui.screens.KitchenPrepStatus.SCHEDULED.label)
        assertEquals("Preparing", com.example.ui.screens.KitchenPrepStatus.PREPARING.label)
        assertEquals("Ready and Packed", com.example.ui.screens.KitchenPrepStatus.READY_AND_PACKED.label)
        assertEquals("Order Delivered", com.example.ui.screens.KitchenPrepStatus.DELIVERED.label)

        // Progression sequence
        assertEquals("Preparing", com.example.ui.screens.KitchenPrepStatus.SCHEDULED.nextStatus)
        assertEquals("Ready and Packed", com.example.ui.screens.KitchenPrepStatus.PREPARING.nextStatus)
        assertEquals("Order Delivered", com.example.ui.screens.KitchenPrepStatus.READY_AND_PACKED.nextStatus)
        assertNull(com.example.ui.screens.KitchenPrepStatus.DELIVERED.nextStatus)

        // Status mapping from database strings
        assertEquals(com.example.ui.screens.KitchenPrepStatus.SCHEDULED, com.example.ui.screens.KitchenPrepStatus.fromKitchenStatus("CONFIRMED"))
        assertEquals(com.example.ui.screens.KitchenPrepStatus.SCHEDULED, com.example.ui.screens.KitchenPrepStatus.fromKitchenStatus("LOCKED & CONFIRMED"))
        assertEquals(com.example.ui.screens.KitchenPrepStatus.PREPARING, com.example.ui.screens.KitchenPrepStatus.fromKitchenStatus("PREPARING"))
        assertEquals(com.example.ui.screens.KitchenPrepStatus.READY_AND_PACKED, com.example.ui.screens.KitchenPrepStatus.fromKitchenStatus("Ready and Packed"))
        assertEquals(com.example.ui.screens.KitchenPrepStatus.DELIVERED, com.example.ui.screens.KitchenPrepStatus.fromKitchenStatus("Order Delivered"))

        // 2. Test parsing order items and quantities
        val summary1 = "2x Aloo Paratha (Full Portion), 1x Masala Chai (Regular)"
        val parsed = com.example.ui.screens.KdsOrderHelper.parseOrderItems(summary1)
        assertEquals(2, parsed.size)
        assertEquals(2, parsed[0].quantity)
        assertEquals("Aloo Paratha", parsed[0].dishName)
        assertEquals("Full Portion", parsed[0].portion)
        assertEquals(1, parsed[1].quantity)
        assertEquals("Masala Chai", parsed[1].dishName)

        // 3. Test daily advance planning aggregate item calculation
        val sampleOrders = listOf(
            OrderEntity(
                orderNumber = "RK-101",
                targetDate = "Tomorrow",
                dayOfWeek = "Friday",
                itemsSummary = "2x Aloo Paratha (Full Portion), 1x Masala Chai",
                totalAmount = 140.0,
                deliverySlot = "7:45 AM - 8:30 AM",
                deliveryAddress = "Margao",
                paymentStatus = "PAID",
                kitchenStatus = "Scheduled"
            ),
            OrderEntity(
                orderNumber = "RK-102",
                targetDate = "Tomorrow",
                dayOfWeek = "Friday",
                itemsSummary = "3x Aloo Paratha (Full Portion), 2x Kanda Poha",
                totalAmount = 210.0,
                deliverySlot = "7:45 AM - 8:30 AM",
                deliveryAddress = "Fatorda",
                paymentStatus = "PAYMENT_PENDING",
                kitchenStatus = "Preparing"
            )
        )

        val aggregated = com.example.ui.screens.KdsOrderHelper.aggregateDishes(sampleOrders)
        val alooParatha = aggregated.find { it.dishName == "Aloo Paratha" }
        assertNotNull(alooParatha)
        assertEquals(5, alooParatha?.totalPortions)

        val poha = aggregated.find { it.dishName == "Kanda Poha" }
        assertNotNull(poha)
        assertEquals(2, poha?.totalPortions)

        // 4. Verify payment status is separate from kitchen preparation status
        val pendingOrder = sampleOrders[1]
        assertEquals("PAYMENT_PENDING", pendingOrder.paymentStatus)
        assertEquals("Preparing", pendingOrder.kitchenStatus)
    }

    @Test
    fun `test UPI payment helper generates correct uri with vyanjanamm@ybl and launches safely without error`() {
        assertEquals("vyanjanamm@ybl", com.example.payment.UpiPaymentHelper.OFFICIAL_UPI_ID)
        assertEquals("Vyanjanam Pure Veg", com.example.payment.UpiPaymentHelper.PAYEE_NAME)
        assertEquals("5812", com.example.payment.UpiPaymentHelper.MERCHANT_CATEGORY_CODE)
        
        val uri = com.example.payment.UpiPaymentHelper.buildUpiUri("RK-9999", 120.0, isMerchantMode = true)
        assertTrue(uri.startsWith("upi://pay?"))
        assertTrue(uri.contains("pa=vyanjanamm@ybl") || uri.contains("pa=vyanjanamm%40ybl"))
        assertTrue(uri.contains("am=120.00"))
        assertTrue(uri.contains("cu=INR"))
        assertTrue(uri.contains("mc=5812"))
        assertTrue(uri.contains("tr=VYAN"))

        var fallbackMessage: String? = null
        com.example.payment.UpiPaymentHelper.launchUpiPayment(
            context = context,
            orderNumber = "RK-9999",
            amount = 120.0,
            targetPackage = null,
            onFallback = { msg -> fallbackMessage = msg }
        )
        // In Robolectric environment without external UPI apps, fallback copies vyanjanamm@ybl without crashing
        assertNotNull(fallbackMessage)
        assertTrue(fallbackMessage!!.contains("vyanjanamm@ybl"))

        val qrUrl = com.example.payment.UpiPaymentHelper.buildQrCodeUrl("RK-9999", 120.0)
        assertTrue(qrUrl.startsWith("https://api.qrserver.com/v1/create-qr-code/"))
        assertTrue(qrUrl.contains("vyanjanamm"))
    }

    @Test
    fun `test GPS detection fails cleanly when permission denied or location disabled without Panaji fallback`() {
        val app = context as Application
        val shadowApp = Shadows.shadowOf(app)
        shadowApp.denyPermissions(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )

        var permissionError: String? = null
        var permissionSuccess: DeliveryLocationInfo? = null
        DeliveryLocationService.detectPreciseLocation(
            context = app,
            onSuccess = { permissionSuccess = it },
            onError = { permissionError = it }
        )
        ShadowLooper.runUiThreadTasksIncludingDelayedTasks()

        assertNull("Must not return fake Panaji coordinates when permission denied", permissionSuccess)
        assertNotNull(permissionError)
        assertTrue(permissionError!!.contains("permission", ignoreCase = true))

        // Grant permission, but keep Location disabled in LocationManager
        shadowApp.grantPermissions(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        val locationManager = app.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val shadowLm = Shadows.shadowOf(locationManager)
        shadowLm.setLocationEnabled(false)

        var disabledError: String? = null
        var disabledSuccess: DeliveryLocationInfo? = null
        DeliveryLocationService.detectPreciseLocation(
            context = app,
            onSuccess = { disabledSuccess = it },
            onError = { disabledError = it }
        )
        ShadowLooper.runUiThreadTasksIncludingDelayedTasks()

        assertNull("Must not return fake Panaji coordinates when GPS is turned off", disabledSuccess)
        assertNotNull(disabledError)
        assertTrue(disabledError!!.contains("Location", ignoreCase = true))
    }

    @Test
    fun `test GPS detection fetches accurate user coordinates via active provider fix`() {
        val app = context as Application
        val shadowApp = Shadows.shadowOf(app)
        shadowApp.grantPermissions(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )

        val locationManager = app.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val shadowLm = Shadows.shadowOf(locationManager)
        shadowLm.setLocationEnabled(true)
        shadowLm.setProviderEnabled(LocationManager.GPS_PROVIDER, true)

        val userLat = 15.2993
        val userLng = 73.9585
        val gpsFix = Location(LocationManager.GPS_PROVIDER).apply {
            latitude = userLat
            longitude = userLng
            accuracy = 12.0f
            time = System.currentTimeMillis()
        }
        shadowLm.setLastKnownLocation(LocationManager.GPS_PROVIDER, gpsFix)

        val latch = CountDownLatch(1)
        var detected: DeliveryLocationInfo? = null
        var errorMsg: String? = null

        DeliveryLocationService.detectPreciseLocation(
            context = app,
            onSuccess = {
                detected = it
                latch.countDown()
            },
            onError = {
                errorMsg = it
                latch.countDown()
            }
        )
        ShadowLooper.runUiThreadTasksIncludingDelayedTasks()
        latch.await(2, TimeUnit.SECONDS)
        ShadowLooper.runUiThreadTasksIncludingDelayedTasks()

        assertNull("GPS fetch should succeed without error: $errorMsg", errorMsg)
        assertNotNull("Detected GPS location must not be null", detected)
        assertEquals(userLat, detected!!.latitude, 0.0001)
        assertEquals(userLng, detected!!.longitude, 0.0001)
        assertTrue("Margao GPS coordinates must be deliverable", detected!!.isDeliverable)
        assertTrue("Distance from kitchen should be ~2-4 km", detected!!.distanceKm in 1.0..5.0)
    }

    @Test
    fun `test KitchenViewModel savePinnedLocation stores single record with exact GPS coordinates`() = runBlocking {
        val app = context as Application
        val viewModel = KitchenViewModel(app)
        val targetLat = 15.2912
        val targetLng = 73.9715

        viewModel.savePinnedLocation(
            id = null,
            label = "Home",
            lat = targetLat,
            lng = targetLng,
            buildingDetail = "Flat 301, Sapphire Court, PIN: 403601",
            isDefault = true
        )

        // Wait briefly for viewModelScope coroutine and main handler geocoder callback
        val deadline = System.currentTimeMillis() + 3000L
        var savedList: List<SavedAddressEntity> = emptyList()
        while (System.currentTimeMillis() < deadline) {
            ShadowLooper.runUiThreadTasksIncludingDelayedTasks()
            savedList = KitchenDatabase.getDatabase(app).savedAddressDao().getAllSavedAddressesSync()
            if (savedList.isNotEmpty() && viewModel.deliveryLocationInfo.value != null) break
            kotlinx.coroutines.delay(50)
        }

        val matching = savedList.filter { it.flatDoorNumber == "Flat 301" }
        assertEquals("Should save exactly one address entry without duplicates", 1, matching.size)
        val saved = matching.first()
        assertEquals(targetLat, saved.latitude, 0.0001)
        assertEquals(targetLng, saved.longitude, 0.0001)
        assertEquals("403601", saved.pincode)
        assertTrue(saved.isDefault)
        assertEquals(targetLat, viewModel.deliveryLocationInfo.value?.latitude ?: 0.0, 0.0001)
        assertEquals(targetLng, viewModel.deliveryLocationInfo.value?.longitude ?: 0.0, 0.0001)
    }
}