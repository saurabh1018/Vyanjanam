package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.database.KitchenDatabase
import com.example.data.entity.DayCartItemEntity
import com.example.data.entity.OrderEntity
import com.example.data.entity.UserSubscriptionEntity
import com.example.data.repository.KitchenRepository
import com.example.model.KitchenMenuData
import com.example.model.ScheduleHelper
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Vyanjanam", appName)
    }

    @Test
    fun `verify breakfast menu dishes and exact prices`() {
        val dishes = KitchenMenuData.menuDishes
        assertEquals(8, dishes.size)

        // 1. Aloo paratha: 2 for 130, 4 for 230
        val aloo = dishes.find { it.id == "aloo_paratha" }
        assertNotNull(aloo)
        assertEquals(130.0, aloo!!.options.find { it.pieceCount == 2 }?.price ?: 0.0, 0.01)
        assertEquals(230.0, aloo.options.find { it.pieceCount == 4 }?.price ?: 0.0, 0.01)

        // 2. Gobhi paratha: 2 for 130, 4 for 230
        val gobhi = dishes.find { it.id == "gobhi_paratha" }
        assertNotNull(gobhi)
        assertEquals(130.0, gobhi!!.options.find { it.pieceCount == 2 }?.price ?: 0.0, 0.01)
        assertEquals(230.0, gobhi.options.find { it.pieceCount == 4 }?.price ?: 0.0, 0.01)

        // 3. Mooli paratha: 2 for 130, 4 for 230
        val mooli = dishes.find { it.id == "mooli_paratha" }
        assertNotNull(mooli)
        assertEquals(130.0, mooli!!.options.find { it.pieceCount == 2 }?.price ?: 0.0, 0.01)
        assertEquals(230.0, mooli.options.find { it.pieceCount == 4 }?.price ?: 0.0, 0.01)

        // 4. Paneer paratha: 2 for 170, 4 for 320
        val paneer = dishes.find { it.id == "paneer_paratha" }
        assertNotNull(paneer)
        assertEquals(170.0, paneer!!.options.find { it.pieceCount == 2 }?.price ?: 0.0, 0.01)
        assertEquals(320.0, paneer.options.find { it.pieceCount == 4 }?.price ?: 0.0, 0.01)

        // 5. Plain paratha with Sabji: 2 for 119, 4 for 199
        val plain = dishes.find { it.id == "plain_paratha" }
        assertNotNull(plain)
        assertEquals(119.0, plain!!.options.find { it.pieceCount == 2 }?.price ?: 0.0, 0.01)
        assertEquals(199.0, plain.options.find { it.pieceCount == 4 }?.price ?: 0.0, 0.01)

        // 6. Idli with chutney: 4 for 99
        val idli = dishes.find { it.id == "idli_chutney" }
        assertNotNull(idli)
        assertEquals(99.0, idli!!.options.find { it.pieceCount == 4 }?.price ?: 0.0, 0.01)

        // 7. Goan Bhaji Pav: 99
        val pavBhaji = dishes.find { it.id == "pav_bhaji" }
        assertNotNull(pavBhaji)
        assertEquals("Goan Bhaji Pav", pavBhaji!!.name)
        assertEquals(99.0, pavBhaji.options[0].price, 0.01)

        // 8. Indori Poha & Sev: Regular Plate 79, Jumbo Combo with Chai (x2) 120
        val poha = dishes.find { it.id == "indori_poha" }
        assertNotNull(poha)
        assertEquals(79.0, poha!!.options[0].price, 0.01)
        assertEquals(120.0, poha.options[1].price, 0.01)
    }

    @Test
    fun `verify 7-day schedule generation`() {
        val days = ScheduleHelper.generate7Days()
        assertEquals(7, days.size)
        assertTrue(days[0].isToday)
        assertTrue(days[1].isTomorrow)
        assertNotNull(days[0].suggestedDish)
    }

    @Test
    fun `verify customizations are only Fresh Thick Dahi at 30 and Chai at 12`() {
        val addons = KitchenMenuData.commonAddOns
        assertEquals(2, addons.size)
        assertEquals("Fresh Thick Dahi", addons[0].name)
        assertEquals(30.0, addons[0].price, 0.01)
        assertEquals("Chai", addons[1].name)
        assertEquals(12.0, addons[1].price, 0.01)

        // Verify every dish has only these 2 customizations
        for (dish in KitchenMenuData.menuDishes) {
            assertEquals(2, dish.addOns.size)
            assertEquals("Fresh Thick Dahi", dish.addOns[0].name)
            assertEquals("Chai", dish.addOns[1].name)
        }
    }

    @Test
    fun `verify Room database creation and DAOs operations`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, KitchenDatabase::class.java).build()

        // 1. Order DAO
        val order = OrderEntity(
            orderNumber = "ORD-TEST-123",
            targetDate = "2026-10-04",
            dayOfWeek = "Sunday",
            itemsSummary = "2x Aloo Paratha",
            totalAmount = 60.0,
            deliverySlot = "7:45 AM - 8:30 AM",
            deliveryAddress = "Flat 101, Test Street"
        )
        val orderId = db.orderDao().insertOrder(order)
        assertTrue(orderId > 0)
        val orders = db.orderDao().getAllOrdersSync()
        assertEquals(1, orders.size)
        assertEquals("ORD-TEST-123", orders[0].orderNumber)

        // 2. Day Cart DAO
        val cartItem = DayCartItemEntity(
            dayIndex = 1,
            dishId = "aloo_paratha",
            dishName = "Aloo Paratha",
            optionId = "aloo_2",
            optionLabel = "2 Pieces",
            unitPrice = 60.0,
            quantity = 1,
            addOnNames = "Fresh Thick Dahi (₹30)"
        )
        val itemId = db.dayCartDao().insertItem(cartItem)
        assertTrue(itemId > 0)
        val dayItems = db.dayCartDao().getAllItemsSync()
        assertEquals(1, dayItems.size)
        assertEquals("Aloo Paratha", dayItems[0].dishName)

        // 3. User Subscription DAO
        val profile = UserSubscriptionEntity(
            id = 1,
            userName = "Test Gourmet",
            walletBalance = 1000.0
        )
        db.userSubscriptionDao().saveProfile(profile)
        val loadedProfile = db.userSubscriptionDao().getProfileSync()
        assertNotNull(loadedProfile)
        assertEquals("Test Gourmet", loadedProfile?.userName)
        assertEquals(1000.0, loadedProfile?.walletBalance ?: 0.0, 0.01)

        db.close()
    }

    @Test
    fun `verify Google Sign-In with test email and password`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        context.getSharedPreferences("vyanjanam_auth_prefs", Context.MODE_PRIVATE).edit().clear().commit()
        val db = Room.inMemoryDatabaseBuilder(context, KitchenDatabase::class.java).build()
        val repository = KitchenRepository(
            orderDao = db.orderDao(),
            dayCartDao = db.dayCartDao(),
            userSubscriptionDao = db.userSubscriptionDao(),
            context = context
        )

        // Initial state
        repository.signOut()
        assertEquals(false, repository.isLoggedIn.value)

        // Perform Google Sign-In with test credentials
        val testEmail = "test.foodie@gmail.com"
        val testPassword = "TestPass@1234"
        val testDisplayName = "Test Foodie"

        repository.signInWithGoogleSuspend(testEmail, testPassword, testDisplayName)

        // Verify signed in state
        assertTrue(repository.isLoggedIn.value)
        val user = repository.currentUser.value
        assertNotNull(user)
        assertEquals(testEmail, user?.email)
        assertEquals(testDisplayName, user?.name)
        assertTrue(user?.isVerified == true)

        // Verify saved to Room Database profile
        val savedProfile = db.userSubscriptionDao().getProfileSync()
        assertNotNull(savedProfile)
        assertEquals(testEmail, savedProfile?.email)
        assertEquals(testDisplayName, savedProfile?.userName)

        db.close()
    }

    @Test
    fun `verify unverified order created as PENDING without marking as PAID`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, KitchenDatabase::class.java).build()

        val pendingOrder = OrderEntity(
            orderNumber = "CF-SANDBOX-101",
            targetDate = "2026-10-05",
            dayOfWeek = "Monday",
            itemsSummary = "4x Gobhi Paratha",
            totalAmount = 100.0,
            deliverySlot = "7:00 AM - 7:45 AM",
            deliveryAddress = "Flat 101, Park Avenue, Sector 4",
            paymentMethod = "Cashfree Sandbox (Pending)",
            paymentStatus = "PENDING",
            kitchenStatus = "PAYMENT_PENDING",
            transactionId = "CF_PENDING_101"
        )

        val id = db.orderDao().insertOrder(pendingOrder)
        assertTrue(id > 0)

        val retrieved = db.orderDao().getAllOrdersSync().firstOrNull { it.orderNumber == "CF-SANDBOX-101" }
        assertNotNull(retrieved)
        assertEquals("PENDING", retrieved?.paymentStatus)
        assertEquals("PAYMENT_PENDING", retrieved?.kitchenStatus)
        assertEquals(false, retrieved?.isLocked)

        db.close()
    }

    @Test
    fun `verify authoritative server confirmation updates order to PAID`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, KitchenDatabase::class.java).build()

        val pendingOrder = OrderEntity(
            orderNumber = "CF-SANDBOX-202",
            targetDate = "2026-10-06",
            dayOfWeek = "Tuesday",
            itemsSummary = "Idli + Vada Combo",
            totalAmount = 120.0,
            deliverySlot = "8:30 AM - 9:15 AM",
            deliveryAddress = "Villa 12, Green Glen Layout",
            paymentMethod = "Cashfree Sandbox",
            paymentStatus = "PENDING",
            kitchenStatus = "PAYMENT_PENDING",
            transactionId = "CF_INITIAL_202"
        )
        db.orderDao().insertOrder(pendingOrder)

        // Simulate authoritative server verification callback
        val verifiedTxnId = "CF_TXN_VERIFIED_998877"
        db.orderDao().updateOrderPaymentStatus(
            orderNumber = "CF-SANDBOX-202",
            paymentStatus = "PAID",
            transactionId = verifiedTxnId,
            kitchenStatus = "LOCKED & CONFIRMED"
        )

        val updated = db.orderDao().getAllOrdersSync().firstOrNull { it.orderNumber == "CF-SANDBOX-202" }
        assertNotNull(updated)
        assertEquals("PAID", updated?.paymentStatus)
        assertEquals("LOCKED & CONFIRMED", updated?.kitchenStatus)
        assertEquals(verifiedTxnId, updated?.transactionId)

        db.close()
    }

    @Test
    fun `verify offline payment manager returns failure and never marks order paid`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = com.example.payment.CashfreePaymentManager(context)
        // Point to nonexistent offline host
        com.example.payment.CashfreePaymentManager.backendBaseUrl = "http://127.0.0.1:59999"

        val createResult = manager.createSandboxOrder(
            orderNumber = "ORD-TEST-FAIL",
            amount = 150.0,
            customerPhone = "9876543210",
            customerName = "Test Foodie"
        )

        // Must fail gracefully rather than producing a fake paid session
        assertTrue(createResult.isFailure)

        val verifyResult = manager.verifyOrderOnServer("ORD-TEST-FAIL")
        assertTrue(verifyResult.isFailure)
    }

    @Test
    fun `verify Cashfree HMAC-SHA256 signature procedure matching official spec`() {
        val secretKey = "test_cf_secret_key_12345"
        val timestamp = "1729000000"
        val rawBody = "{\"data\":{\"order\":{\"order_id\":\"ORD_123\",\"order_amount\":100.0}}}"

        val signedData = timestamp + rawBody
        val mac = javax.crypto.Mac.getInstance("HmacSHA256")
        mac.init(javax.crypto.spec.SecretKeySpec(secretKey.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        val computedBytes = mac.doFinal(signedData.toByteArray(Charsets.UTF_8))
        val expectedSignature = android.util.Base64.encodeToString(computedBytes, android.util.Base64.NO_WRAP)

        // Test signature comparison
        assertNotNull(expectedSignature)
        assertTrue(expectedSignature.isNotEmpty())

        // Tampered payload must mismatch
        val tamperedBody = "{\"data\":{\"order\":{\"order_id\":\"ORD_123\",\"order_amount\":1.0}}}"
        val tamperedBytes = mac.doFinal((timestamp + tamperedBody).toByteArray(Charsets.UTF_8))
        val tamperedSignature = android.util.Base64.encodeToString(tamperedBytes, android.util.Base64.NO_WRAP)
        org.junit.Assert.assertNotEquals(expectedSignature, tamperedSignature)
    }
}

