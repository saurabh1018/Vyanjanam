const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function loadEnv() {
  try {
    const envPath = path.join(__dirname, '.env');
    if (fs.existsSync(envPath)) {
      const envContent = fs.readFileSync(envPath, 'utf8');
      envContent.split('\n').forEach(line => {
        const trimmed = line.trim();
        if (trimmed && !trimmed.startsWith('#')) {
          const eqIdx = trimmed.indexOf('=');
          if (eqIdx > 0) {
            const key = trimmed.substring(0, eqIdx).trim();
            const val = trimmed.substring(eqIdx + 1).trim().replace(/^["']|["']$/g, '');
            process.env[key] = val;
          }
        }
      });
    }
  } catch (e) {
    // ignore
  }
}
loadEnv();

const PORT = process.env.APP_PORT || ((process.env.PORT && process.env.PORT !== '8080') ? process.env.PORT : 3000);
const ADMIN_HTML = path.join(__dirname, 'app/src/main/assets/admin_dashboard.html');
const DELETION_HTML = path.join(__dirname, 'app/src/main/assets/account_deletion.html');

// Cashfree Configuration - strictly Sandbox mode with dynamic hot-reload from .env
function getCashfreeAppId() {
  loadEnv();
  const id = process.env.CASHFREE_APP_ID || '';
  return (id.startsWith('TEST_YOUR_') || id.includes('YOUR_APP_ID') || id === '') ? '' : id;
}

function getCashfreeSecretKey() {
  loadEnv();
  const sec = process.env.CASHFREE_SECRET_KEY || '';
  return (sec.startsWith('cfsk_ma_test_YOUR_') || sec.includes('YOUR_SECRET') || sec === '') ? '' : sec;
}

const CASHFREE_API_VERSION = process.env.CASHFREE_API_VERSION || '2023-08-01';
const CASHFREE_BASE_URL = 'sandbox.cashfree.com';

// Official WhatsApp Business Number & Payment Management Configuration
const WHATSAPP_BUSINESS_NUMBER = process.env.WHATSAPP_BUSINESS_NUMBER || '917579890049';
const ADMIN_API_KEY = process.env.ADMIN_API_KEY || 'vyanjanam_admin_secure_2026';

// In-memory idempotency tracking for webhook transactions & verified orders
const processedOrders = new Map();

// --- Secure Authentication & Session Management for Admin Portal ---
function getAdminPassword() {
  loadEnv();
  return process.env.ADMIN_PASSWORD || process.env.ADMIN_PASSCODE || '2026';
}

function verifyPasswordTimingSafe(providedPassword) {
  if (typeof providedPassword !== 'string' || !providedPassword) return false;
  const expected = getAdminPassword();
  const h1 = crypto.createHash('sha256').update(providedPassword).digest();
  const h2 = crypto.createHash('sha256').update(expected).digest();
  return (h1.length === h2.length) && crypto.timingSafeEqual(h1, h2);
}

// Rate Limiting: Max 5 failed attempts per 15-minute window per IP
const failedLoginAttempts = new Map();
const MAX_FAILED_ATTEMPTS = 5;
const LOCKOUT_DURATION_MS = 15 * 60 * 1000; // 15 minutes

function checkRateLimit(clientIp) {
  const now = Date.now();
  const record = failedLoginAttempts.get(clientIp);
  if (!record) return { allowed: true };

  if (record.lockedUntil && now < record.lockedUntil) {
    const remainingSec = Math.ceil((record.lockedUntil - now) / 1000);
    return { allowed: false, remainingSec };
  }

  if (record.lockedUntil && now >= record.lockedUntil) {
    failedLoginAttempts.delete(clientIp);
    return { allowed: true };
  }

  if (now - record.firstAttemptAt > LOCKOUT_DURATION_MS) {
    failedLoginAttempts.delete(clientIp);
    return { allowed: true };
  }

  return { allowed: true, remainingAttempts: MAX_FAILED_ATTEMPTS - record.count };
}

function recordFailedAttempt(clientIp) {
  const now = Date.now();
  const record = failedLoginAttempts.get(clientIp) || { count: 0, firstAttemptAt: now, lockedUntil: 0 };
  record.count += 1;

  if (record.count >= MAX_FAILED_ATTEMPTS) {
    record.lockedUntil = now + LOCKOUT_DURATION_MS;
    console.warn(`[Security Alert] IP ${clientIp} temporarily locked out due to ${record.count} consecutive failed login attempts.`);
  } else {
    failedLoginAttempts.set(clientIp, record);
    console.warn(`[Security] Failed login attempt from ${clientIp}. (${record.count}/${MAX_FAILED_ATTEMPTS})`);
  }
}

function clearFailedAttempts(clientIp) {
  failedLoginAttempts.delete(clientIp);
}

// Active Server Sessions
const activeAdminSessions = new Map();
const SESSION_TTL_MS = 8 * 60 * 60 * 1000; // 8 hours

function createAdminSession(clientIp) {
  const sessionToken = crypto.randomBytes(32).toString('hex');
  const session = {
    token: sessionToken,
    role: 'admin',
    ip: clientIp,
    createdAt: Date.now(),
    expiresAt: Date.now() + SESSION_TTL_MS
  };
  activeAdminSessions.set(sessionToken, session);
  return session;
}

function invalidateAdminSession(token) {
  if (token) {
    activeAdminSessions.delete(token);
  }
}

function parseCookies(req) {
  const list = {};
  const rc = req.headers.cookie;
  if (rc) {
    rc.split(';').forEach(cookie => {
      const parts = cookie.split('=');
      const name = parts.shift().trim();
      const value = decodeURI(parts.join('='));
      if (name) list[name] = value;
    });
  }
  return list;
}

function authenticateAdmin(req) {
  // 1. Check HttpOnly cookie
  const cookies = parseCookies(req);
  let token = cookies['vyanjanam_admin_session'];

  // 2. Check Authorization header: Bearer <token>
  if (!token && req.headers.authorization) {
    const authHeader = req.headers.authorization.trim();
    if (authHeader.startsWith('Bearer ')) {
      token = authHeader.substring(7).trim();
    }
  }

  // 3. Fallback for server-to-server with ADMIN_API_KEY
  if (!token && req.headers['x-admin-key']) {
    if (req.headers['x-admin-key'] === ADMIN_API_KEY) {
      return { role: 'admin', type: 'api_key', expiresAt: Date.now() + SESSION_TTL_MS };
    }
  }

  if (!token) return null;

  const session = activeAdminSessions.get(token);
  if (!session) return null;

  // Check session expiry
  if (Date.now() > session.expiresAt) {
    activeAdminSessions.delete(token);
    return null;
  }

  return session;
}


function sendJson(res, statusCode, data) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, x-api-version'
  });
  res.end(JSON.stringify(data));
}

/**
 * Make an HTTPS request to Cashfree Sandbox API
 */
function callCashfree(options, postData) {
  return new Promise((resolve, reject) => {
    const req = https.request(options, (res) => {
      let body = '';
      res.on('data', chunk => { body += chunk; });
      res.on('end', () => {
        try {
          const parsed = JSON.parse(body);
          resolve({ statusCode: res.statusCode, headers: res.headers, data: parsed, raw: body });
        } catch (e) {
          resolve({ statusCode: res.statusCode, headers: res.headers, data: null, raw: body });
        }
      });
    });

    req.on('error', (err) => {
      reject(err);
    });

    if (postData) {
      req.write(typeof postData === 'string' ? postData : JSON.stringify(postData));
    }
    req.end();
  });
}

/**
 * Cashfree Webhook Signature Verification
 * Cashfree signature: Base64(HMAC-SHA256(timestamp + rawBody, secretKey))
 * Validates 5-minute replay attack window and performs timing-safe comparison
 */
function verifyCashfreeWebhookSignature(signature, timestamp, rawBody, secretKey) {
  if (!signature || !secretKey || !rawBody) return false;
  try {
    // Validate timestamp freshness (within 5 minutes / 300 seconds)
    if (timestamp) {
      const tsNum = parseInt(timestamp, 10);
      const nowSec = Math.floor(Date.now() / 1000);
      if (isNaN(tsNum) || Math.abs(nowSec - tsNum) > 300) {
        console.warn(`[Cashfree] Webhook timestamp outside allowed 5-minute window: header=${timestamp}, server=${nowSec}`);
        return false;
      }
    }

    const signedData = timestamp ? (timestamp + rawBody) : rawBody;
    const computed = crypto.createHmac('sha256', secretKey).update(signedData).digest('base64');
    
    const sigBuf = Buffer.from(signature, 'utf8');
    const compBuf = Buffer.from(computed, 'utf8');
    if (sigBuf.length !== compBuf.length) {
      return false;
    }
    return crypto.timingSafeEqual(sigBuf, compBuf);
  } catch (err) {
    console.error('[Cashfree] Signature verification exception:', err);
    return false;
  }
}


const server = http.createServer((req, res) => {
  const urlObj = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const urlPath = urlObj.pathname;

  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization, x-api-version, x-webhook-signature, x-webhook-timestamp'
    });
    return res.end();
  }

  if (urlPath === '/health') {
    return sendJson(res, 200, {
      status: 'ok',
      service: 'Vyanjanam Backend & Cashfree Sandbox Server',
      sandbox_configured: Boolean(getCashfreeAppId() && getCashfreeSecretKey()),
      environment: 'SANDBOX'
    });
  }

  // Payment System Configuration
  if (urlPath === '/api/payment/config' && req.method === 'GET') {
    return sendJson(res, 200, {
      whatsapp_business_number: WHATSAPP_BUSINESS_NUMBER,
      whatsapp_display: '+91 7579890049',
      payment_mode: 'WHATSAPP_MANUAL_UPI',
      cashfree_customer_facing_enabled: false, // Cashfree kept out of live customer checkout until production onboarding is approved
      cashfree_sandbox_available: true,
      currency: 'INR'
    });
  }

  // VALIDATE ORDER & INITIATE WHATSAPP MANUAL PAYMENT
  if (urlPath === '/api/orders/validate' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const payload = JSON.parse(body);
        const { order_id, order_amount, items_summary, customer_name, customer_phone, delivery_slot } = payload;
        
        if (!order_amount || order_amount <= 0) {
          return sendJson(res, 400, { error: 'Invalid order amount' });
        }

        const validOrderId = order_id || `RK-${Math.floor(1000 + Math.random() * 9000)}`;
        const finalAmount = parseFloat(order_amount);

        // Register order with PAYMENT_PENDING status in backend state
        processedOrders.set(validOrderId, {
          order_id: validOrderId,
          order_amount: finalAmount,
          currency: 'INR',
          status: 'PAYMENT_PENDING',
          payment_method: 'WHATSAPP_MANUAL_UPI',
          customer_name: customer_name || 'Customer',
          customer_phone: customer_phone || '',
          delivery_slot: delivery_slot || '',
          items_summary: items_summary || '',
          created_at: Date.now()
        });

        const prefilledText = `Hello Vyanjanam Team, I have placed Order #${validOrderId} for ₹${Math.round(finalAmount)}. Please share the bank UPI QR code for payment.`;
        const waLink = `https://wa.me/${WHATSAPP_BUSINESS_NUMBER}?text=${encodeURIComponent(prefilledText)}`;

        console.log(`[Order Initiated] ID: ${validOrderId}, Amount: ₹${finalAmount}, Status: PAYMENT_PENDING`);

        return sendJson(res, 200, {
          success: true,
          order_id: validOrderId,
          order_amount: finalAmount,
          currency: 'INR',
          status: 'PAYMENT_PENDING',
          whatsapp_business_number: WHATSAPP_BUSINESS_NUMBER,
          whatsapp_link: waLink,
          instructions: 'Customer pays via Bank UPI QR sent on WhatsApp. Admin verifies bank credit.'
        });
      } catch (err) {
        console.error('[Orders] Error validating order:', err);
        return sendJson(res, 400, { error: 'Malformed request payload' });
      }
    });
    return;
  }

  // 1. ADMIN LOGIN (POST) - Timing-safe, rate-limited, sets HttpOnly secure session cookie
  if (urlPath === '/api/admin/login' && req.method === 'POST') {
    const clientIp = req.headers['x-forwarded-for']?.split(',')[0].trim() || req.socket.remoteAddress || 'unknown';
    const rateCheck = checkRateLimit(clientIp);
    if (!rateCheck.allowed) {
      return sendJson(res, 429, {
        success: false,
        error: `Too many failed login attempts. Account temporarily locked for security. Please try again in ${Math.ceil(rateCheck.remainingSec / 60)} minutes.`
      });
    }

    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const payload = JSON.parse(body || '{}');
        const { password } = payload;

        if (!password || !verifyPasswordTimingSafe(password)) {
          recordFailedAttempt(clientIp);
          return sendJson(res, 401, {
            success: false,
            error: 'Invalid administrator credentials. Access denied.'
          });
        }

        clearFailedAttempts(clientIp);
        const session = createAdminSession(clientIp);

        // Set HttpOnly, Secure, SameSite=Strict session cookie
        res.writeHead(200, {
          'Content-Type': 'application/json',
          'Set-Cookie': `vyanjanam_admin_session=${session.token}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=28800`,
          'Access-Control-Allow-Origin': '*',
          'Access-Control-Allow-Credentials': 'true',
          'Access-Control-Allow-Headers': 'Content-Type, Authorization'
        });
        return res.end(JSON.stringify({
          success: true,
          message: 'Authenticated successfully',
          token: session.token,
          role: 'admin',
          expiresAt: session.expiresAt
        }));
      } catch (e) {
        return sendJson(res, 400, { error: 'Malformed login payload' });
      }
    });
    return;
  }

  // 2. ADMIN SESSION STATUS (GET) - Server-side session verification
  if (urlPath === '/api/admin/session' && req.method === 'GET') {
    const session = authenticateAdmin(req);
    if (session) {
      return sendJson(res, 200, {
        authenticated: true,
        role: session.role,
        expiresAt: session.expiresAt
      });
    } else {
      return sendJson(res, 200, {
        authenticated: false
      });
    }
  }

  // 3. ADMIN LOGOUT (POST) - Invalidates server session and clears cookie
  if (urlPath === '/api/admin/logout' && req.method === 'POST') {
    const cookies = parseCookies(req);
    const token = cookies['vyanjanam_admin_session'];
    invalidateAdminSession(token);

    res.writeHead(200, {
      'Content-Type': 'application/json',
      'Set-Cookie': 'vyanjanam_admin_session=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Credentials': 'true'
    });
    return res.end(JSON.stringify({
      success: true,
      message: 'Logged out successfully. Server session invalidated.'
    }));
  }

  // ADMIN: MANUALLY VERIFY BANK CREDIT & MARK ORDER AS PAID (Server Auth Protected)
  if (urlPath === '/api/admin/verify-manual-payment' && req.method === 'POST') {
    const session = authenticateAdmin(req);
    if (!session) {
      return sendJson(res, 401, {
        error: 'Unauthorized: Valid administrator session required to verify bank credit.'
      });
    }
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const payload = JSON.parse(body);
        const { order_id, admin_notes, payment_ref } = payload;

        if (!order_id) {
          return sendJson(res, 400, { error: 'order_id is required' });
        }

        const existing = processedOrders.get(order_id) || {};
        const verifiedAmount = existing.order_amount || payload.order_amount || 0;

        processedOrders.set(order_id, {
          ...existing,
          order_id: order_id,
          order_amount: verifiedAmount,
          status: 'PAID',
          payment_id: payment_ref || `UPI_WA_CREDIT_${Date.now() % 1000000}`,
          verified_by: 'ADMIN_MANUAL_UPI',
          admin_notes: admin_notes || 'Bank credit verified manually via UPI statement',
          verified_at: Date.now()
        });

        console.log(`[Admin Payment Verified] Order ${order_id} marked as PAID. Bank credit confirmed.`);

        return sendJson(res, 200, {
          success: true,
          order_id: order_id,
          status: 'PAID',
          payment_id: processedOrders.get(order_id).payment_id,
          verified_at: processedOrders.get(order_id).verified_at,
          message: 'Bank credit verified. Order successfully marked as PAID.'
        });
      } catch (err) {
        console.error('[Admin Verify] Error:', err);
        return sendJson(res, 400, { error: 'Malformed request payload' });
      }
    });
    return;
  }

  // Cashfree Client Configuration Status (Safe for public client query, never reveals secrets)
  if (urlPath === '/api/cashfree/config' && req.method === 'GET') {
    const appId = getCashfreeAppId();
    return sendJson(res, 200, {
      environment: 'SANDBOX',
      configured: Boolean(appId && getCashfreeSecretKey()),
      app_id_preview: appId ? appId.substring(0, 8) + '...' : 'NOT_SET',
      api_version: CASHFREE_API_VERSION
    });
  }

  // 1. CREATE CASHFREE SANDBOX ORDER
  if (urlPath === '/api/cashfree/create-order' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', async () => {
      try {
        const payload = JSON.parse(body);
        const { order_id, order_amount, customer_details } = payload;

        if (!order_id || !order_amount || order_amount <= 0) {
          return sendJson(res, 400, {
            error: 'Invalid order parameters. order_id and positive order_amount are required.'
          });
        }

        const customerId = customer_details?.customer_id || 'cust_' + Date.now();
        const customerPhone = customer_details?.customer_phone || '9876543210';
        const customerName = customer_details?.customer_name || 'Vyanjanam Customer';
        const customerEmail = customer_details?.customer_email || 'guest@vyanjanam.in';

        const appId = getCashfreeAppId();
        const secretKey = getCashfreeSecretKey();

        // Check if server credentials are fully populated
        if (!appId || !secretKey) {
          console.error('[Cashfree] CASHFREE_APP_ID or CASHFREE_SECRET_KEY not set in server environment.');
          return sendJson(res, 503, {
            error: 'Cashfree Sandbox is not configured on backend server. Please configure CASHFREE_APP_ID and CASHFREE_SECRET_KEY in server .env file.'
          });
        }

        const cfOrderPayload = {
          order_id: order_id,
          order_amount: parseFloat(order_amount),
          order_currency: 'INR',
          customer_details: {
            customer_id: customerId,
            customer_name: customerName,
            customer_phone: customerPhone,
            customer_email: customerEmail
          },
          order_meta: {
            return_url: `https://www.cashfree.com/devstudio/thankyou?order_id=${order_id}`,
            notify_url: `https://www.cashfree.com/devstudio/thankyou?order_id=${order_id}`
          },
          order_note: 'Vyanjanam Cloud Kitchen Breakfast Order'
        };

        const postBody = JSON.stringify(cfOrderPayload);
        const requestOptions = {
          hostname: CASHFREE_BASE_URL,
          path: '/pg/orders',
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-client-id': appId,
            'x-client-secret': secretKey,
            'x-api-version': CASHFREE_API_VERSION,
            'Content-Length': Buffer.byteLength(postBody)
          }
        };

        const cfResponse = await callCashfree(requestOptions, postBody);
        console.log(`[Cashfree Create Order] Status: ${cfResponse.statusCode}, Order: ${order_id}`);

        if (cfResponse.statusCode === 200 && cfResponse.data?.payment_session_id) {
          processedOrders.set(order_id, {
            order_id,
            order_amount: parseFloat(order_amount),
            status: 'ACTIVE',
            payment_session_id: cfResponse.data.payment_session_id,
            created_at: Date.now()
          });

          return sendJson(res, 200, {
            status: 'success',
            order_id: cfResponse.data.order_id,
            payment_session_id: cfResponse.data.payment_session_id,
            order_status: cfResponse.data.order_status,
            order_amount: cfResponse.data.order_amount,
            order_currency: cfResponse.data.order_currency,
            environment: 'SANDBOX'
          });
        } else {
          return sendJson(res, cfResponse.statusCode || 500, {
            error: 'Cashfree API order creation failure',
            details: cfResponse.data || cfResponse.raw
          });
        }
      } catch (err) {
        console.error('[Cashfree] Exception in create-order:', err);
        return sendJson(res, 500, { error: 'Internal server error while initiating Cashfree order' });
      }
    });
    return;
  }

  // 2. VERIFY CASHFREE PAYMENT (Server-to-Server official verification)
  if (urlPath === '/api/cashfree/verify-order' && req.method === 'GET') {
    const orderId = urlObj.searchParams.get('order_id');
    if (!orderId) {
      return sendJson(res, 400, { error: 'order_id parameter is required' });
    }

    const appId = getCashfreeAppId();
    const secretKey = getCashfreeSecretKey();

    // Check if server credentials are set
    if (!appId || !secretKey) {
      console.error('[Cashfree Verify] Credentials missing in server environment.');
      return sendJson(res, 503, {
        error: 'Cashfree Sandbox is not configured on backend server. Please configure CASHFREE_APP_ID and CASHFREE_SECRET_KEY in server .env file.'
      });
    }

    (async () => {
      try {
        const requestOptions = {
          hostname: CASHFREE_BASE_URL,
          path: `/pg/orders/${encodeURIComponent(orderId)}/payments`,
          method: 'GET',
          headers: {
            'x-client-id': appId,
            'x-client-secret': secretKey,
            'x-api-version': CASHFREE_API_VERSION
          }
        };

        const cfResponse = await callCashfree(requestOptions);
        console.log(`[Cashfree Verify Payments] Status: ${cfResponse.statusCode}, Order: ${orderId}`);

        let isPaid = false;
        let successfulTxn = null;

        if (cfResponse.statusCode === 200 && Array.isArray(cfResponse.data)) {
          successfulTxn = cfResponse.data.find(p => p.payment_status === 'SUCCESS');
          if (successfulTxn) {
            isPaid = true;
          }
        }

        // Also check order status directly
        const orderStatusOpts = {
          hostname: CASHFREE_BASE_URL,
          path: `/pg/orders/${encodeURIComponent(orderId)}`,
          method: 'GET',
          headers: {
            'x-client-id': appId,
            'x-client-secret': secretKey,
            'x-api-version': CASHFREE_API_VERSION
          }
        };
        const orderStatusRes = await callCashfree(orderStatusOpts);
        if (orderStatusRes.statusCode === 200 && orderStatusRes.data?.order_status === 'PAID') {
          isPaid = true;
        }

        const expectedOrder = processedOrders.get(orderId);
        const actualAmount = parseFloat(successfulTxn?.payment_amount || orderStatusRes.data?.order_amount || 0);
        const actualCurrency = successfulTxn?.payment_currency || orderStatusRes.data?.order_currency || 'INR';

        // Security Validation: Never confirm if paid amount differs from expected order amount
        if (isPaid && expectedOrder && expectedOrder.order_amount) {
          if (Math.abs(expectedOrder.order_amount - actualAmount) > 0.01) {
            console.error(`[Cashfree Verify] Amount mismatch for ${orderId}: expected ${expectedOrder.order_amount}, received ${actualAmount}`);
            isPaid = false;
          }
        }
        if (isPaid && actualCurrency !== 'INR') {
          console.error(`[Cashfree Verify] Currency mismatch for ${orderId}: ${actualCurrency}`);
          isPaid = false;
        }

        if (isPaid) {
          processedOrders.set(orderId, {
            order_id: orderId,
            status: 'PAID',
            payment_id: successfulTxn?.cf_payment_id || 'CF_VERIFIED',
            payment_amount: actualAmount,
            verified_at: Date.now()
          });
        }

        return sendJson(res, 200, {
          order_id: orderId,
          is_paid: isPaid,
          payment_status: isPaid ? 'SUCCESS' : (orderStatusRes.data?.order_status || 'PENDING'),
          transaction_id: successfulTxn?.cf_payment_id || '',
          payment_amount: actualAmount,
          currency: 'INR',
          environment: 'SANDBOX',
          verified_by: 'Cashfree Server-to-Server Official API'
        });
      } catch (err) {
        console.error('[Cashfree] Exception in verify-order:', err);
        return sendJson(res, 500, { error: 'Failed to verify payment with Cashfree API' });
      }
    })();
    return;
  }

  // 3. CASHFREE AUTHENTICATED WEBHOOK RECEIVER (Idempotent)
  if (urlPath === '/api/cashfree/webhook' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const signature = req.headers['x-webhook-signature'];
        const timestamp = req.headers['x-webhook-timestamp'];
        const webhookSecret = getCashfreeSecretKey();

        // Validate secret key configuration - never bypass signature verification!
        if (!webhookSecret) {
          console.error('[Cashfree Webhook] Webhook received but CASHFREE_SECRET_KEY is not configured on server.');
          return sendJson(res, 503, { error: 'Webhook processing unavailable: CASHFREE_SECRET_KEY unconfigured' });
        }

        if (!signature) {
          console.warn('[Cashfree Webhook] Missing x-webhook-signature header.');
          return sendJson(res, 401, { error: 'Missing x-webhook-signature header' });
        }

        const isValid = verifyCashfreeWebhookSignature(signature, timestamp, body, webhookSecret);
        if (!isValid) {
          console.warn('[Cashfree Webhook] Invalid signature received! Rejecting unauthorized webhook.');
          return sendJson(res, 401, { error: 'Invalid webhook signature' });
        }

        const event = JSON.parse(body);
        const orderData = event.data?.order || {};
        const paymentData = event.data?.payment || {};
        const orderId = orderData.order_id || paymentData.order_id;
        const paymentStatus = paymentData.payment_status || orderData.order_status;
        const receivedAmount = parseFloat(paymentData.payment_amount || orderData.order_amount || 0);
        const receivedCurrency = paymentData.payment_currency || orderData.order_currency || 'INR';

        console.log(`[Cashfree Webhook Received] Type: ${event.type}, Order: ${orderId}, Status: ${paymentStatus}, Amount: ${receivedAmount}`);

        // Idempotency check: Don't re-process already finalized orders
        if (orderId && processedOrders.get(orderId)?.status === 'PAID') {
          console.log(`[Cashfree Webhook] Order ${orderId} already marked PAID. Idempotency safeguard applied.`);
          return sendJson(res, 200, { status: 'OK', message: 'Order already processed', idempotent: true });
        }

        // Amount & currency verification against expected order
        const expectedOrder = processedOrders.get(orderId);
        if (expectedOrder && expectedOrder.order_amount) {
          if (Math.abs(expectedOrder.order_amount - receivedAmount) > 0.01) {
            console.error(`[Cashfree Webhook] Amount mismatch for ${orderId}: expected ${expectedOrder.order_amount}, received ${receivedAmount}`);
            return sendJson(res, 400, { error: 'Order amount mismatch' });
          }
        }
        if (receivedCurrency !== 'INR') {
          console.error(`[Cashfree Webhook] Currency mismatch for ${orderId}: ${receivedCurrency}`);
          return sendJson(res, 400, { error: 'Currency must be INR' });
        }

        if (paymentStatus === 'SUCCESS' || paymentStatus === 'PAID') {
          processedOrders.set(orderId, {
            order_id: orderId,
            status: 'PAID',
            payment_id: paymentData.cf_payment_id || 'CF_WEBHOOK_CONFIRMED',
            payment_amount: receivedAmount,
            processed_at: Date.now()
          });
          console.log(`[Cashfree Webhook] Order ${orderId} verified and confirmed as PAID.`);
        }

        return sendJson(res, 200, { status: 'OK', processed: true });
      } catch (err) {
        console.error('[Cashfree Webhook] Error processing event:', err);
        return sendJson(res, 400, { error: 'Malformed webhook payload' });
      }
    });
    return;
  }

  // Google Play Store Account & Data Deletion Portal
  if (['/delete-account', '/delete-account.html', '/data-deletion', '/account-deletion', '/privacy/delete-account'].includes(urlPath)) {
    fs.readFile(DELETION_HTML, 'utf8', (err, data) => {
      if (err) {
        console.error('Error reading deletion HTML:', err);
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        return res.end('Error loading account deletion portal');
      }

      res.writeHead(200, {
        'Content-Type': 'text/html; charset=utf-8',
        'Cache-Control': 'no-cache, no-store, must-revalidate'
      });
      res.end(data);
    });
    return;
  }

  // Web Deletion Request API
  if (urlPath === '/api/request-deletion' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const payload = JSON.parse(body);
        console.log('[Account Deletion Request Received]:', payload);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ status: 'success', ticket: payload.ticket || 'DEL-CONFIRMED', message: 'Deletion request registered successfully' }));
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Invalid JSON payload' }));
      }
    });
    return;
  }

  // Default: Admin Dashboard
  fs.readFile(ADMIN_HTML, 'utf8', (err, data) => {
    if (err) {
      console.error('Error reading HTML:', err);
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      return res.end('Error loading admin dashboard');
    }

    res.writeHead(200, {
      'Content-Type': 'text/html; charset=utf-8',
      'Cache-Control': 'no-cache, no-store, must-revalidate',
      'Pragma': 'no-cache',
      'Expires': '0'
    });
    res.end(data);
  });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Vyanjanam Web Server & Cashfree Sandbox listening on http://0.0.0.0:${PORT}`);
});
